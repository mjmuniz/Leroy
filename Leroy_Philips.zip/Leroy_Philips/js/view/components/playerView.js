window.PlayerView = PlayerView = {
             
        header: '<div class="head_wrapper">'+ 
                                 '<div class="lm_logo"></div>'+
			         '<div class="head_text">'+
                                        '<span>El canal de ideas<br> y consejos para tu casa</span>'+
			         '</div>'+
                                 '<div class="head_subtext">Inicio > <span class="category_name_pv"></span> > Video</div>'+
                    '</div>',
                
	backbutton: '<div id="btn_back_pw_anchor" ></div>'+

                    '<div id="player_back_btn" class="btn_backtostart">'+                        
                            '<div class="btn_backtostart_slice_l"></div>' +
                            '<div class="btn_backtostart_slice_c" onclick="Main.magicCtrView3verDynamic()" onmouseover="Main.magicCtrlView3BackMouseOver(this, true)"></div>' +
                            '<div class="btn_backtostart_slice_r"></div>' +
                    '</div>',
                

        videotitle: '<div class="video_title_wrapper">'+ 
                            '<div class="video_title_head"><h1>Aprende Cómo</h1></div>'+
                            '<div class="video_title"><h2></h2></div>'+
                    '</div>',
            
        relatedBox: '<div class="videorelated_arrow_up"  onmouseover="Main.magicCtrView3ArrMouseOver(\'up\')">'+
                             '<img src="./resources/img/buttons/button_up.png">'+
                    '</div>'+ 
                    '<div class="videorelated_arrow_up_sel" onclick="Main.magicCtrView3ArrUpClick()" onmouseout="Main.magicCtrView3ArrMouseOut(\'up\')" >'+
                             '<img src="./resources/img/buttons/button_up_selected.png">'+
                    '</div>'+ 
            
                    '<div class="videorelated_wrapper">'+       // bkg image
                        
                            '<div class="videorelated_title">Vídeos relacionados</div>'+

                            '<div class="thumblist_wrapper">'+
                                
                                    //VIDEO THUMBS LIST
                                    '<div id ="relthumblist_anchor"></div>'+ // thumbs anchor
                            
                            '</div>'+   

                    '</div>'+
                        
                    '<div class="videorelated_arrow_dwn"  onmouseover="Main.magicCtrView3ArrMouseOver(\'down\')">'+
                            '<img src="./resources/img/buttons/button_down.png">'+
                    '</div>'+
                    '<div class="videorelated_arrow_dwn_sel" onclick="Main.magicCtrView3ArrDownClick()" onmouseout="Main.magicCtrView3ArrMouseOut(\'down\')" >'+
                            '<img src="./resources/img/buttons/button_down_selected.png">'+
                    '</div>',
                
        videocontrols: 
                    '<div class="videocontrols_wrapper">'+
                            '<div id="play_button" class="control_play_btn"> </div>'+
                            '<div id="play_button_over" onclick="Main.magicCtrView3PlayPauseClick()" onmouseover="Main.magicCtrView3PlayPauseMouseOver(this)"></div>'+
                            '<div id="stop_button" class="control_stop_btn" onclick="Main.magicCtrView3StopClick()" onmouseover="Main.magicCtrView3StopMouseOver(this)"></div>'+
                            '<div class="progress_bar">'+
                                    '<div id="progress"></div>'+
                            '</div>'+
                            '<div id="fs_button" class="control_fullscr_btn" onclick="Main.magicCtrView3FullscreenClick()"  onmouseover="Main.magicCtrView3FullscreenMouseOver(this)"  ></div>'+
            
                    '</div>',
        videoStopped: 
                        '<div class="videobackground">'+
                        '</div>',
                
        el: '#playerView',
        
        // ID of focused related video
        focusedID: null,
        
        // ID of focused player controll
        focusedPlayerID: null,
        
        thumbName : 'relvideo_thumb',
        thumbId: 0,
        
        // Number of thumbs in related videos list:
        thumbsLength: 3, 
        
        numberOfRelVideos: null, 
        relVideosData: null,
        catgVideosData: null,
        
        // id of video thumb which is displayed as topmost in related video list
        startThumbId : 0,        
        
        // Fullscreen flag
        fullscreenFlag : 0,
        
        // Width of progress bar in pixels 
        progressBarWidth : 511,     //516
        
        navigationIds: {backButton : 0, player : 1, relatedVideos : 2},
        navigationSelected: null ,
        
        controlIds: {play : 0, stop : 1, fullscreen : 2},
        controlSelected: null,
        
        playerStatus : null,
        
        progressTimer : null,
        
	initialize: function(){
                this.navigationSelected = this.navigationIds.relatedVideos;
	},

	
	render: function(el){
		el = $(el || '#playerView');
                this.hide();
		el.append(this.header);
		el.append(this.backbutton);
                el.append(this.videotitle);
                el.append(this.relatedBox);
                el.append(this.videocontrols);
                el.append(this.videoStopped);
                this.setBackground();
                this.fixPhilipsButton_pw();        
	},
        
        initPlayer: function(url){
                if (settings.device != 'philips'){
                    Main.preloadBkgSwap('remove');
                }
               
               try{
            	   this.resetProgress();

                    TVA_Player.init ({url: url});
                    Main.player.setSmallScreen();
                    this.hidePlayer();
                    Main.player.showLoading();
                    TVA_Player.play(); 
                        
                    this.startProgress();     
                }
                catch(err){
                        //LOG ERROR IF IT OCCURS
                        TVA.log('initPlayer:' + err.name + ' ' + err.message);
                        
                }         
        },
        
        fixPhilipsButton_pw: function(){
            
                if ( settings.device == 'philips'){
                        var phButton =
                        '<div class="btn_backtostart">'+                        
                            '<div class="btn_backtostart_slice_l"></div>' +
                            '<div class="btn_backtostart_slice_c" ></div>' +
                            '<div class="btn_backtostart_slice_r"></div>' +
                        '</div>';
                }
                
                $('#btn_back_pw_anchor').append(phButton);
        },
        
        updateProgress : function (){
            
                var seconds = (TVA.device == 'googletv' && TVA_Player.getLength() == -1)?(TVA_Player.getCurrentTime()/-1000):TVA_Player.getCurrentTime();
                var percentPlayed = seconds / TVA_Player.getLength();
                this.oldposition = this.newposition;
                this.newposition = Math.floor(this.progressBarWidth * percentPlayed);
                var progressBarWidth = this.newposition + 'px';
                //TVA.log('progressBarWidth='+progressBarWidth+'||'+TVA_Player.getCurrentTime()+'||length='+TVA_Player.getLength());
                if(TVA.device == 'googletv'){
                  if(typeof this.oldposition == 'number' && typeof this.newposition == 'number' && this.oldposition != null && this.newposition != null && this.oldposition != this.newposition){
                  TVA.log('seconds='+seconds);
                    $('#preload').hide();
                    $('#preloadWeel').removeClass('playerView').hide();
                  }
                } 

                this.$el_progressBar      =  $('#progress');
                if(this.$el_progressBar){
                	this.$el_progressBar.css("width", progressBarWidth);
                }
        },
        

        startProgress: function(){
          this.progressTimer = window.setInterval(bind(this, this.updateProgress), 200);
        },

        resetProgress: function(){
        	this.$el_progressBar      =  $('#progress');
        	if(this.$el_progressBar){
              if(this.progressTimer){
                window.clearInterval(this.progressTimer);
              }
            	this.$el_progressBar.css("width", "0px");
              this.oldposition = null;
              this.newposition = null;
        	}
        },
      
        hide: function(){
                Main.player.getPlayerState();
                var playerState = Main.player.status;
                
                if (playerState != 0){
                    
                        TVA_Player.stop();
                }
                /*
                if( settings.device == 'philips' || settings.device == 'googletv' ){
                
                    TVA_Player.stop();
                }
                else if( settings.device == 'samsung' || settings.device == 'lg' ){
                        TVA_Player.deinit();
                }
                */
                // if is loading over video
            	$('#preloadWeel').removeClass('playerView');
            	$('#preloadWeel').hide();
                $('#playerView').hide();
        },
        
        isVisible: function(){
		return $(this.el).is(':visible');    
	},
        
        show: function(url, data, id, name, reldata){
                $('#playerView').show();
                this.navigationSelected = this.navigationIds.relatedVideos;
                
                if (this.controlSelected != null) {
                        this.controlSelected = null;
                        this.offFocus(this.focusedPlayerID);
                }
                
		this.startThumbId = 0;
                this.catgVideosData = data;
                this.relVideosData  = reldata;
                this.resetFocus();

                var videoUrl  = CONFIG.hollybyteBaseUrl + url;
                
                this.setStrings(data, id, name);
                       
		$('div.videorelated_arrow_up img').css("display", "none");
                this.initPlayer(videoUrl);
                
                // remove thumblist if exists
                if ($('#relvideo_list_wrapper').length != 0){
                        $('#relvideo_list_wrapper').remove();
                }
                
                // Render the related video List
                this.numberOfRelVideos = this.relVideosData.length;  
                this.generateRelatedVideoList(/*this.thumbsLength,*/ this.relVideosData);
                // Truncate text in thumbnail, add 3 ellipsis respectively
                for (var i = 0; i < this.numberOfRelVideos; i++){
                    truncate($("#container" + i)); 
                    this.$element = $("#container" + i);
                    this.$element.css('height', '54px');
                }
                
                this.setFocus( this.getFocusedId() );
                this.displayPlayButton();
        },
        
        showRelated: function(data, reldata){
                
                this.relVideosData  = reldata;
                this.resetFocus();

                var videoTitle  = data[1];
                // Chop Title
                if(videoTitle.length > 39) {
                    videoTitle = videoTitle.substr(0, 40) + ' ...';
                } 
                
                // Title
                this.$el_titleText      = $('div.video_title_wrapper div.video_title h2');
                this.$el_titleText.html(videoTitle); 
                
                var url = data[5];
                var videoUrl  = CONFIG.hollybyteBaseUrl + url;
                
                //this.setStrings(data, id, name);
                this.initPlayer(videoUrl);
                
                // remove thumblist if exists
                if ($('#relvideo_list_wrapper').length != 0){
                        $('#relvideo_list_wrapper').remove();
                }
                
                // Render the related video List
                this.numberOfRelVideos = this.relVideosData.length;  
                this.generateRelatedVideoList(/*this.thumbsLength, */this.relVideosData);
                // Truncate text in thumbnail, add 3 ellipsis respectively
                for (var i = 0; i < this.numberOfRelVideos; i++){
                    truncate($("#container" + i));
                    this.$element = $("#container" + i);
                    this.$element.css('height', '54px');
                }
                
                this.setFocus( this.getFocusedId() );
                this.displayPlayButton();
        },
        
        showNorel: function(url, data, id, name){
                
                this.catgVideosData = data;
                var videoUrl  = CONFIG.hollybyteBaseUrl + url;
                
                this.setStrings(data, id, name);
                
                $('#playerView').show();  
                this.initPlayer(videoUrl);
                
                this.numberOfRelVideos = 0;
                this.relVideosData = [];
                
                // remove thumblist if exists
                if ($('#relvideo_list_wrapper').length != 0){
                        $('#relvideo_list_wrapper').remove();
                }
                    TVA.log('[categoryView] [show] #relvideo_list_wrapper NOT Exist:  ');
                    
                    TVA.log('[categoryView] [show] '+this.numberOfRelVideos);
                    //TVA.log('[categoryView] [show] '+JSON.stringify(this.relVideosData));
                    
                    this.offFocus(this.focusedID);
                	this.navigationSelected = this.navigationIds.player;
                    this.hidePlayButton();
                    // set focus to fullscreen
                    this.setControlFocus(null, 'left');
        },
        
        
        
        setStrings: function(data, id, name){
            
                var videoTitle          = data[id][1];
                
                // Chop Title
                if(videoTitle.length > 39) {
                    videoTitle = videoTitle.substr(0, 40) + ' ...';
                }          
                var btnText             = 'Volver a ' + name;
                // Title
                this.$el_titleText      = $('div.video_title_wrapper div.video_title h2');
                this.$el_titleText.html(videoTitle); 
                // Back button
                this.$el_backBtnText    = $('div.btn_backtostart_slice_c');
                this.$el_backBtnText.html(btnText); 
                // Header 
                this.$el_catgText = $('div.head_wrapper div.head_subtext span.category_name_pv');
		this.$el_catgText.html(name);
        },

        generateRelatedVideoList: function(data){
        	//TVA.log(JSON.stringify(data));
        	TVA.log('this.numberOfRelVideos='+this.numberOfRelVideos);
                var count = this.thumbsLength;
                var videoNavigation = '<div id="relvideo_list_wrapper">';      // handle for removing former list 
                if (count > this.numberOfRelVideos) count = this.numberOfRelVideos;
                var i;
                for (i = 0; i < count; i++){
                        var videoTitle      = (typeof data[i][1] == 'undefined')?'N/A':data[i][1];
                        var videoSplash     = (typeof data[i][2] == 'undefined')?'':data[i][2];
                        var videoDuration   = (typeof data[i][4] == 'undefined')?'0:00':data[i][4];
                        var videoSource     = (typeof data[i][5] == 'undefined')?'':data[i][5];
                        var videoSplashUrl  = CONFIG.hollybyteBaseUrl + videoSplash;
                        var videoSourceUrl  = CONFIG.hollybyteBaseUrl + videoSource;
                        
                        var relVideoThumbItem = this.renderRelatedVideoThumb({thumbId : i, title : videoTitle , videosplash: videoSplashUrl, duration : videoDuration });
                        videoNavigation += relVideoThumbItem;
                }
                videoNavigation += '</div>';
                
                
                    
                $('#relthumblist_anchor').append(videoNavigation); 
        },

        
        renderRelatedVideoThumb: function(opt){
                return '<div id="relvideo_thumb'+opt.thumbId+'" class="rel_video_thumb_wrapper" onclick="Main.magicCtrView3RelVideoClick(' + opt.thumbId + ')" onmouseover="Main.magicCtrView3RelVideoMouseOver(this)" >'+
                                '<div class="video_thumb">'+
                                        '<img src="'+opt.videosplash+'">'+
                                '</div>'+

                                '<div class = "video_description">'+
                                        //'<p>'+opt.title+'</p> '+
                                        '<div id="container'+ opt.thumbId +'" class="containerClass">'+opt.title+'</div>'+
                                '</div>'+

                                '<div class="video_duration">'+
                                        '<p>'+opt.duration+'</p>'+
                                '</div>'+
                                '<div class="play_btn"></div>'+

                                '<div class="item_focus"></div>'+
                        '</div>';
	},
        
        setBackground: function(){
                this.$el_player_view = $('#playerView');
                this.$el_player_view.css('background','transparent url("./resources/img/bkg3.png") no-repeat left top');
            
        },
        
        hidePlayer: function(){
        	// show div which is over the player
        	$('.videobackground').show();
        },
              
        showPlayer: function(){
        	// hide div which is over the player
        	$('.videobackground').hide();
        },

        moving: function(direction, playerStatus){
            
                this.playerStatus = playerStatus; 
                switch(direction){
				case 'right':this.moveRight();break;
                                case 'left' :this.moveLeft();break;
                                case 'up'   :this.moveUp();break;
                                case 'down' :this.moveDown();break;
                }
	},
        
        moveRight: function(){

                if (this.navigationSelected < getObjLength(this.navigationIds)-1 ){
                        TVA.log('[playerView] [moveRight] this.focusedPlayerID : ' + this.focusedPlayerID );
                        switch(this.navigationSelected){
                                case this.navigationIds.player:                     // Current focus: player

                                        if (this.controlSelected < getObjLength(this.controlIds)-1){ 

                                                this.setControlFocus(this.controlSelected, 'right');
                                        }
                                        else if((this.numberOfRelVideos == 0 || this.relVideosData.length == 0) && this.controlSelected == this.controlIds.fullscreen){
                                            this.offFocus(this.focusedPlayerID);
                                            this.navigationSelected = this.navigationIds.backButton;
                                            this.controlSelected = null;  
                                            this.setPlayBtnOver();
                                            TVA.setFocus('player_back_btn');
                                            
                                            this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                                            this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l_focus.png") no-repeat  0 0');
                                            this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                                            this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c_focus.png") repeat-x');
                                            this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                                            this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r_focus.png") no-repeat  0 0');                                     
                                        }
                                        else{
                                            
                                                this.offFocus(this.focusedPlayerID);
                                                this.navigationSelected++;
                                                this.controlSelected = null;
                                                this.setFocus(this.focusedID);
                                                this.displayPlayButton();
                                        }
                                        
                                        break;
               
                                case this.navigationIds.backButton:                 // Current focus: Back button 
                                        this.offFocus('player_back_btn');           // offFocus backsBtn 
                                        
                                                this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                                                this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l.png") no-repeat  0 0');
                                                this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                                                this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c.png") repeat-x');
                                                this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                                                this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r.png") no-repeat  0 0');
                                        
                                        this.setControlFocus(this.controlSelected, 'right');
                                        this.navigationSelected = this.navigationIds.player;
                                        this.setPlayBtnOver();
                                        break;                                       
                        }
                        TVA.log('[playerView] [moveRight] this.navigationSelected: ' + this.navigationSelected );
                }
                else{
                        this.offFocus(this.focusedID);
                        this.hidePlayButton();
                        this.navigationSelected = this.navigationIds.backButton ;
                        TVA.setFocus('player_back_btn');

                        this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                        this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l_focus.png") no-repeat  0 0');
                        this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                        this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c_focus.png") repeat-x');
                        this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                        this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r_focus.png") no-repeat  0 0');
                }
                                
	},
        
        
        
        moveLeft: function(){
            
                TVA.log('[playerView] [moveLeft] this.controlSelected: ' + this.controlSelected);
                
                if (this.navigationSelected > 0 ){
                        
                        switch(this.navigationSelected){
                                
                                case this.navigationIds.relatedVideos:
                                        this.offFocus(this.focusedID);
                                        this.hidePlayButton();
                                        this.setControlFocus(this.controlSelected, 'left');
                                        this.navigationSelected--;
                                        break;
                                        
                                case this.navigationIds.player:
                                        if (this.controlSelected > 0){
                                            
                                                this.setControlFocus(this.controlSelected, 'left'); 
                                                TVA.log('[playerView] [moveLeft] this.focusedPlayerID : ' + this.focusedPlayerID );
                                        }
                                        else{
                                                this.offFocus(this.focusedPlayerID);
                                                this.navigationSelected--;
                                                this.controlSelected = null;  
                                                this.setPlayBtnOver();
                                                TVA.setFocus('player_back_btn');
                                                
                                                this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                                                this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l_focus.png") no-repeat  0 0');
                                                this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                                                this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c_focus.png") repeat-x');
                                                this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                                                this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r_focus.png") no-repeat  0 0');
                                                
                                        }
                                        break;
                        }
                    
                        
                        TVA.log('[playerView] [moveLeft] this.navigationSelected: ' + this.navigationSelected );        
                }
                else if(this.navigationSelected == 0){

                        this.offFocus('player_back_btn');
                        this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                        this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l.png") no-repeat  0 0');
                        this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                        this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c.png") repeat-x');
                        this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                        this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r.png") no-repeat  0 0');
                    	if(this.numberOfRelVideos == 0 || this.relVideosData.length == 0){
                            this.navigationSelected = this.navigationIds.player;
                            this.setControlFocus(null, 'left');
                            this.displayPlayButton();                    		
                    	}
                    	else{
                            this.navigationSelected = this.navigationIds.relatedVideos;
                            this.setFocus(this.focusedID);
                            this.displayPlayButton();                    		
                    	}
                }

                                
	},
        
        setPlayBtnOver : function(){
            
                TVA.log('[playerView] [setPlayBtnOver] this.navigationSelected:  ' + this.navigationSelected )
            
                if (this.navigationSelected != this.navigationIds.player) {
                        // if paused or stopped:
                        if (this.playerStatus == Main.player.state.STOPPED || this.playerStatus == Main.player.state.PAUSED ){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (this.playerStatus == Main.player.state.PLAYING || this.playerStatus == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                        }

                }
                else if (this.navigationSelected == this.navigationIds.player &&  this.controlSelected != this.controlIds.play ) {

                        TVA.log('this.playerStatus: ' + this.playerStatus);
                        if (this.playerStatus == Main.player.state.STOPPED || this.playerStatus == Main.player.state.PAUSED){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (this.playerStatus == Main.player.state.PLAYING || this.playerStatus == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                        }  
                }
                else{
                        TVA.log('this.playerStatus: ' + this.playerStatus);
                        
                        if (this.playerStatus == Main.player.state.STOPPED || this.playerStatus == Main.player.state.PAUSED){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (this.playerStatus == Main.player.state.PLAYING || this.playerStatus == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause02.png") no-repeat left top');
                        }

                }
                    
    
        },
        
        setPlayBtnOverMC : function(){
            
                        
                if (this.navigationSelected != this.navigationIds.player) {
                    
                        // if paused or stopped:
                        if (Main.player.status == Main.player.state.STOPPED || Main.player.status == Main.player.state.PAUSED){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                        }
                        // if playing:
                        else if (Main.player.status == Main.player.state.PLAYING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                        }

                }
                else if (this.navigationSelected == this.navigationIds.player &&  this.controlSelected != this.controlIds.play ) {

                        if (Main.player.status == Main.player.state.STOPPED || Main.player.status == Main.player.state.PAUSED){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (Main.player.status == Main.player.state.PLAYING || Main.player.status == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                        }  
                }
                else{
                        
                        if (Main.player.status == Main.player.state.STOPPED || Main.player.status == Main.player.state.PAUSED){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (Main.player.status == Main.player.state.PLAYING || Main.player.status == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause02.png") no-repeat left top');
                        }

                }
                    
    
        },
        
        togglePlayBtnOver : function(){
            TVA.log('[togglePlayBtnOver] BEFORE playerStatus='+this.playerStatus+' navigationSelected='+this.navigationSelected+' controlSelected='+this.controlSelected);
            TVA.log('B='+$('#play_button_over').css('background'));
                    if (this.navigationSelected == this.navigationIds.backButton || this.navigationSelected == this.navigationIds.relatedVideos ){
                            // if paused or stopped:
                            if (this.playerStatus == 2 || this.playerStatus == 0){
                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                            }
                            // if playing:
                            else if (this.playerStatus == 1) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                            }
                    }
                    else if (this.navigationSelected == this.navigationIds.player) {
                        
                            if (this.controlSelected == this.controlIds.play){
                                

                                    if (this.playerStatus == 2 || this.playerStatus == 0){
                                                this.$el_play_button = $('#play_button_over');
                                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause02.png") no-repeat left top');
                                    }

                                    else if (this.playerStatus == 1) {

                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');
                                    }
  
                            }
                            else{

                                    if (this.playerStatus == 2 || this.playerStatus == 0){
                                                this.$el_play_button = $('#play_button_over');
                                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                                    }

                                    else if (this.playerStatus == 1) {

                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                                    }

                            }

                        
                    }
                    TVA.log('A='+$('#play_button_over').css('background'));
                    TVA.log('[togglePlayBtnOver] AFTER playerStatus='+this.playerStatus+' navigationSelected='+this.navigationSelected+' controlSelected='+this.controlSelected);
        },
        
        //  focusedPlayerID
      
        setControlFocus: function(id, direction){
            
                if (direction == 'left'){
                    
                        switch(id){

                                case null:
                                        this.setPlayerControlFocus('fs_button');
                                        this.controlSelected = this.controlIds.fullscreen ;
                                        break;
                                        
                                case this.controlIds.fullscreen:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('stop_button');
                                        this.controlSelected--;
                                        break;
                               case this.controlIds.stop:

                                        this.offFocus(this.focusedPlayerID);
                                        // set image for play button
                                        this.setPlayerControlFocus('play_button');
                                        this.controlSelected--;
                                        this.setPlayBtnOver();
                                        break;


                                        
                        }
                }
                else if (direction == 'right'){
                    
                        TVA.log('ID should be null: ' + id);
                    
                        switch(id){
                            
                                case null:
                                        this.setPlayerControlFocus('play_button');
                                        this.controlSelected = this.controlIds.play;
                                        this.setPlayBtnOver();
                                        break;
                    
                                case this.controlIds.play:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('stop_button');
                                        this.controlSelected++; 
                                        this.setPlayBtnOver();
                                        break;
                                        
                                case this.controlIds.stop:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('fs_button');
                                        this.controlSelected++;
                                        break;

                        }
  
                }
       
	},
        
        moveUp: function(){
            
                if (this.navigationSelected == this.navigationIds.relatedVideos){
                    
                        if (this.thumbId > 0 && this.startThumbId == 0 ){
                                this.offFocus(this.thumbName + this.thumbId);
                                this.thumbId = --this.thumbId;
                                this.setFocus(this.thumbName + this.thumbId);
                                this.displayPlayButton();
                                TVA.log('[categoryView] [moveUp] this.thumbId: ' + this.thumbId);
                        }else{
                                this.updateRelatedVideoList('up');
                        }
                    
                }
                // Set focus to Back button
                else if (this.navigationSelected == this.navigationIds.player && this.controlSelected == this.controlIds.play ){
                        this.offFocus(this.focusedPlayerID);
                        this.navigationSelected--;
                        this.controlSelected = null;  
                        this.setPlayBtnOver();
                        TVA.setFocus('player_back_btn');

                        this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                        this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l_focus.png") no-repeat  0 0');
                        this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                        this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c_focus.png") repeat-x');
                        this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                        this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r_focus.png") no-repeat  0 0');
                }
                // Set focus to Related video
                else if (this.navigationSelected == this.navigationIds.player && this.controlSelected == this.controlIds.fullscreen ){
                    
                        this.offFocus(this.focusedPlayerID);
                        this.navigationSelected++;
                        this.controlSelected = null;
                        this.setFocus(this.focusedID);
                        this.displayPlayButton();
                     
                }
           
	},
        
        moveDown: function(){ 
            
                if (this.navigationSelected == this.navigationIds.relatedVideos){
                        if(this.thumbId == this.numberOfRelVideos - 1){
                                return;
                        }

                        else if(this.thumbId < this.thumbsLength - 1){
                                this.offFocus(this.thumbName + this.thumbId);
                                this.thumbId = ++this.thumbId;
                                this.setFocus(this.thumbName + this.thumbId);
                                this.displayPlayButton();
                                TVA.log('[playerView] [moveDown] this.thumbId: ' + this.thumbId);
                        }else{
                                this.updateRelatedVideoList('down');
                        } 
                } 
                else if (this.navigationSelected == this.navigationIds.backButton){
                    
                        this.offFocus('player_back_btn');           // offFocus backsBtn 
                                        
                        this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                        this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l.png") no-repeat  0 0');
                        this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                        this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c.png") repeat-x');
                        this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                        this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r.png") no-repeat  0 0');

                        this.setControlFocus(this.controlSelected, 'right');
                        this.navigationSelected++;
                        this.setPlayBtnOver();
                    
                }
	},
        
        offFocus: function(id){
		if(id){
			TVA.offFocus(id);
		}
	},
        
        offFocusPlayerView: function(){
            
                if (this.navigationSelected == this.navigationIds.backButton){

                        this.offFocusBackButton();
                }   
        },
        
        offHover: function(id){
		if(id){
			TVA.offHover(id);
		}
	},

	setFocus: function(id){
		//this.offHover(this.hoveredID);
		this.offHover(id);
		TVA.setFocus(id);
		this.focusedID = id;
	},
        
        setPlayerControlFocus: function(id){
		//this.offHover(this.hoveredID);
		//this.offHover(id);
		TVA.setFocus(id);
		this.focusedPlayerID = id;
	},
       
        displayPlayButton: function(){
            
                this.$el_play_btn_offFoc = $('div.rel_video_thumb_wrapper div.play_btn');
                this.$el_play_btn_offFoc.css('display','none');
                this.$el_play_btn       = $('div.focus div.play_btn');
                this.$el_play_btn.css('display','block');
        },
        
        hidePlayButton: function(){
            
                this.$el_play_btn_offFoc = $('div.rel_video_thumb_wrapper div.play_btn');
                this.$el_play_btn_offFoc.css('display','none');
        },
        
        updateRelatedVideoList_my : function(direction){
                            
                // id of the last video to be displayed topmost:
                var limitStartVideoNumb = this.numberOfRelVideos - this.thumbsLength;  

                if(direction == 'down'){

                        if (this.startThumbId == limitStartVideoNumb ){     // do not update anymore

                                TVA.log('[playerView] [updateRelatedVideoList] startThumbId: ' + this.startThumbId);
                                TVA.log('[playerView] [updateRelatedVideoList] thumbId: ' + this.thumbId);
                                return
                        }
                        else{
                            
                                this.startThumbId++;
                                TVA.log('[playerView] [updateRelatedVideoList] startThumbId: ' + this.startThumbId);
                                TVA.log('[playerView] [updateRelatedVideoList] limitStartVideoNumb: ' + limitStartVideoNumb);
                                TVA.log('[playerView] [updateRelatedVideoList] thumbId: ' + this.thumbId);                                

                                if (this.startThumbId > limitStartVideoNumb ){ 
                                        
                                        return
                                }else{
                                        TVA.log('[infoBar] [updateRelatedVideoList] ELSE: ' );
                                    
                                        for (var i = 0, j= this.startThumbId; i < this.thumbsLength; i++, j++){ 

                                                // update images
                                                this.$el_relThumbImage           =  $('#relvideo_thumb'+i+' div.video_thumb img');
                                                this.$el_relThumbImage.attr('src',  this.categoryThumbImageUrl(this.relVideosData[j][2]));
                                                
                                                // update strings
                                                this.$el_descriptionText        =  $('#relvideo_thumb'+i+' div.video_description p');
                                                this.$el_durationText           =  $('#relvideo_thumb'+i+' div.video_duration p');
                                                this.$el_descriptionText.html(this.relVideosData[j][1]);
                                                this.$el_durationText.html(this.relVideosData[j][4]);
                                             
                                                // hide btn down when last thumb focused:
                                                if(this.startThumbId == limitStartVideoNumb){
                                                        this.$el_btnDown =  $('div.videorelated_arrow_dwn img');
                                                        this.$el_btnDown.css("display","none");
                                                }
                            
                                        }
                                }
                                        
                        }
                            
                }
                else if (direction == 'up'){
                    
                        if (this.startThumbId == 0 ){ 

                                TVA.log('[playerView] [updateCategoryNavigation] startThumbId: ' + this.startThumbId);
                                TVA.log('[playerView] [updateCategoryNavigation] thumbId: ' + this.thumbId);
                                return
                        }
                        else{

                                TVA.log('[playerView] [updateCategoryNavigation] startThumbId: ' + this.startThumbId);
                                TVA.log('[playerView] [updateCategoryNavigation] thumbId: ' + this.thumbId);
                                this.startThumbId--;
  
                                for (var i = 0, j= this.startThumbId; i < this.thumbsLength; i++, j++){ 

                                        
                                        // update images
                                                this.$el_relThumbImage           =  $('#relvideo_thumb'+i+' div.video_thumb img');
                                                this.$el_relThumbImage.attr('src',  this.categoryThumbImageUrl(this.relVideosData[j][2]));
                                                
                                        // update strings
                                                this.$el_descriptionText        =  $('#relvideo_thumb'+i+' div.video_description p');
                                                this.$el_durationText           =  $('#relvideo_thumb'+i+' div.video_duration p');
                                                this.$el_descriptionText.html(this.relVideosData[j][1]);
                                                this.$el_durationText.html(this.relVideosData[j][4]);
                                                
                                        // show button down
                                                this.$el_btnDown =  $('div.videorelated_arrow_dwn img');
                                                this.$el_btnDown.css("display","block");

                       
                                }
                        
                        }
           
                }
       
        },
        
        updateRelatedVideoList: function (direction) {

            // id of the last video to be displayed topmost:
            var limitStartVideoNumb = this.numberOfRelVideos - this.thumbsLength;

            if (direction == 'down') {

                if (this.startThumbId == limitStartVideoNumb) {
                    // do not update anymore

                    TVA.log('[playerView][updateRelatedVideoList] startThumbId: ' + this.startThumbId);
                    TVA.log('[playerView][updateRelatedVideoList] thumbId: ' + this.thumbId);
                    
                    return
                } else {
                                        

                    this.startThumbId++;
                    TVA.log('[playerView][updateRelatedVideoList] startThumbId: ' + this.startThumbId);
                    TVA.log('[playerView][updateRelatedVideoList] limitStartVideoNumb: ' + limitStartVideoNumb);
                    TVA.log('[playerView][updateRelatedVideoList] thumbId: ' + this.thumbId);


                    if (this.startThumbId > limitStartVideoNumb) {

                        return
                    } else {
                        TVA.log('[infoBar][updateRelatedVideoList] ELSE: ');


                            for (var i = 0, j= this.startThumbId; i < this.thumbsLength; i++, j++) {

                                    // update images
                                    this.$el_relThumbImage =  $('#relvideo_thumb'+i+ 'div.video_thumb img');

                                    this.$el_relThumbImage.attr('src', this.categoryThumbImageUrl(this.relVideosData[j][2]));

                                    // update strings
                                    this.$el_descriptionText = $('#relvideo_thumb' + i + ' div.video_description p');
                                    this.$el_durationText = $('#relvideo_thumb' + i + ' div.video_duration p');

                                    this.$el_descriptionText.html(this.relVideosData[j][1]);

                                    this.$el_durationText.html(this.relVideosData[j][4]);

                                    // hide btn down when last thumb focused:
                                    if (this.startThumbId == limitStartVideoNumb) {
                                        this.$el_btnDown = $('div.videorelated_arrow_dwn img');
                                        this.$el_btnDown.css("display", "none");
                                        
                                        this.$el_btnDownSel = $('div.videorelated_arrow_dwn_sel');
                                        this.$el_btnDownSel.css("visibility", "hidden");

                                        $('div.videorelated_arrow_up img').css("display", "block");
                                        $('div.videorelated_arrow_up img').css("visibility", "visible");

                                    }

                                    // SHOW THE ARROW UP

                                    if (this.startThumbId < limitStartVideoNumb) {
                                        this.$el_btnUp = $('div.videorelated_arrow_up  img');
                                        this.$el_btnUp.css("display", "block");
                                        this.$el_btnUp.css("visibility", "visible");
                                        $('div.videorelated_arrow_up img').css("visibility", "visible");

                                    }

                        }
                    }

                }

            } else if (direction == 'up') {

                if (this.startThumbId == 0) {

                    TVA.log('[playerView][updateCategoryNavigation] startThumbId: ' + this.startThumbId);
                    TVA.log('[playerView][updateCategoryNavigation] thumbId: ' + this.thumbId);
                    return
                } else {

                    TVA.log('[playerView][updateCategoryNavigation] startThumbId: ' + this.startThumbId);
                    TVA.log('[playerView][updateCategoryNavigation] thumbId: ' + this.thumbId);
                    this.startThumbId--;

                    for (var i = 0, j = this.startThumbId; i < this.thumbsLength; i++, j++) {


                        // update images
                        this.$el_relThumbImage = $('#relvideo_thumb' + i + ' div.video_thumb img');

                        this.$el_relThumbImage.attr('src',
                        this.categoryThumbImageUrl(this.relVideosData[j][2]));

                        // update strings
                        this.$el_descriptionText = $('#relvideo_thumb' + i + ' div.video_description p');
                        this.$el_durationText = $('#relvideo_thumb' + i + ' div.video_duration p');

                        this.$el_descriptionText.html(this.relVideosData[j][1]);

                        this.$el_durationText.html(this.relVideosData[j][4]);

                        // show button down
                        this.$el_btnDown = $('div.videorelated_arrow_dwn img');

                        this.$el_btnDown.css("display", "block");

                        // SHOW THE ARROW UP

                        if (this.startThumbId == 0) {
                            
                            this.$el_btnUp = $('div.videorelated_arrow_up img');
                            this.$el_btnUp.css("visibility", "hidden");

                            this.$el_btnUpSel = $('div.videorelated_arrow_up_sel');
                            this.$el_btnUpSel.css("visibility", "hidden");
                        }

                    }

                }

            }

        },
        
        getFocusedId: function(){
            
                if (this.focusedID == null) {
                        return this.thumbName + this.thumbId;
                }
                else{
                        return this.focusedID;
                }  
        },
        
        /* Set focus to first thumb */
        resetFocus: function(){
                this.thumbId = 0;
                this.focusedID = this.thumbName + this.thumbId;
                this.navigationSelected = this.navigationIds.relatedVideos;
                this.$el_play_button = $('#play_button_over');
                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
   
        },
        
        resetPlayBtn: function(){
            
                if (this.navigationSelected == this.navigationIds.player && this.controlSelected == this.controlIds.play ){
            
                        this.$el_play_button = $('#play_button_over');
                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');
                }
                else{
                    
                        this.$el_play_button = $('#play_button_over');
                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                    
                }

                this.resetProgress();
                $('.videobackground').show();
        },

        
        setPlayBtn : function(playerStatus) {
            
                TVA.log('playerStatus: ' + playerStatus);
                if (this.navigationSelected == this.navigationIds.player){
                    
                        // if paused:
                        if (playerStatus == 2){
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause02.png") no-repeat left top');

                        }
                        // if playing:
                        else if (playerStatus == 1) {
                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');

                        }
                    
                }

        },
        
   
        categoryThumbImageUrl: function(thumbUrl){
            
                return CONFIG.hollybyteBaseUrl + thumbUrl;

        },
        
        getFullscreenFlag: function(){
            
                return this.fullscreenFlag;
        },
        
        offFocusBackButton : function(){
            
                TVA.offFocus('player_back_btn');
        }
   
};
