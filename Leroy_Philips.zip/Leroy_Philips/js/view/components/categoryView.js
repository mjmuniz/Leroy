window.CategoryView = CategoryView = {
	
	header :    '<div class="head_wrapper">' +
                            '<div class="lm_logo"></div>' +
                            '<div class="head_text">' +
                                    '<span>El canal de ideas<br> y consejos para tu casa</span>' +
                            '</div>' +
                            '<div class="head_subtext">Inicio > <span class="category_name"></span></div>' +
                    '</div>',
	
	thumblist :         // BUTTON BACK
        
                            '<div id="btn_back_cw_anchor" ></div>'+
 
                            '<div id="catgBackButton" class="btn_backtostart_catview">' + 
                                    '<div class="btn_backtostart_slice_l_catview"></div>' +
                                    '<div class="btn_backtostart_slice_c_catview" onclick="Main.magicCtrView2VolverInicio()" onmouseover="Main.magicCtrGeneralMouseOver(this, true, null, 2)">Volver al inicio</div>' +
                                    '<div class="btn_backtostart_slice_r_catview"></div>' +
                            '</div>' +

                            //BUTTON LEFT
                            '<div id="videogrid-arrow-l" class="catg_view_btn_prev" onmouseover="Main.magicCtrView2ArrMouseOver(\'prev\')"></div>' +
                            '<div class="catg_view_btn_prev_sel" onclick="Main.magicCtrView2ArrowClick(\'prev\')" onmouseout="Main.magicCtrView2ArrMouseOut(\'prev\')" ></div>' +

                            //BUTTON RIGHT
                            '<div id="videogrid-arrow-r" class="catg_view_btn_next" onmouseover="Main.magicCtrView2ArrMouseOver(\'next\')"></div>' +
                            '<div class="catg_view_btn_next_sel" onclick="Main.magicCtrView2ArrowClick(\'next\')" onmouseout="Main.magicCtrView2ArrMouseOut(\'next\')" ></div>' +
                                    
                            //VIDEO THUMBS LIST
                            '<div class="videolist_wrapper">' + 
                                    
                                    '<div id ="thumblist_anchor"></div>' + 

                            '</div>'+
                        
                            '<div class="pagination_wrapper">' +
                                    '<div id ="pagination_anchor"></div>' + 
                            '</div>',
	
	detailbox : '<div class="detailview_wrapper">' +
	
                        '<img id="video_splash">' +
	
                        '<div class="detailview_text_wrapper">' +
                                '<div class="detailview dv_head_text">' +
                                        '<span>Aprende Cómo</span>' +
                                '</div>' +
                                '<div class="detailview dv_title_text">' +
                                        '<span class="category_name"></span>' +
                                '</div>' +
	
                                '<div class="detailview dv_description_text">' +
                                        '<span class="category_name"></span></div>' +
                                '</div>' +
                        '</div>' +
                    '</div>',
                
        popup :     '<div id="popup" class="popup_wrap" onclick="Main.magicCtrView2PopupClick()">' +  
            
                            '<div class="popup_text"> Ups! Esta categoría no tiene vídeos. Estamos trabajando para darte las mejores ideas y consejos.<br>Vuelve pronto.</div>' +
            
                    '</div>',
	
	el : '#categoryView',
	focusedID : null,
	thumbName : 'video_thumb',
	thumbId : 0,
        
        // Id of current thumblist page
        thumblistPageId : 0,
        
        // Maximal number of thumbs in List
        maxNoOfThumbsInList : 9,
        
        // Current number of thumbs in List
        currentNoOfThumbsInList : null,
        
        // Number of thumbnails in a row
	thumbsInRow : 3,
        
	catgVideos : null,
	
	render : function (el) {
		el = $(el || '#categoryView');
                this.hide();
		el.append(this.header);
		el.append(this.thumblist);
		el.append(this.detailbox);
		this.setBackground();
                this.fixPhilipsButton_cw();
	},
	
	hide : function () {
		$('#categoryView').hide();
	},
	
	isVisible : function () {
		return $(this.el).is(':visible');
	},
        
        fixPhilipsButton_cw: function(){
            
                if ( settings.device == 'philips'){
                        var phButton =
                        '<div class="btn_backtostart_catview">' + 
                                    '<div class="btn_backtostart_slice_l_catview"></div>' +
                                    '<div class="btn_backtostart_slice_c_catview">Volver al inicio</div>' +
                                    '<div class="btn_backtostart_slice_r_catview"></div>' +
                        '</div>';
                }
                
                $('#btn_back_cw_anchor').append(phButton);
        },
        	
	show : function (title, data) {
            
                // if blank category, show blank page:
                if(! data || data.length == 0){
                        TVA.log('[categoryView] [show] data.length == 0 ');
                        this.setHeaderText(title);
                        $('div.detailview_wrapper').hide();
                        // remove thumblist if exists
                        if ($('#videolist_wrapper_rem').length != 0) {
                                $('#videolist_wrapper_rem').remove();
                        }
                        $('#categoryView').show();
                        $('#videogrid-arrow-r').hide(); 
                        $('#videogrid-arrow-l').hide();
                        if ($('#pagination_wrapper_rem').length != 0) {
                                $('#pagination_wrapper_rem').remove();
                        }
                        //this.focusBackButton();
                        
                        if ($('#popup').length == 0) {
                                var el = $('#categoryView');
                                el.append(this.popup);
                        }
                        
                }
                else
                {
                        TVA.log('[categoryView] [show] data.length > 0 ');
                        if ($('#popup').length != 0) {
                                $('#popup').remove();
                        }
            
                        this.catgVideos = data;
                        this.thumblistPageId = 0;
                        this.setHeaderText(title);

                        // Generate the video List
                        this.generateVideoThumblist();

                        // Generate pagination bullets
                        this.generatePagination();
                        
                        // Show detail box hidden by blank category
                        $('div.detailview_wrapper').show();
                        
                        // Set detaibox content
                        this.setDetailboxContent(this.catgVideos);

                        $('#categoryView').show();
                        
                        // Truncate text in thumbnail, add 3 ellipsis respectively
                        for (var i = 0; i < this.getNoOfThumbs(); i++){
                            TVA.log("Tuncate loop for i=" + i + " start")
                            truncate($("#titlewrapId" + i)); 
                            this.$element = $("#titlewrapId" + i);
                            this.$element.css('height', '54px');
                        }

                        if(this.getNoOfThumbs() == 0){
                                this.focusBackButton();
                        }  
                }
		
	},
        
        showBackground: function(){
                
                $('#categoryView').show();
                
                // remove popup
                if ($('#popup').length != 0) {
                                $('#popup').remove();
                }
                
                // remove thumblist if exists
                if ($('#videolist_wrapper_rem').length != 0) {
                        $('#videolist_wrapper_rem').remove();
                }
                $('#videogrid-arrow-r').hide(); 
                $('#videogrid-arrow-l').hide();
                
                // remove pagination
                if ($('#pagination_wrapper_rem').length != 0) {
                        $('#pagination_wrapper_rem').remove();
                }
                
                $('div.detailview_wrapper').hide();
            
        },

        setBackground : function () {
		this.$el_category_view = $('#categoryView');
		this.$el_category_view.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
		
	},
        
        generateVideoThumblist : function () {
            
                // remove thumblist if exists
		if ($('#videolist_wrapper_rem').length != 0) {
			$('#videolist_wrapper_rem').remove();
		}
                
                var count = this.getNoOfThumbs();
                TVA.log ('[generateVideoThumblist] count: '+ count);
		var videoNavigation = '<div id="videolist_wrapper_rem">';   // handle for removing former list

                TVA.log ('[generateVideoThumblist] getFirstThumbIndex: '+ this.getFirstThumbIndex());
                var i, j;
		for (i = 0, j = this.getFirstThumbIndex() ; i < count; i++, j++) {        
                        var videoTitle      = this.catgVideos[j][1];
			var videoTitleShort = this.catgVideos[j][2];                        
			var videoSplash     = this.catgVideos[j][4];
			var videoDuration   = this.catgVideos[j][6];
			var videoSplashUrl  = CONFIG.hollybyteBaseUrl + videoSplash;
			var videoThumbItem  = this.renderVideoThumb({btnId : i,titleshort : videoTitle,videosplash : videoSplashUrl,duration : videoDuration});
			videoNavigation += videoThumbItem;
		}
		videoNavigation += '</div>';
		$('#thumblist_anchor').append(videoNavigation);
                
                // HIDE LEFT ARROW ICON IF YOU ARE NOT IN THE FIRST PAGE SET
                if(this.thumblistPageId > 0) {
                    $('#videogrid-arrow-l').show();            
                }
                // HIDE RIGHT ARROW ICON IF YOU ARE IN THE LATEST SET
                var numberOfPages = Math.ceil(this.catgVideos.length / this.maxNoOfThumbsInList) - 1;
                if (this.thumblistPageId == numberOfPages) {
                    $('#videogrid-arrow-r').hide(); 
                }
                
                // SHOW RIGHT ARROW
                if (this.thumblistPageId < numberOfPages) {
                        $('#videogrid-arrow-r').show(); 
                }
                
                // HIDE LEFT ARROW
                if(this.thumblistPageId == 0) {
                        $('#videogrid-arrow-l').hide();            
                }
                                

	},

	renderVideoThumb : function (opt) {
		return '<div id="video_thumb' + opt.btnId + '" class="video_thumb_wrapper" onclick="Main.magicCtrView2ThubnailReturn(' + opt.btnId + ')" onMouseOver="Main.magicCtrView2VideoThumbMouseOver(this)">' +
		'<div class="video_thumb">' +
		'<img src="' + opt.videosplash + '">' +
		'</div>' +
		
		'<div class = "video_description">' +
                    '<div id="titlewrapId'+ opt.btnId +'" class="title_wrap">'+opt.titleshort+'</div>'+
		'</div>' +
		
		'<div class="video_duration">' +
                    '<p>' + opt.duration + '</p>' +
		'</div>' +
		'<div class="play_btn"></div>' +
		
		'<div class="item_focus"></div>' +
		'</div>';
	},
        
        // Get index of first thumb according to page order
        getFirstThumbIndex : function(){
            
                return this.thumblistPageId * this.maxNoOfThumbsInList;
        },
        
        getCurrentThumbIndex : function(){
            
                return parseInt(this.thumblistPageId * this.maxNoOfThumbsInList) + parseInt(this.thumbId);
        },
        
        getNoOfThumbs : function(){
            
                if  ( (this.catgVideos.length - this.getFirstThumbIndex()) > this.maxNoOfThumbsInList){
                
                            return this.maxNoOfThumbsInList;
                    }
                else
                    {
                            return this.catgVideos.length - this.getFirstThumbIndex();
                    }
            
        },
        
        getCurrentNoOfThumbsInList :function(){
            
        },
        
        // Set ID of thumblist page to be viewed
        getThumblistPageId : function(){
            
                
                return this.thumblistPageId;  
        },
        
        generatePagination : function(){
            
                var noOfPages = Math.ceil(this.catgVideos.length / this.maxNoOfThumbsInList);
                TVA.log('noOfPages: ' + noOfPages);
                
                // remove pagination if exists
                if ($('#pagination_wrapper_rem').length != 0) {
                        $('#pagination_wrapper_rem').remove();
                }
                if ( noOfPages > 1 ){

                        var paginationElm = '<div id="pagination_wrapper_rem">'+   // handle for removing former element
                                                '<div class="pagination">';
                        for (var i = 0 ; i < noOfPages; i++) {  

                                var bulletState = (i == this.thumblistPageId) ? 'current' : 'no_current';
                                var paginationBullet  = this.renderPaginationBullets(bulletState);
                                paginationElm += paginationBullet;
                        }
                        paginationElm +=        '</div>'+
                                            '</div>';
                        $('#pagination_anchor').append(paginationElm); 
                }    
        },
        
        renderPaginationBullets : function(state){
            
                return '<div class ="pagination_' + state + '"></div>';
            
        },
	
	setStrings : function () {},
	
	setDetailboxContent : function (data) {
                
                var id = this.getCurrentThumbIndex();
		
		var videoTitleShortDetails = (data.length == 0)?'N/A':(typeof data[id][2] == 'undefined')?'N/A':data[id][2];
		var videoDescriptionDetails = (data.length == 0)?'N/A':(typeof data[id][8] == 'undefined')?'N/A':data[id][8];

		var videoSplash = (data.length == 0)?'':(typeof data[id][4] == 'undefined')?'':data[id][4];
		var videoSplashUrl = CONFIG.hollybyteBaseUrl + videoSplash;
		
		this.$el_splashImage = $('#video_splash');
		this.$el_splashImage.attr('src', videoSplashUrl);
		
		this.$el_titleText = $('div.detailview_text_wrapper div.dv_title_text span');
		this.$el_titleText.html(videoTitleShortDetails);
		
		this.$el_descriptionText = $('div.detailview_text_wrapper div.dv_description_text span');
		this.$el_descriptionText.html(videoDescriptionDetails);
		
	},
	
	setHeaderText : function (category) {
		this.$el_catgText = $('div.head_wrapper div.head_subtext span.category_name');
		this.$el_catgText.html(category);
	},
	
	moving : function (direction) {
		switch (direction) {
		case 'right':
			this.moveRight();
			break;
		case 'left':
			this.moveLeft();
			break;
		case 'up':
			this.moveUp();
			break;
		case 'down':
			this.moveDown();
			break;
		}
	},
	
	moveRight : function () {
            
                var numOfThumbs = this.getNoOfThumbs();
		if(numOfThumbs == 0){
			this.focusBackButton();
		}
		else{
	            if (this.focusedID == 'catgBackButton' ){
	                this.offFocus('catgBackButton');
	                this.setFocus(this.thumbName + this.thumbId);
	        }
	        else{
	                var nofthumbs = this.getNoOfThumbs();
	    
	                if (this.thumbId < this.getNoOfThumbs() - 1) {
	                        this.offFocus(this.thumbName + this.thumbId);
	                        this.thumbId++;
	                        this.setFocus(this.thumbName + this.thumbId);
	                        this.displayPlayButton();
	                        this.setDetailboxContent(this.catgVideos);
	                        TVA.log('[categoryView] [moveRight] this.thumbId: ' + this.thumbId);
	                }
	                else if (this.thumbId == this.maxNoOfThumbsInList -1 && ((this.thumbId + 1)  * (this.thumblistPageId + 1))  < this.catgVideos.length ){  // Create next list if current thumb not last of all videos
                                var lastThumbId = this.thumbId;
	                        this.thumbId = 0;
	                        this.thumblistPageId++;
                                this.generateVideoThumblist();
                                this.generatePagination();
                                this.offFocus(this.thumbName + lastThumbId );
                                TVA.log('[categoryView] [moveRight] this.thumbId: ' + this.thumbId);
                                this.setFocus(this.thumbName + this.thumbId);
                                this.displayPlayButton();
                                this.setDetailboxContent(this.catgVideos);	                           
	                }
	            
	        }
		}
	},
	
	moveLeft : function () {
		if(this.getNoOfThumbs() == 0){
			this.focusBackButton();
		}
		else{
			if (this.thumbId > 0) {
				this.offFocus(this.thumbName + this.thumbId);
				this.thumbId--;
				this.setFocus(this.thumbName + this.thumbId);
				this.displayPlayButton();
				this.setDetailboxContent(this.catgVideos);
				TVA.log('[categoryView] [moveleft] this.thumbId: ' + this.thumbId);
			}
	                else if( this.thumbId == 0 && this.thumblistPageId > 0 ){   // Create preceeding list 
	                    
	                        var lastThumbId = this.thumbId;
	                        this.thumbId = this.maxNoOfThumbsInList -1;
	                        this.thumblistPageId--;

                                this.generateVideoThumblist();
                                this.generatePagination();
                                this.offFocus(this.thumbName + lastThumbId );
                                TVA.log('[categoryView] [moveLeft] this.thumbId: ' + this.thumbId);
                                this.setFocus(this.thumbName + this.thumbId);
                                this.displayPlayButton();
                                this.setDetailboxContent( this.catgVideos);
	                         
	                }
	                else if (this.thumbId == 0 && this.thumblistPageId == 0){
	                	this.focusBackButton();
	                }
		}
	},
	
	moveUp : function () {
		if(this.getNoOfThumbs() == 0){
			this.focusBackButton();
		}
		else{
			if (this.thumbId > this.thumbsInRow -1) {
				this.offFocus(this.thumbName + this.thumbId);
				this.thumbId = this.thumbId - this.thumbsInRow;
				this.setFocus(this.thumbName + this.thumbId);
				this.displayPlayButton();
				this.setDetailboxContent(this.catgVideos);
				TVA.log('[categoryView] [moveUp] this.thumbId: ' + this.thumbId);
			}
	                else if (this.thumbId == 0){
	                        
	                        this.focusBackButton();
	                }
		}
	},
	
	moveDown : function () {
		if(this.getNoOfThumbs() == 0){
			this.focusBackButton();
		}
		else{
                if (this.focusedID == 'catgBackButton' ){
                        this.offFocus('catgBackButton');
                        this.setFocus(this.thumbName + this.thumbId);
                }
                else if (this.thumbId < this.maxNoOfThumbsInList - this.thumbsInRow && (this.thumbId + this.thumbsInRow < this.getNoOfThumbs())) {
                        this.offFocus(this.thumbName + this.thumbId);
                        this.thumbId = this.thumbId + this.thumbsInRow;
                        this.setFocus(this.thumbName + this.thumbId);
                        this.displayPlayButton();
                        this.setDetailboxContent(this.catgVideos);
                        TVA.log('[categoryView] [moveDown] this.thumbId: ' + this.thumbId);
                }
		}
	},
	
	focusBackButton: function(){
        TVA.log('FOCUS BACK BTN, this.thumbId: ' + this.thumbId);
        this.offFocus(this.thumbName + this.thumbId);
        this.setFocus('catgBackButton');		
	},
	
	offFocus : function (id) {
		if (id) {
			TVA.offFocus(id);
		}
	},
	
	offFocusCategoryView : function () {
		TVA.offFocus(this.thumbName + this.thumbId);
	},
	
	offHover : function (id) {
		if (id) {
			TVA.offHover(id);
		}
	},
	
	setFocus : function (id) {
		//this.offHover(this.hoveredID);
		this.offHover(id);
		TVA.setFocus(id);
		this.focusedID = id;
	},
	
	showInfobar : function () {
		TVA.log('[categoryView] [showInfobar] ');
		$('#categoryView').hide();
		$('#infoBar').show();
	},
	
	displayPlayButton : function () {
		this.$el_play_btn_offFoc = $('div.video_thumb_wrapper div.play_btn');
		this.$el_play_btn_offFoc.css('display', 'none');
		this.$el_play_btn = $('div.focus div.play_btn');
		this.$el_play_btn.css('display', 'block');
	},
	
	getFocusedId : function () {
		
		if (this.focusedID == null) {
			return this.thumbName + this.thumbId;
		} else {
			return this.focusedID;
		}
	},
	
	/* Set focus to first thumb */
	resetFocus : function () {
		this.thumbId = 0;
		this.focusedID = this.thumbName + this.thumbId;
	},
        
        getMaxNoOfThumbsInList : function (){
            
            return this.maxNoOfThumbsInList;
        }
	
};
