<?php
/*
 * in JavaScript call with `encodeURIComponent`
 * $.get('proxy.php?proxy_url='+encodeURIComponent('http://google.com?param=1&param2=2'))
 */ 
$url = rawurldecode($_GET['proxy_url']);
$cb = ! empty($_GET['callback']) ? $_GET['callback'] : null;

if(preg_match('#nettv\.mautilus\.com/merlin/#', $url)){
    $url = preg_replace('#http\://nettv\.mautilus\.com/merlin/#', '', $url);
}

if(! preg_match('#^https?:#', $url)){
    $url = preg_replace('#^[\.\/]+#', '', $url);
    
    if(!file_exists($url)){
        echo 'File not found';
        die(0);
    }
}

if(preg_match('#\.xml$#', $url)){
    header('Content-type: text/xml');
}

$file = file_get_contents($url);

if($cb){
    header('Content-type: application/javascript');
    echo $cb.'('.$file.');';
    
}else{
    echo $file;
}