//SET GLOBAL SETTINGS THAT ARE USED THROUGHOUT THE APP
var settings = {
    device:'',
    year:'',
    lang:{},
    homepage:'homePage',
    setFocusOnBack:true
};