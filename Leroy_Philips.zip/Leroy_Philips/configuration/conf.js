CONFIG = {
  //  Configuration version 
  //  If the application version as the one in the configuration, then it is re-loaded
  //  from assets and rewrites the user data
  version: '0.248',
	
  // 	Language
  // 	If it is not specified, then the default language is saved here upon application startup 
  // 	If cookie is set, this language is not set
  language: 'es',
	
  // Dis/enabling showing debug info (version, etc.)
  showDebugInfo: true,
	
  // Logs dis/enabling
  enabledLogs: false,
  
  //  Debug type
  //   0 only console.log
  //   1 only in debug window
  //   2 both
  typeLogs: 0,
	
  // Logs dis/enabling time stamp
  timeZone: 0,

  // How often should app ask for time? (in seconds)
  timer: 60,
		
  // Set, if Magic motion/mouse is enabled
  enableMouse: true,
  
  // proxy url for cross domain requests
  // proxyURL: 'http://nettv.mautilus.com/merlin/proxy-jsonp.php?proxy_url=',
  proxyURL: 'http://www.lmserver.es/smarttv/proxy-jsonp.php?proxy_url=',
  
  // Hollybyte base URL
  hollybyteBaseUrl : 'http://s3-eu-west-1.amazonaws.com/repo.eu-w1.hollybyte.com/',
  googleAnalytics: 'MO-39022899-2',
  gaPhp: 'http://www.lmserver.es/smarttv/ga.php'
};
window.CONFIG = CONFIG;