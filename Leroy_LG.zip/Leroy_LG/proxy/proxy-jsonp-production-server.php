<?php
//Header('Content-Type: application/javascript');
/*
 * in JavaScript call with `encodeURIComponent`
 * $.get('proxy.php?proxy_url='+encodeURIComponent('http://google.com?param=1&param2=2'))
 */

ini_set('display_errors', 1);
error_reporting(0);

$url = stripslashes(rawurldecode($_GET['proxy_url']));
$cb = !empty($_GET['callback']) ? $_GET['callback'] : null;

if (preg_match('#nettv\.mautilus\.com/merlin/#', $url)) {
    $url = preg_replace('#http\://nettv\.mautilus\.com/merlin/#', '', $url);
}

if (!preg_match('#^https?:#', $url)) {
    $url = preg_replace('#^[\.\/]+#', '', $url);

    if (!file_exists($url)) {
	echo 'File not found';
	die(0);
    }
}

if (preg_match('#\.xml$#', $url)) {
    header('Content-type: text/xml');
}

$opts = array(
    'http' => array('ignore_errors' => true)
);

$file = file_get_contents($url, false, stream_context_create($opts));

if ($cb) {
    header('Content-type: application/javascript');
    
    if(! preg_match('/^\s?(\{|\[)/', $file)){
	$file = '\''.$file.'\'';
    }
    
    echo $cb . '(' . $file . ');';
} else {
    echo $file;
}
