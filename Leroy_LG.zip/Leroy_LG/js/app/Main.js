//SET MAIN NAMESPACE
var Main = {
    infobar: InfoBar,
    categoryView: CategoryView,
    playerView: PlayerView,
    categoryListView: CategoryListView,
    playbackUI: PlaybackUI,
    player: Player,
    footer: Footer,
    lang: null,
    catgNavigData: [],
    /*catgNavigDataHistory: undefined,*/ /* MILANO*/
    catgNavigDataHistory: [],
    seasonalContentData: [],
    catgVideos: [],
    relatedVideosData: [],
    catgAlphabetData : [],
    catgListCache: [], // Test
    activeViews: {
        homeView : 'infoBar', 
        categoryView : 'categoryView', 
        playerView : 'playerView', 
        categoryListView :'categoryListView',
        aTuCasaLeToca    : 'aTuCasaLeToca'
    },        
    activeView: null,
    alphabetQueryLength : 1,
    pageHistory : [],
    networkerror: false,
    preloadFlag : true,
    activeCatgView: 1,
    suspendKeys: false,
    suspend: false,
    timeoutHandle: null,
    puiVisible: false,

    urlToGetToken : 'https://api.hollybyte.com/oauth/token?grant_type=client_credentials&client_id=leroymerlin.ro&client_secret=8b6f23d849b7f0c553de58a1235d4b266e33c702',

    onLoad: function()
    {
        // Google Analytic integration
        TVA_GoogleAnalytics.init(CONFIG.googleAnalytics, CONFIG.gaPhp);
        TVA_GoogleAnalytics.analyticMark('device', TVA.device);
        
        //SET THE DEVICE TYPE FOR FUTURE REFERENCE E.G. SAMSUNG, LG ETC
        settings.device = TVA.device.toLowerCase();

        var whatTv = TVA.device.toLowerCase();
        console.log(whatTv);
        if (whatTv == 'samsung') {
        	document.body.onkeydown = function () {
        		console.log('do nothing');	
        	};
        }   
         
        //INITIALISE THE TVA MODULE
        if(settings.device == 'samsung' || settings.device == 'googletv'){
                TVA.init({
                        debug:CONFIG.enabledLogs, 
                        connectionCheck: true
                });
        }
        this.initZoom();
        if(!CONFIG.enabledLogs){
            $('#debugWindow').hide();
        }
        this.setPlatform();
        this.lang = Es;
        this.setDisconnectionPopupText(this.lang);
        
        //SET THE INITIAL PAGE FOR THE HISTORY
        this.pageHistory[0] = this.activeViews.homeView,        

        this.loadMainCategoryNavigation();
        
        // preload wheeel for player view:
        $('#preloadWeel').ajaxStart(function(){
            
                    if (Main.preloadFlag){
        
                            if(!$(this).hasClass('playerView')){
                                    this.suspendKeys = true;
                            }
                            $(this).removeClass('playerView');
                            $(this).show();
                    }
        });
         
        // preload wheeel for swapping views
        $('#preload').ajaxStart(function(){
                
                if (Main.preloadFlag){

                        if($(this).hasClass('playerView')){
            
                        this.suspendKeys = true;
                        
                                $('#preload').removeClass('playerView');
                                $('#preload').hide();
                        }        
                }
        });
            
        //Register a handler to be called when all Ajax requests have completed. This is an Ajax Event.
         $('#preload,#preloadWeel').ajaxStop(function(){
        	 if(!$(this).hasClass('playerView')){
        		 this.suspendKeys = false;
                         $(this).hide();
        	 }
         });
    },
    
    unload: function()
    {
        if (TVA.device == 'lg') { 
            TVA.quit(true);
        }
        /*
        if ( settings.device == 'lg'){
            if (TVA_Player) {
                TVA_Player.deinit();
            } 
         
            window.NetCastBack();   
        }
        else{
            TVA.quit(); 
        }
        */
    },

    
    unloadExitLG: function()
    {
        console.log('unloadExitLG');
        if ( settings.device === 'lg'){
            if (TVA_Player) {
                TVA_Player.deinit();
            }   
            window.NetCastExit();
        }
    },
       
    setDisconnectionPopupText: function(lang){
        TVA.popupConnNoTitle    = lang.popupConnNoTitle;
        TVA.popupConnNoText     = lang.popupConnNoText;
        TVA.popupConnBadTitle   = lang.popupConnBadTitle;
    	TVA.popupConnBadText    = lang.popupConnBadText;
        TVA.popupConnBack       = lang.popupConnBack; 
    },

    renderComponents: function(hbdata, hbdata2 )
    {      
        this.infobar.initialize();
        this.infobar.render(hbdata);
        this.infobar.renderSeasonalContent(hbdata2);
        
        this.categoryListView.render();
        
        this.categoryView.render(); 
        
        this.playerView.initialize();
        this.playerView.render();   
        
        this.playbackUI.initialize();
        this.playbackUI.render();
             
        this.footer.render(1);
        this.footer.render(2);
        this.footer.render(3);      
        this.footer.showFooter(1);
        this.footer.hideFooter(2);
        this.footer.hideFooter(3);

        this.activeView = this.activeViews.homeView;
    },
    
    mouseDown: function(){
        if (this.player.getFullscreenFlag() == 1 && this.puiVisible == false   ){
            
            clearTimeout(this.timeoutHandle);       // reset timeout

                // first show it
                this.$el_pui = $('#playbackUI'); 
                this.$el_pui.show();

                //then hide it
                this.timeoutHandle = setTimeout( 
                    function(){
                    this.$el_pui = $('#playbackUI'); 
                    this.$el_pui.hide();
                    }, 
                    3000
                );

                this.puiVisible = false;
        }
        
    },
        


    //FUNCTION TO PROCESS KEYBOARD PRESSES
    //NOTE: IF THE TVA_Input MODULE IS INCLUDED, THIS WILL DEAL WITH A MAJORITY OF KEY PRESSES.  SEE MODULE
    keyDown: function (keycode) {       
        TVA.log('Mautilus keycode = [Main]'+keycode);
        
        if (this.suspend == true || $('#connectionAlert').length != 0){     //  || if second internet connection alert visible
            return;
        }

        if(!TVA.online){
            if(keycode == 461){
                    this.unload();
            }
            return;
        }

        if (settings.device != 'googletv'){
            
            if(this.suspendKeys){
                    return;
            }
        }

        switch(keycode)
        {
            case 37:
                if(this.infobar.isVisible()){
                    this.infobar.moving('left');
                } 
                else if (this.categoryView.isVisible()){
                    this.categoryView.moving('left');
                }
                else if (this.categoryListView.isVisible()){
                    this.categoryListView.moving('left');
                }
                else if (this.playerView.isVisible()){
                    this.player.getPlayerState();
                    this.playerView.moving('left', this.player.status );
                }
                else  if( this.player.getFullscreenFlag() == 1 && this.playbackUI.isVisible()){
                        this.player.getPlayerState();
                        this.playbackUI.moving('left',  this.player.status );         
                }
                break;
            case 39:
                if(this.infobar.isVisible()){
                    this.infobar.moving('right');
                }
                else if (this.categoryView.isVisible()){
                    this.categoryView.moving('right');
                }
                else if (this.categoryListView.isVisible()){
                    this.categoryListView.moving('right');
                }
                else if (this.playerView.isVisible()){
                    this.player.getPlayerState();
                    this.playerView.moving('right', this.player.status);
                }
                else if( this.player.getFullscreenFlag() == 1 && this.playbackUI.isVisible()){
                        this.player.getPlayerState();
                        this.playbackUI.moving('right',  this.player.status );
                }
                break;
                
            case 38:
                if(this.infobar.isVisible()){
                    this.infobar.moving('up');
                }	
                else if (this.categoryView.isVisible()){
                    this.categoryView.moving('up');
                }
                else if (this.playerView.isVisible()){
                    this.player.getPlayerState();
                    this.playerView.moving('up', this.player.status);
                }
                else if (this.categoryListView.isVisible()){
                    this.categoryListView.moving('up');
                }
                break;
                
            case 40:
                if(this.infobar.isVisible()){
                    this.infobar.moving('down');
                }	
                else if (this.categoryView.isVisible()){
                    this.categoryView.moving('down');
                }
                else if (this.playerView.isVisible()){
                    this.player.getPlayerState();
                    this.playerView.moving('down', this.player.status);
                }
                else if (this.categoryListView.isVisible()){
                    this.categoryListView.moving('down');
                }
                break;
                
            case 13:
                
                if(this.infobar.isVisible()){                    
                    
                    // Set Preload Background
                    this.preloadBkgSwap('infoBar');
                                    
                    // Go to Category View 
                    if (this.infobar.navigationSelected == this.infobar.navigationIds.categoryNavig){

                        this.suspend = true;                       
                        this.infobar.hideInfobar();
                        var categoryIndex = this.infobar.getCatgIndex();
                        TVA.log('[Main] [keyDown] [KEY_ENTER] infobar.catgIndex: '+ categoryIndex);
                                                
                        // call for category videos
                        var categoryId = this.catgNavigData[categoryIndex][2];
                        /* MILANO */
                        //this.catgNavigDataHistory =  categoryId;
                        this.catgNavigDataHistory.push(categoryId);
                        
                        TVA.log('[Main] [keyDown] [KEY_ENTER] categoryId: '+ categoryId);
                        this.loadCategoryVideoView(categoryId);
                        
                        this.pageHistory.unshift(this.activeViews.categoryView);
                        
                        for (var i = 0; i < this.pageHistory.length; i++){
                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                        }
             
                    }
                                        
                    // Ver videos Btn
                    else if (this.infobar.navigationSelected == this.infobar.navigationIds.vervideosBtn){
                            this.suspend = true;
                            this.activeView = this.activeViews.aTuCasaLeToca;
                            // FOOTER
                            this.footer.showFooter(2);
                            this.footer.hideFooter(1);
                            this.footer.hideFooter(3);
                            
                            this.infobar.hideInfobar();
                            this.pageHistory.unshift(this.activeViews.aTuCasaLeToca);
                            
                            for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }
                            this.loadCategoryVideoView('atucasaletoca');
                    }
                    // Ver todas Btn
                    else if (this.infobar.navigationSelected == this.infobar.navigationIds.vertodasBtn){
                            this.activeView = this.activeViews.categoryListView;
                            // FOOTER
                            this.footer.showFooter(2);
                            this.footer.hideFooter(1);
                            this.footer.hideFooter(3);
                            
                            this.infobar.hideInfobar();
                            this.pageHistory.unshift(this.activeViews.categoryListView);
                            
                            for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }
                            this.categoryListView.show();
                            this.loadCategoryListViewData(bind(this, this.categoriesAlphabeticCallback) );
                    }                 
                }
                
                else if (this.categoryView.isVisible()){
                    
                    // if back button focused, go Home
                    // else
                    if (this.categoryView.getFocusedId() == 'catgBackButton'){
                            this.resetHistory();
                            this.categoryView.hide();  
                            this.infobar.setFocus( this.infobar.getFocusedId() );
                            $('#infoBar').show();
                            this.activeView = this.activeViews.homeView;
                            this.footer.showFooter(1);
                            this.footer.hideFooter(2);
                            this.footer.hideFooter(3);

                    }
                    // Go back to home from blank category
                    else if( ! this.catgVideos || this.catgVideos.length == 0){
                            TVA.log('BACK TO PREVIOUS');
                            this.pageHistory.shift();
                            for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }

                            switch(this.pageHistory[0]){
                                    case this.activeViews.homeView:
                                            this.categoryView.hide(); 
                                            this.infobar.setFocus( this.infobar.getFocusedId() );
                                            $('#infoBar').show();
                                            this.activeView = this.activeViews.homeView;
                                            this.footer.showFooter(1);
                                            this.footer.hideFooter(2);
                                            this.footer.hideFooter(3);
                                            break;
                                            
                                    case this.activeViews.categoryListView:
                                            this.categoryView.hide(); 
                                            $('#categoryListView').show();
                                            this.activeView = this.activeViews.categoryListView;
                                            this.footer.hideFooter(1);
                                            this.footer.hideFooter(3);
                                            this.footer.showFooter(2);
                                            break;
                            }
                    }
                    else{   // Go to Player View
                            // Set preload background
                            this.suspend = true;
                            this.preloadBkgSwap('categoryView');
                            this.categoryView.offFocusCategoryView();
                            this.categoryView.hide();
                            var focusedVideoId = this.categoryView.getFocusedId();
                            focusedVideoId = focusedVideoId.substr(11,1);

                            if(this.catgVideos.length > 0){
                                var myVideoId = this.catgVideos[focusedVideoId][0];
                                this.loadRelatedVideos(myVideoId, null);
                            }

                            this.pageHistory.unshift(this.activeViews.playerView);
                            for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }                         
                    }
                }
                                
                else if (this.playerView.isVisible()){
                        
                        if (this.playerView.navigationSelected == this.playerView.navigationIds.player){
                            
                                this.player.getPlayerState();
                                var playState = this.player.status;
                                TVA.log('[Main] [keyDown] ENTER this.player.status = ' + this.player.status );
                                TVA.log('[Main] [keyDown] ENTER ' + this.playerView.controlSelected );
                                

                                switch (this.playerView.controlSelected){
                                        // Go to Player View fullscreen
                                        case this.playerView.controlIds.fullscreen:
                                        	this.goFullscreen();
                                                this.playbackUI.show();
                                                this.puiVisible = true;
                                                setTimeout( 
                                                    function(){
                                                    this.$el_pui = $('#playbackUI'); 
                                                    this.$el_pui.hide();
                                                    this.puiVisible = false;
                                                    }, 
                                                    3000
                                                );
                                                break;
                                                
                                        case this.playerView.controlIds.stop:
                                        		this.keyStop();
                                                break;
                                                
                                        case this.playerView.controlIds.play:
                                                TVA.log('[Main] [keyDown] ENTER this.playerView.controlSelected = ' + this.playerView.controlSelected );
                                                if (this.player.status == this.player.state.PLAYING || this.player.status == this.player.state.PAUSED){
                                                        
                                                        this.playerView.setPlayBtn(this.player.status);
                                                        this.keyPause();
                                                }
                                                else if (this.player.status == this.player.state.STOPPED) {

                                                	this.keyPlay();

                                                }
                                                break;                                            
                                }

                        }
                        // Play focused related video
                        else if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos) {
                                this.suspend = true;
                                // play selected related video
                                this.preloadFlag = false;
                                
                                var focusedRelVideoId = this.playerView.focusedID;
                                focusedRelVideoId = focusedRelVideoId.substr(14);
                                TVA.log('[Main] [keyDown]  --->  focusedRelVideoId: ' + focusedRelVideoId);
                                
                                var relVideoId = this.relatedVideosData[focusedRelVideoId][0];
                                TVA.log('[Main] [keyDown]  --->  relVideoId: ' + relVideoId);       

                                var focusedRelatedVideoData = this.relatedVideosData[focusedRelVideoId];
                                this.loadRelatedVideos(relVideoId, focusedRelatedVideoData);
  
                        }
                        // Go back to category view
                        else if (this.playerView.navigationSelected == this.playerView.navigationIds.backButton){
                                    // [Leroy Merlin 0001044]: [Philips] When we press "Volver al inicio", Black screen appear.
                                    this.categoryView.showBackground();
                                    
                                    this.footer.showFooter(2);
                                    this.footer.hideFooter(1);
                                    this.footer.hideFooter(3);

                                    var categoryTitle;
                                    this.playerView.offFocusBackButton();
                                    this.playerView.hide();
                                    
                                    // get title
                                    if ( this.pageHistory[1] == this.activeViews.categoryView){    
                                            categoryIndex = this.infobar.getCatgIndex();
                                            categoryTitle = this.catgNavigData[categoryIndex][0];
                                            this.activeView = this.activeViews.categoryView;
                                    }
                                    else if ( this.pageHistory[1] == this.activeViews.aTuCasaLeToca){        
                                            categoryTitle = 'A tu casa le toca...';
                                            this.activeView = this.activeViews.aTuCasaLeToca;
                                    }
                                    
                                    this.categoryView.show(categoryTitle, this.catgVideos);             
                                    this.categoryView.setFocus( this.categoryView.getFocusedId() );     
                                    this.categoryView.displayPlayButton();   
                                    this.preloadFlag = true;
                                    /*
                                    if (settings.device == 'philips'  || settings.device == 'googletv'){
                                        var content = $('#content');
                                        content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                                    }*/
                                    
                                    this.pageHistory.shift();
                                    for (var i = 0; i < this.pageHistory.length; i++){
                                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                                    }

                        }
                    
                }
                
                else if (this.playbackUI.isVisible()){
                    // TEST
                    this.player.getPlayerState();
                    //var playState = this.player.status;
                        
                        switch (this.playbackUI.controlSelected){
                        case this.playbackUI.controlIds.play:
                                TVA.log('[Main] [keyDown] ENTER this.playbackUI.controlSelected = ' + this.playbackUI.controlSelected );
                                
                                if (this.player.status == this.player.state.PLAYING || this.player.status == this.player.state.PAUSED){
                                        this.playbackUI.setPlayBtn(this.player.status);
                                        this.keyPause();
                                }
                                else if (this.player.status == this.player.state.STOPPED) {
                                        this.keyPlay();
                                }
                                
                                break;
                        case this.playbackUI.controlIds.back:
                                this.playbackUI.controlSelected = 0;
                                this.playbackUI.resetFocus();
                                this.playbackUI.resetProgress();
                                this.playbackUI.hide(); 
                                clearTimeout(this.timeoutHandle);
                                this.goBackFromFullscreen();
                                
                                break;

                        case this.playbackUI.controlIds.stop:
                                        //this.puiStop();
                                TVA_Player.stop();
                                TVA_Player.playPos = 0;
                                this.playbackUI.controlSelected = 0;
                                this.playbackUI.resetFocus();
                                this.playbackUI.resetProgress();
                                this.playbackUI.hide(); 
                                clearTimeout(this.timeoutHandle);
                                this.goBackFromFullscreen();
                    	    		
                                this.playerView.resetPlayBtn();
                                this.playerView.resetProgress();
                                break;
                            
                        case this.playbackUI.controlIds.qmenu:
				TVA_Player.showQMenu();
                                break;	
                        }     
                }
                                
                else if (this.categoryListView.isVisible()){
                                                       
                        this.categoryListView.hide();
			
			if(this.categoryListView.focusedID == 'catListgBackButton'){                          
                            this.pageHistory.shift();
                            for (var i = 0; i < this.pageHistory.length; i++){
                                
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }
                            
                            this.infobar.setFocus( this.infobar.getFocusedId() );
                            $('#infoBar').show();
                            this.activeView = this.activeViews.homeView;
                            this.footer.showFooter(1);
                            this.footer.hideFooter(2);
                            this.footer.hideFooter(3);
			    
			}else{
                            this.suspend = true;
                            this.preloadBkgSwap('categoryView');          
			    var categoryId = this.categoryListView.getCategoryId();
                            /* MILANO */
                            if(this.catgNavigDataHistory) {
                                //this.catgNavigDataHistory = categoryId;
                                this.catgNavigDataHistory.push(categoryId);
                            }
			    this.loadCategoryVideoView(categoryId);

			    this.pageHistory.unshift(this.activeViews.categoryView);
			    for (var i = 0; i < this.pageHistory.length; i++){
					    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
			    }
			} 
                }
                break;


                case 461:
                        if(this.categoryView.isVisible()){
                                       
                                    this.pageHistory.shift();
                                    for (var i = 0; i < this.pageHistory.length; i++){
                                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                                    }
                               
                                    switch(this.pageHistory[0]){
                                                case this.activeViews.homeView:
                                                        this.categoryView.hide(); 
                                                        this.infobar.setFocus( this.infobar.getFocusedId() );
                                                        $('#infoBar').show();
                                                        this.activeView = this.activeViews.homeView;
                                                        this.footer.showFooter(1);
                                                        this.footer.hideFooter(2);
                                                        this.footer.hideFooter(3);
                                                        break;

                                                case this.activeViews.playerView:

                                                        this.suspend = true;                       
                                                        var categoryIndex = this.infobar.getCatgIndex();
                                                        TVA.log('[Main] [keyDown] [KEY_ENTER] infobar.catgIndex: '+ categoryIndex);

                                                        // call for category videos
                                                        var categoryId = this.catgNavigData[categoryIndex][2];
                                                        
                                                        /* MILANO */
                                                        //this.catgNavigDataHistory =  categoryId;
                                                        this.catgNavigDataHistory.push(categoryId);
                                                        
                                                        var viewId = 'cv';
                                                        this.loadHomeCategory(categoryId, viewId );
                                                        break;
                                                        
                                                case this.activeViews.categoryListView:
                                                        this.categoryView.hide(); 
                                                        $('#categoryListView').show();
                                                        this.activeView = this.activeViews.categoryListView;
                                                        this.footer.hideFooter(1);
                                                        this.footer.hideFooter(3);
                                                        this.footer.showFooter(2);
                                                        break;
                                                // if going from A tu casa le toca to category :                
                                                case this.activeViews.categoryView:
                                                        // BUG 23) Home - Category (Armarios) > Video (let it play) > Volver > Return > BLACK SCREEN
                                                        this.categoryView.showBackground();
                                                    
                                                        TVA.log('BACK TO CATEGORY VIEW ');
                                                        this.suspend = true;
                                                            
                                                        var categoryIndex = this.infobar.getCatgIndex();
                                                        TVA.log('categoryIndex: ' + categoryIndex );

                                                        var categoryId = this.catgNavigData[categoryIndex][2];
                                                        TVA.log('categoryId: ' + categoryId );

                                                        this.loadCategoryVideoView(categoryId);
                                                            
                                                        this.activeView = this.activeViews.categoryView;
                                                        this.footer.hideFooter(1);
                                                        this.footer.showFooter(2);
                                                        this.footer.hideFooter(3);
                                                        break;
                                        
                                   }
                        }
                                
                        else if(this.playerView.isVisible()){

                                Main.keyStop();

                                var categoryTitle;

                                this.playerView.offFocusPlayerView();
                                this.playerView.controlSelected = null;
                                this.playerView.hide();
                                // get title                           
                                if ( this.pageHistory[1] == this.activeViews.categoryView){

                                        if ( this.activeCatgView == 1){
                                                var categoryIndex = this.infobar.getCatgIndex();
                                                var categoryTitle = this.catgNavigData[categoryIndex][0];
                                        }
                                        else{ 

                                                var categoryId =  this.categoryListView.getCategoryId();
                                                for(var i in this.catgNavigData){
                                                        if(this.catgNavigData[i][2] == categoryId){
                                                                categoryTitle = this.catgNavigData[i][0];
                                                        }
                                                }
                                        }

                                        this.activeView = this.activeViews.categoryView;
                                        this.footer.showFooter(2);
                                        this.footer.hideFooter(1);
                                        this.footer.hideFooter(3);
                                }
                                else if ( this.pageHistory[1] == this.activeViews.aTuCasaLeToca){
                                        categoryTitle = 'A tu casa le toca...';
                                        this.activeView = this.activeViews.aTuCasaLeToca;
                                        this.footer.showFooter(2);
                                        this.footer.hideFooter(1);
                                        this.footer.hideFooter(3);
                                }
                                
                                if (settings.device == 'philips' || settings.device == 'googletv'){
                                        var content = $('#content');
                                        content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                                        setTimeout(this.preloadImageLoaded(categoryTitle),3000);
                                }
                                else if ( settings.device == 'samsung' || settings.device == 'lg'){
                                        this.categoryView.show(categoryTitle, this.catgVideos);             
                                        this.categoryView.setFocus( this.categoryView.getFocusedId() );     
                                        this.categoryView.displayPlayButton();                                    
                                }
                                this.preloadFlag = true;

                                this.pageHistory.shift();
                                for (var i = 0; i < this.pageHistory.length; i++){
                                        TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                                }
                        }
                                                        
                        // Back from fullscreen
                        else if ( this.player.getFullscreenFlag() == 1 ){

                            // hide PUI on RETURN
                            if (this.playbackUI.isVisible()){
                                this.playbackUI.controlSelected = 0;
                                this.playbackUI.resetFocus();
                                this.playbackUI.hide(); 
                                clearTimeout(this.timeoutHandle);
                                this.goBackFromFullscreen();
                            }
                            else
                                {
                                    this.goBackFromFullscreen();
                                }
                            
                        }
                                
                        else if(this.categoryListView.isVisible()){
                                this.activeCatgView = 1;

                                this.pageHistory.shift();
                                for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                                }

                                switch(this.pageHistory[0]){
                                        case this.activeViews.homeView:
                                                this.categoryListView.hide();
                                                this.infobar.setFocus( this.infobar.getFocusedId() );
                                                $('#infoBar').show();
                                                this.activeView = this.activeViews.homeView;
                                                this.footer.showFooter(1);
                                                this.footer.hideFooter(2);
                                                this.footer.hideFooter(3);
                                                break;

                                        case this.activeViews.categoryView:
                                                /* MILANO */
                                                //this.loadCategoryVideoView(this.catgNavigDataHistory);
                                                if(this.catgNavigDataHistory.length == 1) {
                                                    var prevItem = this.catgNavigDataHistory[this.catgNavigDataHistory.length - 1];
                                                } else {
                                                    var prevItem = this.catgNavigDataHistory[this.catgNavigDataHistory.length - 2]; 
                                                }
                                                this.loadCategoryVideoView(prevItem);
                                                
                                                this.categoryListView.hide();
                                                $('#categoryView').show();
                                                this.categoryView.setFocus(this.categoryView.getFocusedId());
                                                this.categoryView.displayPlayButton();
                                                this.activeView = this.activeViews.categoryView;
                                                this.footer.hideFooter(1);
                                                this.footer.showFooter(2);
                                                this.footer.hideFooter(3);
                                                break;

                                        case this.activeViews.playerView: 
                                                this.suspend = true;                       
                                                var categoryIndex = this.infobar.getCatgIndex();
                                                TVA.log('[Main] [keyDown] [KEY_ENTER] infobar.catgIndex: '+ categoryIndex);

                                                // call for category videos
                                                var categoryId = this.catgNavigData[categoryIndex][2];
                                                TVA.log('[Main] [keyDown] [KEY_ENTER] categoryId: '+ categoryId);
                                                var viewId = 'clv';
                                                this.loadHomeCategory(categoryId, viewId);
                                                break;

                                        case this.activeViews.aTuCasaLeToca:
                                                this.categoryListView.hide();
                                                $('#categoryView').show();
                                                this.activeView = this.activeViews.aTuCasaLeToca;
                                                this.footer.hideFooter(1);
                                                this.footer.showFooter(2);
                                                this.footer.hideFooter(3);
                                                break;
                                }
                        }
                        
                        
			else{
                                        this.unload();
                        }
                        
			break;


                                
            case 405:
                    //if( this.activeView != this.activeViews.categoryListView || !this.playbackUI.isVisible() ){
                    if( this.activeView != this.activeViews.categoryListView ){
                            this.activeCatgView = 4;
                            if(this.infobar.isVisible()) {
                                this.preloadBkgSwap('infoBar');
                             } else {
                                this.preloadBkgSwap('categoryView');     
                             }
                            if(this.activeView == this.activeViews.homeView)      this.infobar.hideInfobar();
                            if(this.activeView == this.activeViews.categoryView)  this.categoryView.hide();
                            if(this.activeView == this.activeViews.aTuCasaLeToca) this.categoryView.hide();      
                            if(this.activeView == this.activeViews.playerView)   
                            {
                                this.playbackUI.controlSelected = 0;
                                this.playbackUI.resetFocus();
                                this.playbackUI.resetProgress();
                                this.playbackUI.hide(); 
                                clearTimeout(this.timeoutHandle);  
                                this.player.fullscreenFlag = 0;
                                this.playerView.hide();
                            }
                            this.activeView = this.activeViews.categoryListView;
                            this.footer.showFooter(2);
                            this.footer.hideFooter(1);
                            this.categoryListView.show();
                            this.loadCategoryListViewData(bind(this, this.categoriesAlphabeticCallback) );

                            this.pageHistory.unshift(this.activeViews.categoryListView);
                            for (var i = 0; i < this.pageHistory.length; i++){
                                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                            }
                    }

                    break;
                                

            case 404:
                
                    //if( this.activeView != this.activeViews.aTuCasaLeToca && !this.playbackUI.isVisible() ){
                    if( this.activeView != this.activeViews.aTuCasaLeToca ){
                        this.preloadBkgSwap('categoryView');
                        
                        this.suspend = true;
			TVA.log('[Main] [keyDown]  [KEY_GREEN] button pressed ');
			if(this.activeView == this.activeViews.homeView)            this.infobar.hideInfobar();
			if(this.activeView == this.activeViews.categoryView)        this.categoryView.hide();
			if(this.activeView == this.activeViews.categoryListView)    this.categoryListView.hide();
			if(this.activeView == this.activeViews.aTuCasaLeToca)       this.categoryView.hide();
                        if(this.activeView == this.activeViews.playerView)         
                        {
                            this.playbackUI.controlSelected = 0;
                            this.playbackUI.resetFocus();
                            this.playbackUI.resetProgress();
                            this.playbackUI.hide(); 
                            clearTimeout(this.timeoutHandle);  
                            this.player.fullscreenFlag = 0;
                            this.playerView.hide();
                        }
                        this.activeView = this.activeViews.aTuCasaLeToca;
                        this.footer.showFooter(2);
                    	this.footer.hideFooter(1);
                        this.categoryView.showBackground();
			this.loadCategoryVideoView('atucasaletoca');
                        
                        this.pageHistory.unshift(this.activeViews.aTuCasaLeToca); 
                        for (var i = 0; i < this.pageHistory.length; i++){
                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                        }
		    }  
                    break;
                                

            case 415:

            	this.keyPlay();
                break;
            case 413:
            	this.keyStop();
            	break;
            case 412:
            	this.player.backward(15);
                break;
            case 417:
            	this.player.forward(15);
                break;
            case 19:
            	this.keyPause(true);
            	break;
            default:
                    //Do nothing;
                    break;
        }
        //Toggle visibility of PlaybackUI
        if (keycode != 461 && keycode != 413  ){
            this.togglePlaybackUI();
        }
    },
    
    togglePlaybackUI: function(){

        if(this.puiVisible == true &&  this.player.getFullscreenFlag() == 1){

            clearTimeout(this.timeoutHandle);       // reset timeout
        
            this.timeoutHandle = setTimeout( 
                function(){
                this.$el_pui = $('#playbackUI'); 
                this.$el_pui.hide();
                }, 
                3000
            );
            this.puiVisible = false;
            
        }
        else if (this.puiVisible == false &&  this.player.getFullscreenFlag() == 1 ){
            
            if (!this.playerView.isVisible()){
                
                clearTimeout(this.timeoutHandle);       // reset timeout

                // first show it
                this.$el_pui = $('#playbackUI'); 
                this.$el_pui.show();

                //then hide it
                this.timeoutHandle = setTimeout( 
                    function(){
                    this.$el_pui = $('#playbackUI'); 
                    this.$el_pui.hide();
                    }, 
                    3000
                );

                this.puiVisible = false;
                
            }

        }

    },
    
    keyStop: function(){
    	if (this.playerView.isVisible() || this.player.getFullscreenFlag() == 1){
            
            if(this.playbackUI.isVisible()){
                TVA_Player.stop();
                TVA_Player.playPos = 0;
                this.playbackUI.controlSelected = 0;
                this.playbackUI.resetFocus();
                this.playbackUI.resetProgress();
                this.playbackUI.hide(); 
                clearTimeout(this.timeoutHandle);
                this.goBackFromFullscreen();
                    	    		
                this.playerView.resetPlayBtn();
                this.playerView.resetProgress();
            }
            else{
                
                if ( this.player.getFullscreenFlag() == 1 ){  
                    this.goBackFromFullscreen();
                }
                TVA_Player.stop();
                TVA_Player.playPos = 0;    	    		
                this.playerView.resetPlayBtn();
                this.playerView.resetProgress();
            }
 
    	}
    },
    
    puiStop: function(){
            TVA_Player.stop();
            TVA_Player.playPos = 0;
            this.playbackUI.resetProgress();
            this.playbackUI.resetPlayBtn();
    	
    },
    
    keyPlay: function(){
    	if (this.playerView.isVisible() || this.player.getFullscreenFlag() == 1){   
            if(this.playbackUI.isVisible()){
                if (this.player.status == this.player.state.PAUSED){
                    this.playbackUI.setPlayBtn(this.player.status); 
                    TVA_Player.pause (false);
                }
                else if (this.player.status == this.player.state.STOPPED) {
                    this.keyPlay();
                }  
            }
            else{
                if ( this.player.status != this.player.state.PLAYING){
                    this.playbackUI.setPlayBtn(this.player.status); 
                }
                if(this.player.status == this.player.state.PAUSED){
                    this.playerView.playerStatus = this.player.state.PAUSED;
                    this.playerView.togglePlayBtnOver();
                    TVA_Player.pause (false);
                    this.playerView.playerStatus = this.player.status ;
    		}
    		else if(this.player.status == this.player.state.STOPPED){
                    if ( this.player.getFullscreenFlag() == 1 ){
                        this.player.setFullscreen();
                    }
                    else
                    {
                        this.player.setSmallScreen();
                        this.playerView.hidePlayer();
                    }
                    this.playerView.playerStatus = this.player.status ;
                    this.playerView.togglePlayBtnOver();
                    this.player.showLoading();
                    if(TVA.device == 'googletv'){
                        TVA_Player.setURL(TVA_Player.url);
                    }
                        TVA_Player.play();
                    this.playerView.startProgress();
    		}    
            }	
    	}
    },
     
    keyPause: function(isForce){ // funguje pro PUI

            if ( this.player.status != this.player.state.PAUSED){
               this.playbackUI.setPlayBtn(this.player.status); 
            }
            if (this.player.status == this.player.state.PAUSED || this.player.status == this.player.state.PLAYING){
                this.player.getPlayerState();
                this.playerView.playerStatus = this.player.status;

                if (this.player.status != this.player.state.PAUSED){
                    this.playerView.togglePlayBtnOver();
                }
                if(this.player.status == this.player.state.PLAYING || isForce){
                    TVA_Player.pause (true);    // param: boolean; true to pause and false to resume playback
                }
                else if (this.player.status == this.player.state.PAUSED){
                    TVA_Player.pause (false);    // param: boolean; true to pause and false to resume playback
                }
            }
    },
    
    goFullscreen: function(){
        $('#playerView').hide();
        this.footer.hideFooter(2);
        this.player.setFullscreen();

        if ((this.player.status != this.player.state.PLAYING) && (this.player.status != this.player.state.PAUSED)){
        	this.keyPlay();
    	}
    },

	goBackFromFullscreen: function(){
		if (this.player.status == this.player.state.PAUSED || this.player.status == this.player.state.PLAYING){
			this.playerView.showPlayer();
		}
		else{
			this.playerView.hidePlayer();
		}
	    $('#playerView').show();
	    this.player.setSmallScreen();
	    this.footer.showFooter(2);	
	},
	
	togglePlayer: function(isPlayerShown){
		if (this.playerView.isVisible()){
			if(isPlayerShown){
				this.playerView.showPlayer();
			}
			else{
				if(!this.player.isrunning){
					this.playerView.hidePlayer();
				}
			}
		}
	},

	setPlatform: function(){
        
        //IF THE DEVICE IS A SAMSUNG, WE CAN PULL THE YEAR OF MANUFACTURE
        
        if(settings.device.indexOf('samsung')!=-1){
            if(TVA.year == '2010'){
                settings.year = TVA.year;
            }
            else{
                if(navigator.userAgent.indexOf('Maple2012') == -1){
                    if(navigator.userAgent.indexOf('Maple') != -1)
                        settings.year = '2011';
                }
                else{
                    settings.year = '2012';
                }
            }
            $('#body').addClass(String(settings.device+settings.year).toLowerCase());
        }
        else{
            $('#body').addClass(String(settings.device).toLowerCase());
        }
    },
    
    loadMainCategoryNavigation: function(){
           
        var me= this;
        $.get(CONFIG.proxyURL+encodeURIComponent(this.urlToGetToken), function(data) { 
            var accessToken = data.access_token;
            TVA.log('[Main][loadMainCategoryNavigation] accessToken = '+ accessToken);
            //get categories:
            var assetUrl = 'https://api.hollybyte.com/playlist/children/?oauth_token='+ accessToken +'&account=leroymerlin&id=leroymerlin&fields={"title":true,"splash":true}';
                            
            $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function(data) {          
                
                data.result.shift(); // REMOVE THE ROOT NODE (FIRST ELEMENT)
                // SORT DATA APLHABETICALLY ASC
                data.result.sort(function(a,b){
                    var idA = a.id.toLowerCase(), idB = b.id.toLowerCase()
                    if (idA < idB) return -1;
                    if (idA > idB) return 1;
                    return 0;
                })
                
                // TEST Cache the data for the View 1 for View Category in Alpahabetic Order
                me.catgListCache = data;
                
                $.each(data.result, function (i, element) {
                    // DO NOT INCLUDE THE ROOT NODE
        
                    var catgTitle = element.title;
                    var catgThumb = element.splash; 
                    //TVA.log('[Main][loadMainCategoryNavigation] element.id = '+ element.id);

                    if (catgTitle.length >11){
                        catgTitle = catgTitle.substr(0, 12);
                    }

                    var fw = catgTitle.split(" ",1);
                    catgTitle = fw[0];
                    catgTitle = removeLastComma(catgTitle);

                    var subarray = [];
                    subarray[0] = catgTitle;            // Azulejos y ...
                    subarray[1] = catgThumb;            // img path
                    subarray[2] = element.id;           // azulejossuelos - param for query

                    me.catgNavigData[i] = subarray;
                    
                });

                assetUrl = 'https://api.hollybyte.com/playlist?oauth_token=' + accessToken + '&account=leroymerlin&fields={"title":"","description":"","splash":""}&criteria={"id":"atucasaletoca"}';

                //GET SEASONAL CONTENT:
                $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function(data) {
                                             
                    $.each(data.result, function (i, element) {
                        var seasonalTitle = element.title;
                        var seasonalDesc = element.description;
                        var seasonalSplash = element.splash;

                        var subarraySeason = [];
                        subarraySeason[0] = seasonalTitle;
                        subarraySeason[1] = seasonalDesc;
                        subarraySeason[2] = seasonalSplash;

                        me.seasonalContentData[i] = subarraySeason;
                        TVA.log('[Main] [loadMainCategoryNavigation] seasonalContentData[0] = ' + me.seasonalContentData[i][0]);
                        TVA.log('[Main] [loadMainCategoryNavigation] seasonalContentData[1] = ' + me.seasonalContentData[i][1]);
                        TVA.log('[Main] [loadMainCategoryNavigation] seasonalContentData[2] = ' + me.seasonalContentData[i][2]);
                    });
		    
                    me.renderComponents(me.catgNavigData, me.seasonalContentData);
                                                    
                }, 'jsonp');
            }, 'jsonp');

        }, 'jsonp');
                       
    },
        
        
    //--------------------------------------
    // GET ALL VIDEO FROM A SPECIFC CATEGORY
    
    loadCategoryVideoView : function (categoryId) {
		
        var me = this;
        
        var cat = null;
	for(var i in me.catgNavigData){
                if(me.catgNavigData[i][2] == categoryId){
                        cat = me.catgNavigData[i];
		}
	}
	
        // clear the Array with category videos:
        me.catgVideos = [];
		
        
        var accessToken;
		
        $.get(CONFIG.proxyURL+encodeURIComponent(this.urlToGetToken), function (data) {
            accessToken = data.access_token;
						
            // add time and path
            var assetUrl = 'https://api.hollybyte.com/playlist/get-assets?oauth_token=' + accessToken + '&account=leroymerlin&id=' + categoryId + '&fields={"title":true,"splash":true,"id":true,"description":true,"source":true}';
			
            //GET CATEGORIES
            $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function (data) {
                $.each(data.result, function (i, element) {
		    var videoTitle;
		    var videoDescription;
		    
                    // Add default value
                    if (element.title) {
                        videoTitle = element.title;
                    } else {
                        return;
                    }
					
                    if (element.description) {
                        videoDescription = element.description;
                    } else {
                        videoDescription = 'N/A';
                    }
					
                    var videoDuration = convertMilliseconds(element.source.duration).clock;
					
                    var videoTitleShort, videoTitleShortDetails, videoDescriptionDetails;
                    // STRIPPING TITLE FOR THUBNAIL BOX DESCRIPTION
                    if (videoTitle.length > 49) {
                        videoTitleShort = videoTitle.substr(0, 50) + ' ...';
                    } else {
                        videoTitleShort = videoTitle;
                    }
                    // STRIPPING TITLE FOR DETAILS BOX DESCRIPTION
                    if (videoTitle.length > 29) {
                        videoTitleShortDetails = videoTitle.substr(0, 30) + ' ...';
                    } else {
                        videoTitleShortDetails = videoTitleShortDetails;
                    }
                    // STRIPPING DESCRIPTION FOR DETAILS BOX DESCRIPTION
                    if (videoDescription.length > 199) {
                        videoDescriptionDetails = videoDescription.substr(0, 200) + ' ...';
                    } else {
                        videoDescriptionDetails = videoDescription;
                    }
                    var subarray = [];
                    subarray[0] = element.id; // ID
                    subarray[1] = videoTitle; // Title
                    subarray[2] = videoTitleShort; // Title short
                    subarray[3] = videoDescription; // Description
                    subarray[4] = element.splash; // Splash image path
                    subarray[5] = element.source.path; // Video path
                    subarray[6] = videoDuration; // Video duration
                    subarray[7] = videoTitleShortDetails; // Title short for detailbox
                    subarray[8] = videoDescriptionDetails; // Description short for detailbox

                    me.catgVideos.push(subarray);
					
                });
		
		if(! me.catgVideos || me.catgVideos.length == 0){
		    TVA.log('!! EMPTY CATEGORY');
                    
                    $('div.detailview-box-content-videolist-arrow-l img').hide();
                    $('div.detailview-box-content-videolist-arrow-r img').hide();
                    categoryTitle = cat[0];
                    me.infobar.offFocusHome();	
                    me.categoryView.show(categoryTitle, me.catgVideos);
                    me.activeView = me.activeViews.categoryView;
                    me.footer.showFooter(2);
                    me.footer.hideFooter(1);
                    me.footer.hideFooter(3);
                    me.suspend = false;
                    return;
		}
                
                // Disable or Show the arrows icons prev/next                 
                var maxNumThb = me.categoryView.getMaxNoOfThumbsInList();
                if( me.catgVideos.length <= maxNumThb){
                   $('div.detailview-box-content-videolist-arrow-l img').hide();
                   $('div.detailview-box-content-videolist-arrow-r img').hide();
                }
                else if (me.catgVideos.length > maxNumThb) {
                   $('div.detailview-box-content-videolist-arrow-l img').hide();    // By default arpw left is hidden for first pagination set
                   $('div.detailview-box-content-videolist-arrow-r img').show();  
                }   
				
                var categoryTitle
                if ( categoryId == 'atucasaletoca' ){
                        categoryTitle = 'A tu casa le toca...';
                        me.activeView = me.activeViews.aTuCasaLeToca;
                }else{
                        categoryTitle = cat[0];
                        me.activeView = me.activeViews.categoryView;
                }
                me.footer.showFooter(2);
                me.footer.hideFooter(1);
                me.footer.hideFooter(3);
                me.infobar.offFocusHome();
                me.categoryView.resetFocus();
				
                me.categoryView.show(categoryTitle, me.catgVideos);
                me.categoryView.setFocus(me.categoryView.getFocusedId());
                me.categoryView.displayPlayButton();
                me.suspend = false;
				
            }, 'jsonp');
			
        }, 'jsonp');
		
    },
    
        //-------
    // Load category that is selected into array
    
    
    loadHomeCategory : function (categoryId, viewId) {
		
        var me = this;
        
        var cat = null;
	for(var i in me.catgNavigData){
                if(me.catgNavigData[i][2] == categoryId){
                        cat = me.catgNavigData[i];
		}
	}
	
        // clear the Array with category videos:
        me.catgVideos = [];
		
        
        var accessToken;
		
        $.get(CONFIG.proxyURL+encodeURIComponent(this.urlToGetToken), function (data) {
            accessToken = data.access_token;
						
            // add time and path
            var assetUrl = 'https://api.hollybyte.com/playlist/get-assets?oauth_token=' + accessToken + '&account=leroymerlin&id=' + categoryId + '&fields={"title":true,"splash":true,"id":true,"description":true,"source":true}';
			
            //GET CATEGORIES
            $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function (data) {
                $.each(data.result, function (i, element) {
		    var videoTitle;
		    var videoDescription;
		    
                    // Add default value
                    if (element.title) {
                        videoTitle = element.title;
                    } else {
                        return;
                    }
					
                    if (element.description) {
                        videoDescription = element.description;
                    } else {
                        videoDescription = 'N/A';
                    }
					
                    var videoDuration = convertMilliseconds(element.source.duration).clock;
					
                    var videoTitleShort, videoTitleShortDetails, videoDescriptionDetails;
                    // STRIPPING TITLE FOR THUBNAIL BOX DESCRIPTION
                    if (videoTitle.length > 49) {
                        videoTitleShort = videoTitle.substr(0, 50) + ' ...';
                    } else {
                        videoTitleShort = videoTitle;
                    }
                    // STRIPPING TITLE FOR DETAILS BOX DESCRIPTION
                    if (videoTitle.length > 29) {
                        videoTitleShortDetails = videoTitle.substr(0, 30) + ' ...';
                    } else {
                        videoTitleShortDetails = videoTitleShortDetails;
                    }
                    // STRIPPING DESCRIPTION FOR DETAILS BOX DESCRIPTION
                    if (videoDescription.length > 199) {
                        videoDescriptionDetails = videoDescription.substr(0, 200) + ' ...';
                    } else {
                        videoDescriptionDetails = videoDescription;
                    }
                    var subarray = [];
                    subarray[0] = element.id; // ID
                    subarray[1] = videoTitle; // Title
                    subarray[2] = videoTitleShort; // Title short
                    subarray[3] = videoDescription; // Description
                    subarray[4] = element.splash; // Splash image path
                    subarray[5] = element.source.path; // Video path
                    subarray[6] = videoDuration; // Video duration
                    subarray[7] = videoTitleShortDetails; // Title short for detailbox
                    subarray[8] = videoDescriptionDetails; // Description short for detailbox

                    me.catgVideos.push(subarray);
                    
					
                });
                
                    if (viewId == 'cv'){
                             me.categoryView.hide(); 
                    }
                    else if ( viewId == 'clv'){
                        
                            me.categoryListView.hide(); 
                        
                    }
                             
                    $('#playerView').show();
                    me.activeView = me.activeViews.playerView;
                    me.footer.hideFooter(1);
                    me.footer.hideFooter(3);
                    me.footer.showFooter(2);
                    

                    me.suspend = false;
				
            }, 'jsonp');
			
        }, 'jsonp');
		
    },
        
        loadRelatedVideos: function(videoId, data){
           
        var currentRelVideoData = data;
      
        var me = this;
        var countLinkedVideo = 0;   // count how many related videos have a real reference to an asset            
        // clear the related videos array:
        me.relatedVideosData = [];
            
        $.get(CONFIG.proxyURL+encodeURIComponent(this.urlToGetToken), function(data) { 
            var accessToken = data.access_token;
            
            var norelated = function(){
            	TVA.log('NORELATED VIDEOS!!!');
                var focusedVideoId = me.categoryView.getFocusedId();
                focusedVideoId = focusedVideoId.substr(11,1);
                var videoPath = me.catgVideos[focusedVideoId][5];
                
                if (me.activeView == me.activeViews.categoryView ){
                    
                    if ( me.activeCatgView == 1){
                        var categoryIndex = me.infobar.getCatgIndex();
                        var categoryName = me.catgNavigData[categoryIndex][0];
                    }
                    else{ 
                                        
                        var categoryId =  me.categoryListView.getCategoryId();
                        for(var i in me.catgNavigData){
                                if(me.catgNavigData[i][2] == categoryId){
                                        categoryName = me.catgNavigData[i][0];
                                }
                        }
                    }
                    
                }
                else if (me.activeView == me.activeViews.aTuCasaLeToca){
                    
                    var categoryName = 'A tu casa...';
                    
                }

                me.categoryView.offFocusCategoryView();
                me.playerView.resetFocus();

                me.playerView.showNorel(videoPath, me.catgVideos, focusedVideoId, categoryName );
                me.activeView = me.activeViews.playerView;
                me.footer.showFooter(2);
                me.footer.hideFooter(1);
                me.footer.hideFooter(3);
                me.suspend = false;
            };
                            
            // GET INFORMATION FOR A SPECIFIC VIDEO, IN THIS CASE WE ARE INTERESTED IN ITS RELATED ASSETS ONLY
            // WE ARE PASSING MONGO DB COMMANDS IN JSON FORMAT TO THE API FOR FILTERING THE RESULT SET
            var assetUrl = 'https://api.hollybyte.com/asset?oauth_token=' + accessToken + '&account=leroymerlin&id=' + videoId + '&fields={"values":true}';

            $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function (data) {
		
            	if(! data || typeof data.values == 'undefined' || typeof data.values.demostraciones_relacionadas == 'undefined'){
			$('div.videorelated_arrow_up img').hide();
                        $('div.videorelated_arrow_dwn img').hide();
            		norelated();
            	}
            	else if (data.values.demostraciones_relacionadas){   // Check if 'demostraciones_relacionadas' element in result 

                    var relatedVideosIds = (data.values.demostraciones_relacionadas).split(',');

                    if (relatedVideosIds){

                        TVA.log(relatedVideosIds);
                        // NOW THAT WE HAVE THE RELATED IDS FOR A SPECIFIC ASSET,
                        // WE HAVE TO QUERY THE API AND GET ALL ASSETS IN THE MONGO DB, TOGHETER WITH THEIR VIDEO RELATED UNIQUE IDS
                        // GET ALL THE ASSETS USING THE HB API
                        assetUrl = 'https://api.hollybyte.com/asset?oauth_token=' + accessToken + '&account=leroymerlin' + '&fields={"title":true,"splash":true,"description":true,"source":true,"values":true}';
                        $.get(CONFIG.proxyURL+encodeURIComponent(assetUrl), function (data) {

                            // LOOP TROUGHT ALL RELATED VIDEOS
                            for (var i = 0, j = relatedVideosIds.length; i < j; i++) {
                            	var array = [];
                                for (var k = 0, x = data.result.length; k < x; k++) {
                                    // CHECK IF THE OBJECT HAS THE VALUE PROPERTY FROM ITS PROTOTYPE
                                    if (data.result[k].hasOwnProperty('values')) {
                                        if (data.result[k].values.hb1 == relatedVideosIds[i]) {
                                            var subarray = []; 
                                            subarray[0] = data.result[k].id;
                                            subarray[1] = data.result[k].title;
                                            subarray[2] = data.result[k].splash;
                                            subarray[3] = data.result[k].description;
                                            subarray[4] = convertMilliseconds(data.result[k].source.duration).clock;
                                            subarray[5] = data.result[k].source.path;
                                            TVA.log('TITLE:       ' + subarray[1]);
                                            array.push(subarray);
                                            countLinkedVideo++; // COUNT HOW MANY VIDEO ARE ACTUALLY REALLY RELATED
  
					    me.relatedVideosData.push(subarray);
                                        }
                                    }

                                }

                                // Disable or Show the Related Video arrow icons Up and Down if no related video are present
                                 var maxNumThb = 3;  // The number of thubnails you want display
                                  if(countLinkedVideo <= maxNumThb){
                                     $('div.videorelated_arrow_up img').hide();
                                     $('div.videorelated_arrow_dwn img').hide();
                                 }
                                 else if (countLinkedVideo > maxNumThb) {
                                     $('div.videorelated_arrow_up img').show();
                                     $('div.videorelated_arrow_dwn img').show();  
                                 }   
                                
                                // DISABLE THE PRELOAD MANUALLY, AS AJAX CALLS ARE IN PROGRESS WHEN THE VIDEO IS PLAYING
                                $('#preload,#preloadWeel').hide();
                            }

			    
                            // if we go from category view: 
                            if (me.activeView == me.activeViews.categoryView ){
                                if(me.relatedVideosData.length == 1 && me.relatedVideosData[0].length == 0){
                                	norelated();
                                }
                                else{
                                    var focusedVideoId = me.categoryView.getFocusedId();
                                    focusedVideoId = focusedVideoId.substr(11,1);
                                    TVA.log('[Main] [keyDown]  ---> focusedVideoId: '+ focusedVideoId);     //number
                                    var videoPath = me.catgVideos[focusedVideoId][5];

                                    if ( me.activeCatgView == 1){
                                            var categoryIndex = me.infobar.getCatgIndex();
                                            var categoryName = me.catgNavigData[categoryIndex][0];
                                    }
                                    else{   
                                            var categoryId =  me.categoryListView.getCategoryId();
                                            for(var i in me.catgNavigData){
                                                if(me.catgNavigData[i][2] == categoryId){
                                                       categoryName = me.catgNavigData[i][0];
                                                }
                                            }
                                    }
 
                                    me.playerView.show(videoPath, me.catgVideos, focusedVideoId, categoryName, me.relatedVideosData );                         
                                }
                            }
                            // if we go from A tu casa le toca:
                            else if (me.activeView == me.activeViews.aTuCasaLeToca){
                                if(me.relatedVideosData.length == 1 && me.relatedVideosData[0].length == 0){
                                	norelated();
                                }
                                else{
                                    var focusedVideoId = me.categoryView.getFocusedId();
                                    focusedVideoId = focusedVideoId.substr(11,1);
                                    TVA.log('[Main] [keyDown]  ---> focusedVideoId: '+ focusedVideoId);     //number
                                    var videoPath = me.catgVideos[focusedVideoId][5];
                                    var categoryName = 'A tu casa...';
                                    me.categoryView.offFocusCategoryView(); 
                                    me.playerView.show(videoPath, me.catgVideos, focusedVideoId, categoryName, me.relatedVideosData );                         
                                }
                            }
                            // if we go from Related videos:
                            else if (me.activeView == me.activeViews.playerView){
                                
                                    me.playerView.showRelated(currentRelVideoData, me.relatedVideosData );
                            }
                            
                            me.activeView = me.activeViews.playerView;
                            me.footer.showFooter(2);
                            me.footer.hideFooter(1);
                            me.footer.hideFooter(3);
                            me.suspend = false;

                        }, 'jsonp'); 
                       

                    }
   
                }
                else    // no related videos 
                {
                	norelated();
                }

                                
            }, 'jsonp');

        }, 'jsonp');

    },
        

    
    loadCategoriesAlphabetic : function(letter, num, callback ) {   

        var me = this;
	var cats = [];
	
	for(var i in me.catgNavigData){
	    cats.push({
		id: me.catgNavigData[i][2],
		title: me.catgNavigData[i][0],
		splash: me.catgNavigData[i][1]
	    });
	}
            
        var catGroup = [letter];
        catGroup[1] = new Array();
            
        // POPULATE THE ARRAY WITH CATEGORIES FOR A LETTER
 
        // Filter by Letter
        var catgByLetter = cats.filter(function(x){
                return x.id[0] == letter;
        })

        if (catgByLetter.length != 0){

             catGroup[1] = catgByLetter.sort(function (a, b) {
                 // SORTING ALPHABETICALLY
                 var catA = a.title.toLowerCase(), catB = b.title.toLowerCase();
                 if(catA < catB) return -1;
                 if(catA > catB) return 1;
                 return 0;
             });


             me.catgAlphabetData.push(catGroup);
             //TVA.log('me.catgAlphabetData.length  :' + me.catgAlphabetData.length);
         }

         //TVA.log('this.alphabetQueryLength :' + me.alphabetQueryLength);

         if (me.alphabetQueryLength == num ) {
                callback();
         }
         me.alphabetQueryLength++;
 
    },
    
    
    categoriesAlphabeticCallback: function(){
                    
        this.catgAlphabetData.sort(comparator);
                    
        for (i = 0; i < this.catgAlphabetData.length; i++ ){
                        
            TVA.log('sortedAlphabetListData[0][0]: ' + this.catgAlphabetData[i][0]);
        }

	this.categoryListView.renderLayout(this.catgAlphabetData);
    },

        
    iterateAlphabet: function(callback) {

	var str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", nextChar;
     
        this.catgAlphabetData = [];   // empty the data array each time you load data.
        TVA.log('this.catgAlphabetData.length:  ' + this.catgAlphabetData.length);
                
        for (var i = 0, k = str.length; i < k; i++) {
            nextChar = str.charAt(i).toLowerCase();
            bind(this, this.loadCategoriesAlphabetic(nextChar, k, callback ));
        }
    },
    
    
    loadCategoryListViewData: function(callback){
   
        if(!this.catgAlphabetData[0]){
                    
            this.iterateAlphabet(callback);           
        }
        else{
            this.categoryListView.show();

        }
    
    },

    // Change the backgroud Image for the DIV Content when Preload is in action
    // pageLoading = the page being loaded
    preloadBkgSwap:function(pageLoading) {  
        
            var content = $('#content');
            switch (pageLoading) {
                case 'infoBar':
                    content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                    break;
                case 'categoryView':
                    content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                    break;
                case 'remove':
                    content.css('background', 'transparent');
                    break;
            }
        
    },

    networkDown: function(){
	TVA.log('CONNECTION FAILED');
	if(TVA.connectionPlaying){
            this.player.getPlayerState();
            this.playerView.playerStatus = this.player.status = this.player.state.PLAYING;
            this.playerView.togglePlayBtnOver(); 
	    this.networkerror = true;
	}
    },
	
    networkUp: function(){
		TVA.log('CONNECTION OK');
		if(this.networkerror){
                    this.networkerror = false;
                    this.playerView.playerStatus = this.player.status = this.player.state.PAUSED;
                    this.playerView.togglePlayBtnOver();
                    TVA_Player.pause(false);
		}
    },

    preloadImageLoaded: function(title){
        
                this.categoryView.show(title, this.catgVideos);             
                this.categoryView.setFocus( this.categoryView.getFocusedId() );     
                this.categoryView.displayPlayButton(); 
    },
        
        // MAGIC CONTROL LG --------------------------------
        // View 01 : infoBar
        // MAGIC control handler for button VER VIDEOS
	magicCtrVerVideos: function(){
            this.suspend = true;
            this.infobar.hideInfobar();
            this.preloadBkgSwap('infoBar');
            this.pageHistory.unshift(this.activeViews.aTuCasaLeToca);

            for (var i = 0; i < this.pageHistory.length; i++){
                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
            }
            this.activeView = this.activeViews.aTuCasaLeToca;
            this.footer.showFooter(2);
            this.footer.hideFooter(1);
            this.footer.hideFooter(3);
            this.loadCategoryVideoView('atucasaletoca');
	},
        
        // MAGIC control handler for QMENU button in PlaybavkUI: onClick
        magicCtrQmenuBtnClick: function() {
            TVA_Player.showQMenu();
        },
        
        // MAGIC control handler for QMENU button in PlaybavkUI: onMouseOver        
        magicCtrQmenuBtnClickMouseOver: function() {
                var elmCurrentFocus; 
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                this.playbackUI.offFocus(elmCurrentFocus);
                this.playbackUI.setPlayerControlFocus('qmenu');       
                this.playbackUI.controlSelected = this.playbackUI.controlIds.qmenu;        
        },       
        
        // MAGIC control handler for Green button in footer: onClick
        magicCtrGreenBtnClick: function(){

            if(this.activeView != this.activeViews.aTuCasaLeToca){
                    this.suspend = true;
                    
                    //off focus footer
                    var elmCurrentFocus;
                    elmCurrentFocus = TVA.onFocus;
                    this.footer.offFocus(elmCurrentFocus); 
                   
                    if(this.infobar.isVisible()) {
                            this.preloadBkgSwap('infoBar');
                    } else {
                            this.preloadBkgSwap('categoryView');      
                    }                                     
                    if(this.activeView == this.activeViews.homeView)            this.infobar.hideInfobar();
                    if(this.activeView == this.activeViews.categoryView)        this.categoryView.hide();
                    if(this.activeView == this.activeViews.playerView)          this.playerView.hide();
                    if(this.activeView == this.activeViews.categoryListView)    this.categoryListView.hide();
                    if(this.activeView == this.activeViews.aTuCasaLeToca)       this.categoryView.hide();
                    this.pageHistory.unshift(this.activeViews.aTuCasaLeToca);        
                    this.loadCategoryVideoView('atucasaletoca');
                    this.activeView = this.activeViews.aTuCasaLeToca;
                    this.footer.showFooter(2);
                    this.footer.hideFooter(1);
                    this.footer.hideFooter(3);
            } 
 
        },         
        
        // MAGIC control handler for button VER TODAS : onClick
        magicCtrVerTodas: function(){
            this.infobar.hideInfobar();
            this.pageHistory.unshift(this.activeViews.categoryListView);

            for (var i = 0; i < this.pageHistory.length; i++){
                    TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
            }
            this.activeView = this.activeViews.categoryListView;
            this.footer.showFooter(2);
            this.footer.hideFooter(1);
            this.footer.hideFooter(3);
            this.categoryListView.show();
            this.loadCategoryListViewData(bind(this, this.categoriesAlphabeticCallback) );        
        },
        
        // MAGIC control handler for Yellow button in footer: onClick
        magicCtrYellowBtnClick: function(){
            if(this.activeView != this.activeViews.categoryListView){
                    //off focus footer
                    var elmCurrentFocus;
                    elmCurrentFocus = TVA.onFocus;
                    this.footer.offFocus(elmCurrentFocus);
                    
                    this.activeCatgView = 4;
                    if(this.infobar.isVisible()) {
                        this.preloadBkgSwap('infoBar');
                    } else {
                        this.preloadBkgSwap('categoryView');     
                    }
                    if(this.activeView == this.activeViews.homeView)      this.infobar.hideInfobar();
                    if(this.activeView == this.activeViews.categoryView)  this.categoryView.hide();
                    if(this.activeView == this.activeViews.aTuCasaLeToca) this.categoryView.hide();      
                    if(this.activeView == this.activeViews.playerView)    this.playerView.hide();
                    this.activeView = this.activeViews.categoryListView;
                    this.footer.showFooter(2);
                    this.footer.hideFooter(1);
                    this.footer.hideFooter(3);
                    this.categoryListView.show();
                    this.loadCategoryListViewData(bind(this, this.categoriesAlphabeticCallback) );
                    this.pageHistory.unshift(this.activeViews.categoryListView);
            }
            
        },
        
        
        // MAGIC control handler for Yellow buttons in footer: onMouseOver
        magicCtrFooterBtnMouseOver: function(obj){
            
            var elmCurrentFocus;
            elmCurrentFocus = TVA.onFocus;
            console.log('+++elmCurrentFocus:' + elmCurrentFocus);
            var elmOnOver = obj.id;
            console.log('+++elmOnOver:' + elmOnOver);
            
            // infobar:
            if ( this.activeView == this.activeViews.homeView ){
                    console.log('+++Footer1:');
                    this.infobar.offFocus(elmCurrentFocus); 
                    this.footer.setFocus(elmOnOver) ;
            }
            else if ( this.activeView == this.activeViews.categoryView ){
                    console.log('+++Footer2:');
                    
                    console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                    this.categoryView.offFocus(elmCurrentFocus); 
                    console.log('+++elmOnOver:' + elmOnOver);
                    this.footer.setFocus(elmOnOver) ;
            }
            else if ( this.activeView == this.activeViews.playerView ){
                    
                    console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                    this.playerView.offFocus(elmCurrentFocus); 
                    console.log('+++elmOnOver:' + elmOnOver);
                    this.footer.offFocus(elmOnOver) ;
                    this.footer.setFocus(elmOnOver) ;
            } 
            else if ( this.activeView == this.activeViews.categoryListView ){
                    
                    console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                    this.categoryListView.offFocus(elmCurrentFocus); 
                    console.log('+++elmOnOver:' + elmOnOver);
                    this.footer.offFocus(elmOnOver) ;
                    this.footer.setFocus(elmOnOver) ;
            }
            else if ( this.activeView == this.activeViews.aTuCasaLeToca ){
                    
                    console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                    this.categoryListView.offFocus(elmCurrentFocus); 
                    console.log('+++elmOnOver:' + elmOnOver);
                    this.footer.offFocus(elmOnOver) ;
                    this.footer.setFocus(elmOnOver) ;
            } 
        },
        
        // MAGIC control handler for buttons in footer: onMouseOut
        magicCtrFooterBtnMouseOut: function(){
    
                var elmCurrentFocus = TVA.onFocus;
                this.infobar.offFocus(elmCurrentFocus);   
        },
        
        // MAGIC control handler for element in general for status : onMouseOver
        magicCtrGeneralMouseOver: function(obj, getParent, id, viewNumber){           

            var elmCurrentFocus; 
            // Get the id for element with status MouseOver
            elmOnOver = obj.id;
            console.log('+++elmOnOver:' + elmOnOver);
            
            // Get the element currently in focus
            elmCurrentFocus = TVA.onHover;
            // Check if to get the Parent ID
            console.log('+++ getParent:' + getParent);
            if(getParent){
                elmOnOver = obj.parentNode.id; 
            }

            
            switch(viewNumber)
            {
                    case 1:
                            this.infobar.offFocus(elmCurrentFocus);
                            this.infobar.setFocus(elmOnOver);
                            break;
                    case 2:
                            this.categoryView.setFocus(elmOnOver); //test 
                            this.categoryView.offFocus(elmCurrentFocus);                     
                            break;
                    default:

            }

        },
       
        
        // MAGIC control handler for homeView arrows : onClick
        magicCtrView1ArrowClick: function(direction){
            
            if (direction == 'next'){
                
                    if ( this.infobar.catgIndex < this.infobar.catgNavigData.length - 1){
                            this.infobar.moveRight();
                    }
                    else{
                        
                        this.rightArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_next_selected');
                        this.rightArrowSelEl.css("display", "none");
                        
                    } 
            }
            else if ( direction == 'prev'){

                    if ( this.infobar.catgIndex > 0){
                            this.infobar.moving('left');
                    }
                    else{
                        
                        this.rightArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_prev_selected');
                        this.rightArrowSelEl.css("display", "none");   
                    }
                    
            }
        },
        
        // MAGIC control handler for Category Thubnail : onClick 
        magicCtrView1ThubnailReturn: function(id){
                console.log('+++ PRESSED BUTTON  magicCtrView1ThubnailReturn');
                if(this.infobar.isVisible()){  
                        
                        // FOOTER
                        this.footer.showFooter(2);
                        this.footer.hideFooter(1);
                        this.footer.hideFooter(3);                  

                        // Set Preload Background
                        this.preloadBkgSwap('infoBar');

                        // Go to Category View 

                        this.infobar.hideInfobar();
                        //var categoryIndex = this.infobar.getCatgIndex();

                        // We need retrtive the categoryIndex from a selected element using the ID
                        //var elmCurrentFocus = TVA.onHover;

                        console.log('+++ ID: ' + id);
                        this.infobar.focusedID = id; // TESTING
                        var categoryIndex = id;

                        // call for category videos
                        var categoryId = this.catgNavigData[categoryIndex][2];

                        console.log('+++ categoryId: ' + categoryId);
                        this.infobar.catgIndex = id;       
                        this.loadCategoryVideoView(categoryId);

                        this.pageHistory.unshift(this.activeViews.categoryView);

                        // TEST set the status of button id on the element in wich return has been pressed
                        this.infobar.buttonId = id;     
             
                }                   
        },
        
        // MAGIC control handler for infoBar Category Thubnail : onMouseOver
        magicCtrView1ThubnailMouseOver: function(obj){
            
            console.log('+++START:' );
            
            this.infobar.navigationSelected = this.infobar.navigationIds.categoryNavig;
            
            var elmCurrentFocus = TVA.onFocus;
            console.log('+++elmCurrentFocus:' + elmCurrentFocus);
            var elmOnOver = obj.id;
            console.log('+++elmOnOver:' + elmOnOver);
            
            this.infobar.offFocus(elmCurrentFocus);
            var buttonId = this.infobar.buttonId = parseInt(elmOnOver.substr(4));
            
            if( this.infobar.startCatgId == 0){
                    this.infobar.catgIndex = buttonId;
            }
            else{
                    this.infobar.catgIndex = this.infobar.startCatgId + buttonId;
                
            }
            this.infobar.setFocus(elmOnOver) ;
            console.log('+++buttonId:' + this.infobar.buttonId); 
            console.log('+++catgIndex:' + this.infobar.catgIndex);
            console.log('+++startCatgId: ' + this.infobar.startCatgId);
            
        },
        
        // MAGIC control handler for Category Thubnail : onClick 
        magicCtrView1ThubnailClick: function(id){
                console.log('+++ PRESSED BUTTON  magicCtrView1ThubnailReturn');
                        this.suspend = true;
                        // FOOTER
                        this.footer.showFooter(2);
                        this.footer.hideFooter(1);
                        this.footer.hideFooter(3);                  

                        // Set Preload Background
                        this.preloadBkgSwap('infoBar');

                        this.infobar.hideInfobar();
                        var categoryIndex = this.infobar.getCatgIndex();
                        console.log('ib.catgIndex: '+ categoryIndex);
                                                
                        // call for category videos
                        var categoryId = this.catgNavigData[categoryIndex][2];
                        /* MILANO */
                        //this.catgNavigDataHistory = categoryId;
                        this.catgNavigDataHistory.push(categoryId);
                        
                        console.log('categoryId: '+ categoryId);
                        this.loadCategoryVideoView(categoryId);
                        
                        this.pageHistory.unshift(this.activeViews.categoryView);
                        
                        for (var i = 0; i < this.pageHistory.length; i++){
                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                        }   
                   
        },
        
        // MAGIC control handler for Video Category button left, right : onMouseOver
        magicCtrView1ArrMouseOver: function(direction){

                var elmCurrentFocus = TVA.onFocus;                
                this.infobar.offFocus(elmCurrentFocus);
                this.infobar.setFocus(this.infobar.buttonName + this.infobar.buttonId);
                this.infobar.navigationSelected = this.infobar.navigationIds.categoryNavig;
                
                if ( direction == 'next'){
                    
                        this.rightArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_next_selected');
                        this.rightArrowSelEl.css("display", "block");
 
                }
                else if( direction == 'prev' ){
                    
                        this.leftArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_prev_selected');
                        this.leftArrowSelEl.css("display", "block");
 
                }
        },
        
        magicCtrView1ArrMouseOut: function(direction){
            
                if ( direction == 'next'){
                    
                        this.rightArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_next_selected');
                        this.rightArrowSelEl.css("display", "none");
                    
                }
                else if( direction == 'prev' ){
                    
                        this.rightArrowSelEl = $('div.categories_wrapper div.category_btns_wrapper div.btn_prev_selected');
                        this.rightArrowSelEl.css("display", "none");
                    
                } 
        },
        

        // MAGIC control handler for CatgView Thubnails Video : onClick
        magicCtrView2ThubnailReturn: function(id){
                // Set preload background
                this.suspend = true;
                this.preloadBkgSwap('categoryView');
                this.categoryView.hide();

                // FOOTER
                this.footer.showFooter(2);
                this.footer.hideFooter(1);
                this.footer.hideFooter(3);
               
                var focusedVideoId = this.categoryView.getFocusedId();
                focusedVideoId = focusedVideoId.substr(11,1);


                if(this.catgVideos.length > 0){
                    var myVideoId = this.catgVideos[focusedVideoId][0];
                    this.loadRelatedVideos(myVideoId, null);
                }

                this.pageHistory.unshift(this.activeViews.playerView);
   
        },
        
        // View 02 : categoryView
        // MAGIC control handler for button Volver inicio : onClick
        magicCtrView2VolverInicio: function(){
            CategoryView.focusBackButton();
            if (this.categoryView.getFocusedId() == 'catgBackButton'){
                this.resetHistory();
                this.categoryView.hide();                            
                console.log('this.infobar.getFocusedId():' + this.infobar.getFocusedId());
                this.infobar.setFocus( this.infobar.getFocusedId() );
                $('#infoBar').show();
                this.activeView = this.activeViews.homeView;
                this.footer.showFooter(1);
                this.footer.hideFooter(2);
                this.footer.hideFooter(3);

            }
        },
        
        // MAGIC control handler for arrows prev/next : onClick
        magicCtrView2ArrowClick:function(direction){
            
                if ( direction == 'next'){

                        //if (this.categoryView.thumbId < this.categoryView.maxNoOfThumbsInList -1 && this.categoryView.thumbId != this.categoryView.catgVideos.length - 1 ){
                        if (this.categoryView.thumbId <= this.categoryView.maxNoOfThumbsInList -1 && this.categoryView.thumbId != this.categoryView.catgVideos.length - 1 ){    
                                this.categoryView.moveRight();
                        }
                        else if( this.categoryView.thumbId == this.categoryView.maxNoOfThumbsInList -1 ){
                                this.categoryView.moveRight();
                                this.nextArrowSelEl = $('div.catg_view_btn_next_sel');
                                this.nextArrowSelEl.css("display", "none");
                        }
                }
                else if( direction == 'prev' ){

                        var pageid = this.categoryView.thumblistPageId - 1;

                        if(pageid > 0 ){
                                this.categoryView.moveLeft();  
                        }
                        else if (pageid == 0 && this.categoryView.thumbId != 0){
                                this.categoryView.moveLeft();
  
                        }
                        else if (pageid == 0 && this.categoryView.thumbId == 0){
                                this.categoryView.moveLeft();
                                this.nextArrowSelEl = $('div.catg_view_btn_prev_sel');
                                this.nextArrowSelEl.css("display", "none");   
                        }    
   
                } 
        },
        
        // MAGIC control handler for Video Category Thubnails : onMouseOver
        magicCtrView2VideoThumbMouseOver: function(obj){   
                
                var elmCurrentFocus; 
                // Get the element currently in focus
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);

                this.categoryView.offFocus(elmCurrentFocus); 
                this.categoryView.setFocus(elmOnOver);
                //this.categoryView.thumbId = elmOnOver.substr(11);
                this.categoryView.thumbId = parseInt(elmOnOver.substr(11));
                this.categoryView.displayPlayButton();
                
       
       },
       
       // MAGIC control handler for Video Category buttons prev/next : onMouseOver
       magicCtrView2ArrMouseOver: function(direction){
                
                if (this.categoryView.focusedID == 'catgBackButton' ){
	                this.categoryView.offFocus('catgBackButton');
	                this.categoryView.setFocus(this.categoryView.thumbName + this.categoryView.thumbId);
                }
      
                if ( direction == 'next'){
                    
                        this.nextArrowSelEl = $('div.catg_view_btn_next_sel');
                        this.nextArrowSelEl.css("display", "block");
 
                }
                else if( direction == 'prev' ){
                    
                        this.prevArrowSelEl = $('div.catg_view_btn_prev_sel');
                        this.prevArrowSelEl.css("display", "block");
                }

        },
        
        // MAGIC control handler for Video Category buttons prev/next : onMouseOut
       magicCtrView2ArrMouseOut: function(direction){
                
                if ( direction == 'next'){
                    
                        this.nextArrowSelEl = $('div.catg_view_btn_next_sel');
                        this.nextArrowSelEl.css("display", "none");
                    
                }
                else if( direction == 'prev' ){
                    
                        this.prevArrowSelEl = $('div.catg_view_btn_prev_sel');
                        this.prevArrowSelEl.css("display", "none");
                    
                } 

        },
        
        // MAGIC control handler for blank category popup message : onClick
        magicCtrView2PopupClick: function(){
            
                this.pageHistory.shift();
                switch(this.pageHistory[0]){
                        case this.activeViews.homeView:
                                this.categoryView.hide();
                                this.infobar.setFocus( this.infobar.getFocusedId() );
                                $('#infoBar').show();
                                this.activeView = this.activeViews.homeView;
                                this.footer.showFooter(1);
                                this.footer.hideFooter(2);
                                this.footer.hideFooter(3);
                                break;

                        case this.activeViews.categoryListView:
                                this.categoryView.hide();
                                $('#categoryListView').show();
                                this.activeView = this.activeViews.categoryListView;
                                this.footer.hideFooter(1);
                                this.footer.hideFooter(3);
                                this.footer.showFooter(2);
                                break;
                }

        },

       
        // View 03 : playerView
        // Magic control handler for button Volver ... go
        magicCtrView3verDynamic: function(){
            
                this.footer.showFooter(2);
                this.footer.hideFooter(1);
                this.footer.hideFooter(3);

                var categoryTitle;

                this.playerView.offFocusPlayerView();
                this.playerView.controlSelected = null;
                this.playerView.hide();
                // get title
                if ( this.pageHistory[1] == this.activeViews.categoryView){

                        if ( this.activeCatgView == 1){
                                var categoryIndex = this.infobar.getCatgIndex();
                                var categoryTitle = this.catgNavigData[categoryIndex][0];
                        }
                        else{ 

                                var categoryId =  this.categoryListView.getCategoryId();
                                for(var i in this.catgNavigData){
                                        if(this.catgNavigData[i][2] == categoryId){
                                                categoryTitle = this.catgNavigData[i][0];
                                        }
                                }
                        }

                        this.activeView = this.activeViews.categoryView;
                }
                else if ( this.pageHistory[1] == this.activeViews.aTuCasaLeToca){
                        categoryTitle = 'A tu casa le toca...';
                        this.activeView = this.activeViews.aTuCasaLeToca;
                }

                this.categoryView.show(categoryTitle, this.catgVideos);             
                this.categoryView.setFocus( this.categoryView.getFocusedId() );     
                this.categoryView.displayPlayButton();   
                this.preloadFlag = true;
                if (settings.device == 'philips' || settings.device == 'googletv'){
                        var content = $('#content');
                        content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                }

                this.pageHistory.shift();
        },
        
        
        // View3: playerView
        
        // MAGIC control handler for Back button : onMouseOver
        magicCtrlView3BackMouseOver: function(obj, getParent ){

                var elmCurrentFocus;
                elmCurrentFocus = TVA.onFocus;
                // Check if to get the Parent ID
                if(getParent){
                    elmOnOver = obj.parentNode.id; 
                    console.log('+++Parent elmOnOver:' + elmOnOver);     
                }
                
                this.playerView.offFocus(elmCurrentFocus); 
                this.playerView.navigationSelected = this.playerView.navigationIds.backButton;
                this.playerView.controlSelected = null;
                this.playerView.setFocus(elmOnOver);
                
                this.playerView.setPlayBtnOverMC();        
            
        },
        
        // MAGIC control handler for Related Video Thubnails : onMouseOver
        magicCtrView3RelVideoMouseOver: function(obj){   
            
                var elmCurrentFocus; 
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                
                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);

                this.playerView.offFocus(elmCurrentFocus); 
                this.playerView.navigationSelected = this.playerView.navigationIds.relatedVideos;
                this.playerView.controlSelected = null;
                console.log('+++playerView.focusedID:' + this.playerView.focusedID);
                this.playerView.setFocus(elmOnOver);
                this.playerView.thumbId = elmOnOver.substr(14);
                this.playerView.displayPlayButton();
                this.playerView.setPlayBtnOverMC();                           // sets rollover
        },
        
        // MAGIC control handler for Related Video Thubnails : onClick
        magicCtrView3RelVideoClick: function(id){
                
                this.suspend = true;
                this.preloadFlag = false;
                
                var focusedRelVideoId = this.playerView.focusedID;
                focusedRelVideoId = focusedRelVideoId.substr(14);
                console.log('+++ [Main] [keyDown] focusedRelVideoId: ' + focusedRelVideoId);

                var relVideoId = this.relatedVideosData[focusedRelVideoId][0];
                console.log('+++ [Main] [keyDown] relVideoId: ' + relVideoId);

                var focusedRelatedVideoData = this.relatedVideosData[focusedRelVideoId];
                this.loadRelatedVideos(relVideoId, focusedRelatedVideoData);

        },
        
        // MAGIC control handler for Play/Pause button : onMouseOver
        magicCtrView3PlayPauseMouseOver: function(obj){   
            
                var elmCurrentFocus; 
                // Get the element currently in focus
                //elmCurrentFocus = TVA.onHover;
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                
                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);

                this.playerView.offFocus(elmCurrentFocus); 
                this.playerView.navigationSelected = this.playerView.navigationIds.player;
                this.playerView.setPlayerControlFocus('play_button');       // !!! sets focus to 'play_button' not to var 'elmOnOver'

                this.playerView.controlSelected = 0; // Play/Pause btn
                this.playerView.setPlayBtnOverMC();                           // sets rollover
        },
        
        // MAGIC control handler for Fullscreen button : onMouseOver
        magicCtrView3FullscreenMouseOver: function(obj){    
            
                
                var elmCurrentFocus; 
                // Get the element currently in focus
                //elmCurrentFocus = TVA.onHover;
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);

                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);

                this.playerView.offFocus(elmCurrentFocus);
                if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos){
                        this.playerView.hidePlayButton();
                }
                
                this.playerView.navigationSelected = this.playerView.navigationIds.player;
                this.playerView.setPlayerControlFocus(elmOnOver);       // sets focus to 'fs_button'

                this.playerView.controlSelected = this.playerView.controlIds.fullscreen; // Fullscreen btn
                this.playerView.setPlayBtnOverMC();

        },
        
        // MAGIC control handler for Stop button : onMouseOver
        magicCtrView3StopMouseOver: function(obj){    
            
                
                var elmCurrentFocus; 
                // Get the element currently in focus
                //elmCurrentFocus = TVA.onHover;
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);

                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);
                
                if (elmCurrentFocus == 'play_button'){
                        //this.playerView.offFocus('play_button_over');
                }
                else {
                        this.playerView.offFocus(elmCurrentFocus);
                }
                
                if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos){
                        this.playerView.hidePlayButton();
                }
                
                this.playerView.navigationSelected = this.playerView.navigationIds.player;
                this.playerView.setPlayerControlFocus(elmOnOver);                   // sets focus to 'stop_button'

                this.playerView.controlSelected = this.playerView.controlIds.stop; // Stop btn
                this.playerView.setPlayBtnOverMC();

        },
        
        // MAGIC control handler for button up/down : onMouseOut
        magicCtrView3ArrMouseOut: function(direction){
            
                if ( direction == 'up'){
                    
                        console.log('+++DOWN UP' );
                        $('div.videorelated_arrow_up_sel').css("visibility", "hidden");
                    
                }
                else if( direction == 'down' ){
                    
                        console.log('+++DOWN OUT' );
                        $('div.videorelated_arrow_dwn_sel').css("visibility", "hidden");
                } 
            
        },
        
        // MAGIC control handler for button up/down : onMouseOver
        magicCtrView3ArrMouseOver: function(direction){
                
                var elmCurrentFocus; 
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                
                if ( this.playerView.navigationSelected == this.playerView.navigationIds.player ){
                        this.playerView.offFocus(elmCurrentFocus);
                        this.playerView.navigationSelected = this.playerView.navigationIds.relatedVideos;
                        this.playerView.controlSelected = null;
                }
                else if ( this.playerView.navigationSelected == this.playerView.navigationIds.backButton){
                    
                        this.offFocus('player_back_btn');
                        this.playerView.navigationSelected = this.playerView.navigationIds.relatedVideos;
                }
                
                console.log('+++playerView.focusedID:' + this.playerView.focusedID);
                this.playerView.setFocus(this.playerView.focusedID);
                this.playerView.thumbId = this.playerView.focusedID.substr(14);
                console.log('+++thumbId:' + this.playerView.thumbId);
                this.playerView.displayPlayButton();
                
                // set button up/dwn rollover
                if ( direction == 'up'){
                        $('div.videorelated_arrow_up_sel').css("visibility", "visible");
 
                }
                else if( direction == 'down' ){
                        $('div.videorelated_arrow_dwn_sel').css("visibility", "visible");

                }

                this.playerView.setPlayBtnOverMC();                           
                
        },
        
        // MAGIC control handler for Stop button : onClick
        magicCtrView3StopClick: function(){
                this.keyStop();


        },

                    
        
        // MAGIC control handler for Fullscreen button : onClick
        magicCtrView3FullscreenClick: function(){  
            
                this.goFullscreen();
                this.playbackUI.show();
                this.puiVisible = true;
                setTimeout( 
                    function(){
                    this.$el_pui = $('#playbackUI'); 
                    this.$el_pui.hide();
                    }, 
                    3000
                );
                this.puiVisible = false;

        },
        
        // MAGIC control handler for Play/pause button : onClick
        magicCtrView3PlayPauseClick: function(){

                if (this.player.status == this.player.state.PLAYING || this.player.status == this.player.state.PAUSED){

                        this.playerView.setPlayBtn(this.player.status);
                        this.keyPause();
                }
                else if (this.player.status == this.player.state.STOPPED) {

                        this.keyPlay();

                }
        },
        
        magicCtrView3ArrDownClick: function(){
                
                if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos){
                        console.log('thumbId: ' + this.playerView.thumbId  );
                    
                        if(this.playerView.thumbId == this.playerView.numberOfRelVideos - 1){           // last

                                return;
                        }

                        else if(this.playerView.thumbId < this.playerView.thumbsLength - 1){
                                this.playerView.offFocus(this.playerView.focusedID);
                                this.playerView.thumbId++;
                                this.playerView.setFocus(this.playerView.thumbName + this.playerView.thumbId);

                                this.playerView.displayPlayButton();
                        }else{
                                this.playerView.updateRelatedVideoList('down');
                        } 
                } 
 
        },
        
        magicCtrView3ArrUpClick: function(){

                
                if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos){
                    
                        console.log('+++ navigationSelected(relVid): ' +this.playerView.navigationSelected);
                        if(this.playerView.thumbId == this.playerView.numberOfRelVideos - 1){           // last
                                return;
                        }

                        else if(this.playerView.thumbId < this.playerView.thumbsLength - 1){
                                this.playerView.offFocus(this.playerView.focusedID);
                                this.playerView.thumbId++;
                                this.playerView.setFocus(this.playerView.thumbName + this.playerView.thumbId);

                                this.playerView.displayPlayButton();
                        }else{
                                this.playerView.updateRelatedVideoList('down');
                        } 
                } 
                
                if (this.playerView.navigationSelected == this.playerView.navigationIds.relatedVideos){
                    
                        if (this.playerView.thumbId > 0 && this.playerView.startThumbId == 0 ){
                                this.playerView.offFocus(this.playerView.thumbName + this.playerView.thumbId);
                                this.playerView.thumbId = --this.playerView.thumbId;
                                this.playerView.setFocus(this.playerView.thumbName + this.playerView.thumbId);
                                this.playerView.displayPlayButton();
                                TVA.log('[categoryView] [moveUp] this.thumbId: ' + this.playerView.thumbId);
                        }else{
                                this.playerView.updateRelatedVideoList('up');
                        }
                    
                }
            
        },
        
        // View playbackUI
        // MAGIC control handler for Play/Pause button : onMouseOver
        magicCtrViewPUIPlayPauseMouseOver: function(obj){   
                var elmCurrentFocus; 
                // Get the element currently in focus
                //elmCurrentFocus = TVA.onHover;
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);   
                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);
                this.playbackUI.offFocus(elmCurrentFocus); 
                this.playbackUI.setPlayerControlFocus('play_button_pui');       // !!! sets focus to 'play_button' not to var 'elmOnOver'
                this.playbackUI.controlSelected = 0; // Play/Pause btn
                this.playbackUI.setPlayBtnOverMC();                           // sets rollover
        },
        
        // MAGIC control handler for Play/pause button : onClick
        magicCtrViewPUIPlayPauseClick: function(){
                if (this.player.status == this.player.state.PLAYING || this.player.status == this.player.state.PAUSED){
                        this.playbackUI.setPlayBtn(this.player.status);
                        this.keyPause();
                }
                else if (this.player.status == this.player.state.STOPPED) {

                        this.keyPlay();

                }
        },
        
        magicCtrViewPUIStopMouseOver: function(obj){     
                var elmCurrentFocus; 
                // Get the element currently in focus
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                // Get the id for element with status MouseOver
                elmOnOver = obj.id;
                console.log('+++elmOnOver:' + elmOnOver);
                this.playbackUI.offFocus(elmCurrentFocus);
                this.playbackUI.setPlayerControlFocus(elmOnOver);                   
                this.playbackUI.controlSelected = this.playbackUI.controlIds.stop;  
                this.playbackUI.setPlayBtnOverMC();
        },
        
        // MAGIC control handler for Stop button : onClick
        magicCtrViewPUIStopClick: function(){
                //this.puiStop();
                TVA_Player.stop();
                TVA_Player.playPos = 0;
                this.playbackUI.controlSelected = 0;
                this.playbackUI.resetFocus();
                this.playbackUI.resetProgress();
                this.playbackUI.hide(); 
                clearTimeout(this.timeoutHandle);
                this.goBackFromFullscreen();
                this.playerView.setPlayerControlFocus('fs_button');       // set focus bck to 'fs_button'
                this.playerView.resetPlayBtn();
                this.playerView.resetProgress();
        },
        
        // MAGIC control handler for Back button : onMouseOver
        magicCtrViewPUIBackMouseOver: function(){       
                var elmCurrentFocus; 
                elmCurrentFocus = TVA.onFocus;
                console.log('+++elmCurrentFocus:' + elmCurrentFocus);
                this.playbackUI.offFocus(elmCurrentFocus);                  // off focus 'fs_button' in plyer view
                this.playbackUI.setPlayerControlFocus('back_text_id');       
                this.playbackUI.controlSelected = this.playbackUI.controlIds.back; 
                this.playbackUI.setPlayBtnOverMC();
        },
        
        magicCtrViewPUIBackClick: function(){
                this.playbackUI.controlSelected = 0;
                //this.playbackUI.resetFocus();
                this.playbackUI.resetProgress();
                this.playbackUI.hide(); 
                clearTimeout(this.timeoutHandle);
                this.goBackFromFullscreen();
                this.playerView.setPlayerControlFocus('fs_button');       // set focus bck to 'fs_button'
            
        },
        
        // View 04 :categoryListView
        
        // MAGIC control handler for Back Button : onClick
        magicCtrView4VolverClick: function(){
                
                this.categoryListView.hide();        
                this.pageHistory.shift();
                for (var i = 0; i < this.pageHistory.length; i++){

                        TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                }

                this.infobar.setFocus( this.infobar.getFocusedId() );
                $('#infoBar').show();
                this.activeView = this.activeViews.homeView;
                this.activeCatgView = 1;
                this.footer.showFooter(1);
                this.footer.hideFooter(2);
                this.footer.hideFooter(3);         
        },
        
        
        
        // MAGIC control handler for Back Button : onMOuseOver
        magicCtrlView4BackMouseOver: function(obj){           
            var elmCurrentFocus; 
            // Get the id for element with status MouseOver
            elmOnOver = obj.id;
            console.log('+++elmOnOver:' + elmOnOver);

            // Get the element currently in focus
            elmCurrentFocus = TVA.onHover;
            console.log('+++ elmCurrentFocus:' + elmCurrentFocus);

            this.categoryListView.setFocus(elmOnOver); 
            this.categoryListView.offFocus(elmCurrentFocus);
            
            // off focus letter
            if(this.categoryListView.activeLetterEl){
                    this.categoryListView.activeLetterEl.removeClass('alphabet_current');
            }

        },
        
        // MAGIC control handler for All Catgs View Button : onClick
        magicCtrView4CatgButtonClick: function(){
            this.suspend = true;
            this.preloadBkgSwap('categoryView');
                      
            var el = $('#'+this.categoryListView.focusedID); 
            this.categoryListView.focusCol = parseInt(el.attr('data-col'));
            this.categoryListView.focusRow = parseInt(el.attr('data-row'));
            
            this.categoryListView.hide();
            var categoryId = this.categoryListView.getCategoryId();
            /* MILANO */
            if(this.catgNavigDataHistory) {
                //this.catgNavigDataHistory = categoryId;
                this.catgNavigDataHistory.push(categoryId);
            }
            this.loadCategoryVideoView(categoryId);
            this.pageHistory.unshift(this.activeViews.categoryView);

        },
        
        magicCtrView4CatgButtonMouseOver: function(obj  ){           
            var elmCurrentFocus;
            // Get the id for element with status MouseOver
            elmOnOver = obj.id;
            
            // Get the element currently in focus
            elmCurrentFocus = TVA.onFocus;
            console.log('+++ elmCurrentFocus:' + elmCurrentFocus);
		
            this.categoryListView.offFocus(elmCurrentFocus);
            this.categoryListView.setFocus(elmOnOver); 
            
            // offFocus letter
            if(this.categoryListView.activeLetterEl){
                    this.categoryListView.activeLetterEl.removeClass('alphabet_current');
            }
            
            // focus letter
            var letter = $('#'+this.categoryListView.focusedID).attr('data-l');
            
            if(letter){
                    this.categoryListView.activeLetterEl = this.categoryListView.el.find('div[data-letter="'+letter+'"]');
                    this.categoryListView.activeLetterEl.addClass('alphabet_current');
            }

        },
        
        magicCtrView4ArrMouseOver: function(direction){


                if (this.categoryListView.focusedID == 'catListgBackButton' ){
	                this.categoryListView.offFocus('catListgBackButton');
                        this.categoryListView.focus();
	            //    this.categoryView.setFocus(this.categoryListView.thumbName + this.categoryView.thumbId);
                }

                if ( direction == 'next'){
                        console.log('NEXT');
                        this.nextArrowSelEl = $('div.categorylistalphabetic-arrow-r_sel');
                        this.nextArrowSelEl.css("visibility", "visible");
                }
                else if( direction == 'prev' ){
                        console.log('PREV');
                        this.prevArrowSelEl = $('div.categorylistalphabetic-arrow-l_sel');
                        this.prevArrowSelEl.css("visibility", "visible");
                }
            
        },
        
        magicCtrView4ArrMouseOut: function(direction){
            
                if ( direction == 'next'){
                        this.nextArrowSelEl = $('div.categorylistalphabetic-arrow-r_sel');
                        this.nextArrowSelEl.css("visibility", "hidden");
                }
                else if( direction == 'prev' ){
                        this.prevArrowSelEl = $('div.categorylistalphabetic-arrow-l_sel');
                        this.prevArrowSelEl.css("visibility", "hidden");
                }
            
        },
        
        
        magicCtrView4ArrowR:function(){
            
                var el = $('#'+this.categoryListView.focusedID);
                this.categoryListView.moveCategories(el, 'right');
            
        },
        
        magicCtrView4ArrowL:function(){
            
            
                var el = $('#'+this.categoryListView.focusedID);
                this.categoryListView.moveCategories(el, 'left');
            
        },
        
        // MAGIC control handler for button Volver in footer : onClick
        magicCtrFooterVolverClick: function(){

                if(this.categoryView.isVisible()){
                        // Set preload background
                        //this.preloadBkgSwap('remove');

                        this.categoryView.hide();    
                        this.pageHistory.shift();
                        for (var i = 0; i < this.pageHistory.length; i++){
                                TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                        }

                        switch(this.pageHistory[0]){
                                    case this.activeViews.homeView:
                                            this.categoryView.hide();
                                            this.infobar.setFocus( this.infobar.getFocusedId() );
                                            $('#infoBar').show();
                                            this.activeView = this.activeViews.homeView;
                                            this.footer.showFooter(1);
                                            this.footer.hideFooter(2);
                                            this.footer.hideFooter(3);
                                            break;
                                            
                                    case this.activeViews.playerView:
                                            this.suspend = true;                       
                                            var categoryIndex = this.infobar.getCatgIndex();
                                            TVA.log('[Main] [keyDown] [KEY_ENTER] infobar.catgIndex: '+ categoryIndex);

                                            // call for category videos
                                            var categoryId = this.catgNavigData[categoryIndex][2];
                                            this.catgNavigDataHistory =  categoryId;
                                            var viewId = 'cv';
                                            this.loadHomeCategory(categoryId, viewId );
                                            break;

                                    case this.activeViews.categoryListView:
                                            this.categoryView.hide();
                                            $('#categoryListView').show();
                                            //this.categoryView.setFocus(this.categoryView.getFocusedId());
                                            this.activeView = this.activeViews.categoryListView;
                                            this.footer.hideFooter(1);
                                            this.footer.hideFooter(3);
                                            this.footer.showFooter(2);
                                            break;

                                    // if going from A tu casa le toca to category view:        
                                    case this.activeViews.categoryView:
                                            TVA.log('BACK TO CATEGORY VIEW ');

                                            var categoryIndex = this.infobar.getCatgIndex();
                                            TVA.log('categoryIndex: ' + categoryIndex );

                                            var categoryId = this.catgNavigData[categoryIndex][2];
                                            TVA.log('categoryId: ' + categoryId );

                                            this.loadCategoryVideoView(categoryId);

                                            this.activeView = this.activeViews.categoryView;
                                            this.footer.hideFooter(1);
                                            this.footer.showFooter(2);
                                            this.footer.hideFooter(3);
                                            break;

                        }
                }
                                
                else if(this.playerView.isVisible()){
                        // FOOTER
                        this.footer.showFooter(2);
                        this.footer.hideFooter(1);
                        this.footer.hideFooter(3);

                        var categoryTitle;

                        this.playerView.offFocusPlayerView();
                        this.playerView.controlSelected = null;
                        this.playerView.hide();

                        // get title
                        if ( this.pageHistory[1] == this.activeViews.categoryView){
                                categoryIndex = this.infobar.getCatgIndex();
                                categoryTitle = this.catgNavigData[categoryIndex][0];
                                this.activeView = this.activeViews.categoryView;
                        }
                        else if ( this.pageHistory[1] == this.activeViews.aTuCasaLeToca){
                                categoryTitle = 'A tu casa le toca...';
                                this.activeView = this.activeViews.aTuCasaLeToca;
                        }

                        this.categoryView.show(categoryTitle, this.catgVideos);             
                        this.categoryView.setFocus( this.categoryView.getFocusedId() );     
                        this.categoryView.displayPlayButton(); 
                        this.preloadFlag = true;
                        if (settings.device == 'philips' || settings.device == 'googletv'){
                                var content = $('#content');
                                content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                        }

                        this.pageHistory.shift();

                }
                                
                // Back from fullscreen
                else if ( this.player.getFullscreenFlag() == 1 ){
                        	this.goBackFromFullscreen();
                }
                                
                else if(this.categoryListView.isVisible()){
                        // Set Preload Backgroud
                        this.preloadBkgSwap('remove');

                        //this.categoryListView.hide();
                        this.activeCatgView = 1;

                        this.pageHistory.shift();
                        for (var i = 0; i < this.pageHistory.length; i++){
                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                        }

                        switch(this.pageHistory[0]){
                                case this.activeViews.homeView:
                                        this.categoryListView.hide();
                                        this.infobar.setFocus( this.infobar.getFocusedId() );
                                        $('#infoBar').show();
                                        this.activeView = this.activeViews.homeView;
                                        this.footer.showFooter(1);
                                        this.footer.hideFooter(2);
                                        this.footer.hideFooter(3);
                                        break;

                                case this.activeViews.categoryView:
                                        /* MILANO */
                                        // this.loadCategoryVideoView(this.catgNavigDataHistory);
                                        //var prevItem = this.catgNavigDataHistory[this.catgNavigDataHistory.length - 2];
                                        if(this.catgNavigDataHistory.length == 1) {
                                        var prevItem = this.catgNavigDataHistory[this.catgNavigDataHistory.length - 1];
                                        } else {
                                            var prevItem = this.catgNavigDataHistory[this.catgNavigDataHistory.length - 2];
                                        }
                        
                        
                        
                                        this.loadCategoryVideoView(prevItem);
                                        
                                        this.categoryListView.hide();
                                        $('#categoryView').show();
                                        this.categoryView.setFocus(this.categoryView.getFocusedId());
                                        this.categoryView.displayPlayButton();
                                        this.activeView = this.activeViews.categoryView;
                                        this.footer.hideFooter(1);
                                        this.footer.showFooter(2);
                                        this.footer.hideFooter(3);
                                        break;
                                        
                                case this.activeViews.playerView:   
                                        this.suspend = true;                       
                                        var categoryIndex = this.infobar.getCatgIndex();
                                        TVA.log('[Main] [keyDown] [KEY_ENTER] infobar.catgIndex: '+ categoryIndex);

                                        // call for category videos
                                        var categoryId = this.catgNavigData[categoryIndex][2];
                                        TVA.log('[Main] [keyDown] [KEY_ENTER] categoryId: '+ categoryId);
                                        var viewId = 'clv';
                                        this.loadHomeCategory(categoryId, viewId);
                                        break;

                                case this.activeViews.aTuCasaLeToca:
                                        this.categoryListView.hide();
                                        $('#categoryView').show();
                                        this.activeView = this.activeViews.aTuCasaLeToca;
                                        this.footer.hideFooter(1);
                                        this.footer.showFooter(2);
                                        this.footer.hideFooter(3);
                                        break;

                        }
                }
                else if (this.activeView == this.activeViews.aTuCasaLeToca){
                            this.categoryView.hide();    
                                    this.pageHistory.shift();
                                    for (var i = 0; i < this.pageHistory.length; i++){
                                            TVA.log('[Main] [keyDown ]  pageHistory ['+i+'] :' + this.pageHistory[i] );
                                    }

                                    
                                    switch(this.pageHistory[0]){
                                                case this.activeViews.homeView:
                                                        this.infobar.setFocus( this.infobar.getFocusedId() );
                                                        $('#infoBar').show();
                                                        this.activeView = this.activeViews.homeView;
                                                        this.footer.showFooter(1);
                                                        this.footer.hideFooter(2);
                                                        this.footer.hideFooter(3);
                                                        break;

                                                case this.activeViews.playerView:
                                                        $('#playerView').show();
                                                        this.activeView = this.activeViews.playerView;
                                                        this.footer.hideFooter(1);
                                                        this.footer.hideFooter(3);
                                                        this.footer.showFooter(2);
                                                        break;
                                                        
                                                case this.activeViews.categoryListView:
                                                        $('#categoryListView').show();
                                                        //this.categoryView.setFocus(this.categoryView.getFocusedId());
                                                        this.activeView = this.activeViews.categoryListView;
                                                        this.footer.hideFooter(1);
                                                        this.footer.hideFooter(3);
                                                        this.footer.showFooter(2);
                                                        break;
                                        
                                   }
                }
                        
                else{
                        this.unload();
                }
       
        },
        
        initZoom: function(){
            if(TVA.device == 'googletv'){
                var w = 1280;//screen.width;
                var h = 720;//screen.height;

                var bw = window.innerWidth;
                var bh = window.innerHeight;

                var wRatio = bw/w;
                var hRatio = bh/h;
                var ratio = (wRatio + hRatio) / 2;

                document.getElementsByTagName('body')[0].style.zoom = ratio;
            }
        },
        
        resetHistory: function(){
            this.pageHistory = [];
            this.pageHistory[0] = this.activeViews.homeView;
        }
        
};