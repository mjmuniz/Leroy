window.CategoryListView = CategoryListView = {
	
    header:     '<div class="head_wrapper">'+ 
    '<div class="lm_logo"></div>'+
    '<div class="head_text">'+
    '<span>El canal de ideas<br> y consejos para tu casa</span>'+
    '</div>'+
    '<div class="head_subtext">Inicio > <span>Todas las categorías</span></div>'+
    '</div>',

    buttons:    
    '<div id="btn_back_clw_anchor" ></div>'+
    '<div id="catListgBackButton" class="btn_backtostart_catview" onclick="Main.magicCtrView4VolverClick()" onmouseover="Main.magicCtrlView4BackMouseOver(this)" >' + 
            '<div class="btn_backtostart_slice_l_catview"></div>' +
            '<div class="btn_backtostart_slice_c_catview" >Volver al inicio</div>' +
            '<div class="btn_backtostart_slice_r_catview"></div>' +
    '</div>' +
        
    // ARROW RIGHT   
    '<div class="categorylistalphabetic-arrow-r"  onmouseover="Main.magicCtrView4ArrMouseOver(\'next\')">' +
            '<div> <img id="videogrid-arrow-r" src="./resources/img/buttons/button_next.png"> </div>'+
    '</div>' +
    '<div class="categorylistalphabetic-arrow-r_sel" onclick="Main.magicCtrView4ArrowR()" onmouseout="Main.magicCtrView4ArrMouseOut(\'next\')" >' +
            '<div> <img id="videogrid-arrow-r" src="./resources/img/buttons/button_next_selected.png"> </div>'+
    '</div>' +
    
    
    // ARROW LEFT
    '<div class="categorylistalphabetic-arrow-l"  onmouseover="Main.magicCtrView4ArrMouseOver(\'prev\')">' +
            '<div> <img id="videogrid-arrow-r" src="./resources/img/buttons/button_prev.png"> </div>'+     
    '</div>'+
    '<div class="categorylistalphabetic-arrow-l_sel" onclick="Main.magicCtrView4ArrowL()" onmouseout="Main.magicCtrView4ArrMouseOut(\'prev\')">' +
            '<div> <img id="videogrid-arrow-r" src="./resources/img/buttons/button_prev_selected.png"> </div>'+     
    '</div>',
                            
    categorylist:           
    '<div class="all_catg_list_wrapper">' +
    '<div id ="alphabet_anchor"></div>' +
    '</div>',  
	
    focusedID : null,
    focusCol: 0,
    focusRow: 0,
    index: 0,
    maxIndex: 0,
        	
	
    render : function (el) {
	this.el = el = $(el || '#categoryListView');
        this.hide();
	el.append(this.header);
	el.append(this.buttons);
        el.append(this.categorylist);
	this.setBackground();
        this.fixPhilipsButton_clw();
    },
	
    hide : function () {
	$('#categoryListView').hide();
    },
	
    isVisible : function () {
	return $(this.el).is(':visible');
    },
    
    fixPhilipsButton_clw: function(){
            
                if ( settings.device == 'philips'){
                        var phButton =
                        '<div class="btn_backtostart_catview">' + 
                                '<div class="btn_backtostart_slice_l_catview"></div>' +
                                '<div class="btn_backtostart_slice_c_catview" >Volver al inicio</div>' +
                                '<div class="btn_backtostart_slice_r_catview"></div>' +
                        '</div>';
                }
                
                $('#btn_back_clw_anchor').append(phButton);
        },
        	
    show : function () {
	$('#categoryListView').show(); 
        
        if (this.focusedID == null){
            this.focusedID = 'catg_list_thumb0'
        }
            TVA.setFocus(this.focusedID);
    },
	
    setBackground : function () {
	this.$el_category_view = $('#categoryListView');
	this.$el_category_view.css('background','transparent url("./resources/img/bkg2.jpg") no-repeat left top');
    },
	
    moving : function (direction) {
	var el = $('#'+this.focusedID);
	
	if(el && el.length){
	    if(el.hasClass('category_btn')){
		// cats
		this.moveCategories(el, direction);
		
	    }else{
		// volver              
                if (direction != 'left'){
                    this.focusRow = 0;
                    this.focus();  
                    
                }
	    }
	}
    },
    
    moveCategories: function(focused, direction){
	var id;
	
	var col = this.focusCol = parseInt(focused.attr('data-col'));
	var row = this.focusRow = parseInt(focused.attr('data-row'));
	
	if(this.activeLetterEl){
	    this.activeLetterEl.removeClass('alphabet_current');
	}
	
	if(direction == 'right'){
	    if(col == 4){
		this.index ++;
		
		if(this.index > this.maxIndex){
		    this.index = this.maxIndex;
		}
		
		this.renderCategories();
		
	    }else{
		this.focusCol = col+1;
	    }
	    
	}else if(direction == 'left'){
	    if(col == 0){
		this.index --;
		
		if(this.index < 0){
		    this.index = 0;
                    this.focusBackButton();
                    return;          
		}
		
		this.renderCategories();
		
	    }else{
		this.focusCol = col-1;
	    }
	    
	}else if(direction == 'down'){
	    if(row == 0){
		this.focusRow ++;
	    }
	    
	}else if(direction == 'up'){
	    if(row == 1){
		this.focusRow --;
		
	    }else{
		this.focusBackButton();
		return;
	    }
	}
	
	if(id = this.el.find('[data-col="'+this.focusCol+'"][data-row="'+this.focusRow+'"]').attr('id')){
	    this.setFocus(id);
	    
	}else if(id = this.el.find('[data-col="'+this.focusCol+'"][data-row="0"]').attr('id')){
	    this.focusRow = 0;
	    this.setFocus(id);

	}else{
	    this.setFocus(focused.attr('id'));
	}
	
	var letter = $('#'+this.focusedID).attr('data-l');
	
	if(letter){
	    this.activeLetterEl = this.el.find('div[data-letter="'+letter+'"]');
	    this.activeLetterEl.addClass('alphabet_current');
	}
    },
	
    focusBackButton: function(){
	this.offFocus(this.focusedID);
	this.setFocus('catListgBackButton');		
    },
	
    offFocus : function (id) {
	if (id) {
	    TVA.offFocus(id);
	}
    },
	
    offHover : function (id) {
	if (id) {
	    TVA.offHover(id);
	}
    },
	
    setFocus : function (id) {
	if(this.focusedID){
	    this.offFocus(this.focusedID);
	}
	
	this.offHover(id);
	TVA.setFocus(id);
	this.focusedID = id;
    },
	
    showInfobar : function () {
	TVA.log('[categoryView] [showInfobar] ');
	$('#categoryView').hide();
	$('#infoBar').show(); 
    },
	
    getFocusedId : function () {
	return this.focusedID;
    },
    
    renderLayout: function(data){
	this.data = data || [];
	this.index = 0;
	this.maxIndex = this.getMaxIndex();
	
	var wrap = $('<div id="catg_list_view_wrapper" /></div>');
	wrap.appendTo(this.el.find('#alphabet_anchor'));
	
	this.renderCategories();
    },
    
    renderCategories: function(){
	var maxCols = 5, data, prevLetter = null, col = 0;
	var target_el = this.el.find('#catg_list_view_wrapper');
	target_el.empty();
	
	var renderCol = function(l, d, ci, col){
	    var el = $('<div>'
            +'<div class="char_catg_list_wrapper1">'
               +'<div class="letter'+(l ? ' alphabet' : '')+'" data-letter="'+String(l).toLowerCase()+'">'+(l ? l.toUpperCase() : '')+'</div>'
               +'<div id="catg_list_thumb'+ci+'" class="block category_btn" data-col="'+col+'" data-row="0" data-l="'+(d[1].title[0].toLowerCase())+'" data-hbid="'+d[1].id+'" onclick="Main.magicCtrView4CatgButtonClick()" onmouseover="Main.magicCtrView4CatgButtonMouseOver(this)">'
                  +'<span class="image">'
                     +'<div class="thumb_wrap"><img class="thumb_img" src="'+CONFIG.hollybyteBaseUrl+d[1].splash+'" width="105" height="103"><span class="category_btn_text">'+(d[1].title.split(/\s/)[0])+'</span></div>'
                  +'</span>'
                  +'<div class="item_focus">'
                     +'<div class="thumb_wrap"><img class="thumb_img item_focus" src="'+CONFIG.hollybyteBaseUrl+d[1].splash+'"  width="105" height="103"><span class="focus_btn_text">'+(d[1].title.split(/\s/)[0])+'</span></div>'
                  +'</div>'
               +'</div>'
	   
               +(d[2] ? '<div id="catg_list_thumb'+ci+'_b" class="block category_btn" data-col="'+col+'" data-row="1" data-l="'+(d[2].title[0].toLowerCase())+'" data-hbid="'+d[2].id+'" onclick="Main.magicCtrView4CatgButtonClick()" onmouseover="Main.magicCtrView4CatgButtonMouseOver(this)">'
                  +'<span class="image">'
                     +'<div class="thumb_wrap"><img class="thumb_img" src="'+CONFIG.hollybyteBaseUrl+d[2].splash+'"  width="105" height="103"><span class="category_btn_text">'+(d[2].title.split(/\s/)[0])+'</span></div>'
                  +'</span>'
                  +'<div class="item_focus">'
                     +'<div class="thumb_wrap"><img class="thumb_img item_focus" src="'+CONFIG.hollybyteBaseUrl+d[2].splash+'"  width="105" height="103"><span class="focus_btn_text">'+(d[2].title.split(/\s/)[0])+'</span></div>'
                  +'</div>'
               +'</div>' : '')
	   
            +'</div>'
         +'</div>');
	    el.appendTo(target_el);
	}

	for(var i = this.index; i < (this.index + maxCols); i++){
	    data = this.getDataCol(i);

	    if(data){
		renderCol((prevLetter != data[0] ? data[0] : ''), data, i, col);
		prevLetter = data[0];
	    }
	    
	    col ++;
	}

	this.el.find('.categorylistalphabetic-arrow-l img').toggle(this.index > 0);
	this.el.find('.categorylistalphabetic-arrow-r img').toggle(this.index != this.maxIndex);
        this.el.find('.categorylistalphabetic-arrow-l_sel img').toggle(this.index > 0);
        this.el.find('.categorylistalphabetic-arrow-r_sel img').toggle(this.index != this.maxIndex);
	
	this.focus();
    },
    
    getDataCol: function(index){
	var col = -1, k = 0;
	
	for(var i in this.data){
	    k = -1;
	    col ++;
	    
	    for(var j in this.data[i][1]){
		k ++;
		
		if(k && (k % 2 === 0)){
		    col ++;
		}
		
		if(col == index){
		    return [this.data[i][0], this.data[i][1][j], (this.data[i][1][(parseInt(j) + 1)] || null)];
		}
	    }
	}

	return null;
    },
    
    getMaxIndex: function(){
	var cols = 0;

	for(var i in this.data){
	    if(this.data[i][1] && this.data[i][1].length){
		cols += Math.ceil(this.data[i][1].length / 2);
	    }
	}

	return (cols - 5); // minus number of cols per page
    },
    
    focus: function(){
	this.setFocus(this.el.find('[data-col="'+this.focusCol+'"][data-row="'+this.focusRow+'"]').attr('id'));
	
	var letter = $('#'+this.focusedID).attr('data-l');
	
	if(letter){
	    this.activeLetterEl = this.el.find('div[data-letter="'+letter+'"]');
	    this.activeLetterEl.addClass('alphabet_current');
	}
    },
    
    getCategoryId: function(){
	return this.el.find('[data-col="'+this.focusCol+'"][data-row="'+this.focusRow+'"]').attr('data-hbid');
    }
	
};
