window.Footer = Footer = {


    template: '<div class="btn_wrapper" onclick="Main.unload()">'+
    '<div class="btn_salir"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()">'+ 
    '<div class="btn_volver"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()">'+ 
    '<div class="btn_footer btn_C"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div class="btn_wrapper" >'+
    '<div class="btn_footer btn_B"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',

    template2: '<div class="btn_wrapper" onclick="Main.unload()">'+
    '<div class="btn_salir"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()">'+ 
    '<div class="btn_volver"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="footer_yellow_btn2" class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()">'+ 
    '<div class="btn_footer btn_C"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div id="footer_green_btn2" class="btn_wrapper" >'+
    '<div class="btn_footer btn_B"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',

    templateLG1: '<div id="footer_exit_btn" class="btn_wrapper" onclick="Main.unloadExitLG()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
    '<div class="btn_salir"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_volver_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="footer_yellow_btn" class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_footer btn_C_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div id="footer_green_btn" class="btn_wrapper" onclick="Main.magicCtrGreenBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
    '<div class="btn_footer btn_B_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',

    templateLG2: '<div id="footer_exit_btn2" class="btn_wrapper" onclick="Main.unloadExitLG()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
    '<div class="btn_salir"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+

    '<div id="btn-volver2" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_volver_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="footer_yellow_btn2" class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_footer btn_C_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+

    '<div id="footer_green_btn2" class="btn_wrapper" onclick="Main.magicCtrGreenBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
            '<div class="btn_footer btn_B_lg"></div>'+
            '<div class="descriptiontext">'+
                    '<span>A tu casa le toca...</span>'+
            '</div>'+
    '</div>',

    templateLG3: '<div id="footer_exit_btn3" class="btn_wrapper" onclick="Main.unloadExitLG()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
    '<div class="btn_salir"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver3" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_volver_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="footer_yellow_btn3" class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+ 
    '<div class="btn_footer btn_C_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div id="footer_green_btn3" class="btn_wrapper" onclick="Main.magicCtrGreenBtnClick()" onmouseover="Main.magicCtrFooterBtnMouseOver(this)" onmouseout="Main.magicCtrFooterBtnMouseOut()">'+
    '<div class="btn_footer btn_B_lg"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',   

    templatePhil: '<div class="btn_wrapper" onclick="Main.unload()">'+
    '<div class="btn_salir_phil"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()">'+ 
    '<div class="btn_volver_phil"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()">'+ 
    '<div class="btn_footer btn_C_phil"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div class="btn_wrapper" >'+
    '<div class="btn_footer btn_B_phil"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',

    templateGoogle: '<div class="btn_wrapper" onclick="Main.unload()">'+
    '<div class="btn_salir_google"></div>'+
    '<div class="descriptiontext">'+
    '<span>Salir</span>'+
    '</div>'+
    '</div>'+
            
    '<div id="btn-volver" class="btn_wrapper" onclick="Main.magicCtrFooterVolverClick()">'+ 
    '<div class="btn_volver_google"></div>'+
    '<div class="descriptiontext">'+
    '<span>Volver</span>'+
    '</div>'+
    '</div>'+
            
    '<div class="btn_wrapper" onclick="Main.magicCtrYellowBtnClick()">'+ 
    '<div class="btn_footer btn_C_google"></div>'+
    '<div class="descriptiontext">'+
    '<span>Categorías</span>'+
    '</div>'+
    '</div>'+
    '<div class="btn_wrapper" >'+
    '<div class="btn_footer btn_B_google"></div>'+
    '<div class="descriptiontext">'+
    '<span>A tu casa le toca...</span>'+
    '</div>'+
    '</div>',
        
    
    renderVolver: function(viewNumber){
        if(settings.device.indexOf('samsung')!=-1){
                $('#footer' + viewNumber).html(this.template2)
        }
        else if (settings.device.indexOf('lg')!=-1){
            
                if (viewNumber == 1){
                    $('#footer' + viewNumber).html(this.templateLG1);
                }
                else if (viewNumber == 2){
                    $('#footer' + viewNumber).html(this.templateLG2);
                }
                else if (viewNumber == 3){
                    $('#footer' + viewNumber).html(this.templateLG3);
                }
                
        }
        else if (settings.device.indexOf('philips')!=-1){
                $('#footer' + viewNumber).html(this.templatePhil)
        }
        else if (settings.device.indexOf('googletv')!=-1){
                $('#footer' + viewNumber).html(this.templateGoogle)
        }
        
    },    
        
    renderNoVolver: function(viewNumber){
        if(settings.device.indexOf('samsung')!=-1){
                $('#footer' + viewNumber).html(this.template);      
        }
        else if (settings.device.indexOf('lg')!=-1){
                if (viewNumber == 1){
                    $('#footer' + viewNumber).html(this.templateLG1);
                }
                else if (viewNumber == 2){
                    $('#footer' + viewNumber).html(this.templateLG2);
                }
                else if (viewNumber == 3){
                    $('#footer' + viewNumber).html(this.templateLG3);
                }
        }
        else if (settings.device.indexOf('philips')!=-1){
                $('#footer' + viewNumber).html(this.templatePhil);
        }
        else if (settings.device.indexOf('googletv')!=-1){
                $('#footer' + viewNumber).html(this.templateGoogle)
        }
        
        $('#btn-volver').hide();
    },	

        
    hideFooter: function(viewNumber) {
        $('#footer' + viewNumber).hide();
    },
    
    showFooter: function(viewNumber){
        this.$el_yellowBtn =  $('#footer_yellow_btn2');
        this.$el_greenBtn =  $('#footer_green_btn2');
        if( Main.activeView == Main.activeViews.categoryListView){
            TVA.log('Main.activeView(categoryListView): ' + Main.activeView);
            if (! $(this.$el_greenBtn).is(':visible')){
                this.$el_greenBtn.show();
            }
            //hide yellow button
            this.$el_yellowBtn.hide();
        }
        else if ( Main.activeView == Main.activeViews.aTuCasaLeToca){
            TVA.log('Main.activeView (aTuCasaLeToca): ' + Main.activeView);

            if (! $(this.$el_yellowBtn).is(':visible')){
                this.$el_yellowBtn.show();
            }
            //hide green button
            this.$el_greenBtn.hide();
        }
        else{      
            if (! $(this.$el_yellowBtn).is(':visible')){
                TVA.log('Else Yellow: ' );
                this.$el_yellowBtn.show();
            }
            
            else if (! $(this.$el_greenBtn).is(':visible')){
                TVA.log('Else Green: ' );
                this.$el_greenBtn.show();
            }
        }
        $('#footer' + viewNumber).show();
    },
      
    render: function(viewNumber){
        // 1 = categoryView
        // 2 = categoryListView
        // 3 = playerView
        switch(viewNumber)
        {
            case 1:
                this.renderNoVolver(viewNumber);
                break;
            case 2:
                this.renderVolver(viewNumber);
                break;
            case 3:
                this.renderVolver(viewNumber); 
                break;
        }
    },
    
    offFocus: function(id){
            TVA.offFocus(id);
    },
    
    setFocus: function(id){
            TVA.log('footer setFocus ');
            TVA.setFocus(id);
    }

};
