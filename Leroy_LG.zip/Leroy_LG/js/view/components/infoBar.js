window.InfoBar = InfoBar = {   
        
        pageheader: '<div id="head" class="head_wrapper">'+ 
                            '<div class="lm_logo"></div>'+
			    '<div class="head_text">'+
			         '  <span>El canal de ideas<br> y consejos para tu casa</span>'+
			    '</div>'+
                            '<div class="head_subtext">Inicio</div>'+
                    '</div>',
            
        mainbox:   
                    '<div id="season" class="mainbox"></div>',
      
        categorynavig:            
                       '<div id="navigation" class="categories_wrapper">'+
                                '<div class="categories_head">Categorías</div>'+
                           
                           '<div class="btn_see_all_gr_wrap">' + 
                               
                                '<div id="btn_see_all_anchor" ></div>'+       

                                '<div id="see_all" class="btn_see_all_gr">' + 
                                    '<div class="btn_see_all_gr_l"></div>' +
                                    '<div class="btn_see_all_gr_c" onclick="Main.magicCtrVerTodas()" onMouseOver="Main.magicCtrGeneralMouseOver(this, true, null, 1)">Ver todas</div>' +
                                    '<div class="btn_see_all_gr_r"></div>' +
                                '</div>' +    
                                
                           '</div>'+  
                           
                                '<div class="category_btns_wrapper">'+
                                
                                    '<div class="btn_prev"  onmouseover="Main.magicCtrView1ArrMouseOver(\'prev\')" ></div>'+
                                    '<div class="btn_prev_selected" onclick="Main.magicCtrView1ArrowClick(\'prev\')"  onmouseout="Main.magicCtrView1ArrMouseOut(\'prev\')" ></div>'+
                                    
                                        '<div id="navig_anchor" ></div>'+       // navig_buttons

                                    '<div class="btn_next" onmouseover="Main.magicCtrView1ArrMouseOver(\'next\')" ></div>'+
                                    '<div class="btn_next_selected" onclick="Main.magicCtrView1ArrowClick(\'next\')"   onmouseout="Main.magicCtrView1ArrMouseOut(\'next\')" ></div>'+
                                '</div>'+

		        '</div>', 
        cachedContent: '<div id="cached_content" ></div>',
                                
        el: '#infoBar',
	focusedID: null,
	hoveredID: null,
	hoverDown: 'hoverDown',
  
	buttonName: 'info',
	buttonId: 0, 
	buttonsLength: 6,
	buttonSelected: false,
        catgNavigData: [],
        startCatgId : 0,        // id of category which is displayed in first navig. button
        catgIndex: null,
        
        navigationIds: {categoryNavig : 0, vertodasBtn : 1, vervideosBtn : 2},
        navigationSelected: null ,

	initialize: function(){
                this.navigationSelected = this.navigationIds.vervideosBtn;
                this.catgIndex = 0;
	},
        
   
        render: function(hbdata){
                this.catgNavigData = hbdata;
                TVA.log('this.catgNavigData.length: ' + this.catgNavigData.length);
                el = $('#infoBar');
                el.append(this.pageheader);
		el.append(this.mainbox);
                el.append(this.categorynavig);
                el.append(this.cachedContent);
                               
                // create html markup for buttons
                var catgNavigation = '';
                var i;
                for (i = 0; i < this.buttonsLength; i++){

                        var catgTitle = hbdata[i][0];
                        if (catgTitle.length >12){
                            catgTitle = catgTitle.substr(0, 13)+'...';
                        } 
                        
                        var thumnbnailUrl = this.categoryThumbImageUrl(hbdata[i][1]);

                        var buttonRender = this.renderCategoryButton({btnId : i, title : catgTitle, thumbUrl: thumnbnailUrl});

                        catgNavigation += buttonRender;

                }
                $('#navig_anchor').append(catgNavigation);
                
                this.fixPhilipsButton();
                           
                this.setFocus('see_videos'); 
                this.renderCachedButtons();
        },

        isVisible: function(){
		return $(this.el).is(':visible');    
	},
        
        fixPhilipsButton: function(){
            
                if ( settings.device == 'philips'){

                        var phButton =
                        '<div class="btn_see_all_gr">' + 
                                    '<div class="btn_see_all_gr_l"></div>' +
                                    '<div class="btn_see_all_gr_c" >Ver todas</div>' +
                                    '<div class="btn_see_all_gr_r"></div>' +
                        '</div>';
                }
                
                $('#btn_see_all_anchor').append(phButton);
        },
       
        renderSeasonalContent: function(seasonalContentData){
           
                TVA.log('[infoBar][renderSeasonalContent] --- start ');

                var sesonalTitle = seasonalContentData[0][0];
                var sesonalDescript = seasonalContentData[0][1];
                var sesonalSplashUrl = this.categoryThumbImageUrl(seasonalContentData[0][2]);
                $('#season').hide();
                var seasonalContent = this.renderSeasonalContentData({sesonaltitle : sesonalTitle, sesonaldescript : sesonalDescript, sesonalsplashurl:sesonalSplashUrl});
                
                $('#season').append(seasonalContent);
                
                this.setFocus('see_videos');
                
                $('div.mainbox_content_wrapper img.mainbox_image ').load(function(){
                        $('#navigation').css("display", "block");
                        $('#season').css("display", "block"); 
                        $('#head').css("display", "block"); 
                        
                        if (settings.device == 'philips' || settings.device == 'googletv'){

                                var content = $('#content');
                                content.css('background', 'transparent url("./resources/img/bkg2.jpg") no-repeat left top');
                        }
                        
                });
       },
       
       renderCategoryButton: function(opt){
                    
                return '<div id="info'+opt.btnId+'" class="block info_player" onclick="Main.magicCtrView1ThubnailClick(' + opt.btnId + ')" onMouseOver="Main.magicCtrView1ThubnailMouseOver(this)" >'+
                                           
                                '<span class="image">'+     
                                        '<div class="thumb">'+
                                                '<img class="mythumb" src="'+opt.thumbUrl+'"  width="105" height="103">'+

                                                '<span class="category_btn_text">'+opt.title+'</span>'+
                                        '</div>'+
                                '</span>'+
                                                            
                                '<div class="item_focus">'+
                                        '<div class="thumb">'+
                                                '<img class="mythumb item_focus" src="'+opt.thumbUrl+'"  width="105" height="103">'+

                                                '<span class="focus_btn_text">'+opt.title+'</span>'+
                                        '</div>'+                                                    
                                '</div>'+
                        '</div>';
	},
        
                                                                    
        renderSeasonalContentData: function(opt){
            
            return      '<div style="display:none"></div>'+
                        '<div class="maintext">A tu casa le toca...</div>'+
                        '<div class="mainbox_content_wrapper">'+
                            '<img class="mainbox_image" src="'+opt.sesonalsplashurl+'">'+

                            '<div class="mainbox_text_bkg">'+
      
                                '<div class="title_text">'+opt.sesonaltitle+'</div>'+       //Pintar y reparar paredes
                                '<div class="descriptiontext">'+opt.sesonaldescript+'</div>'+

                                '<div id="see_videos" class="btn_backtostart_catview">' + 
                                    '<div class="btn_backtostart_slice_l_catview resetter_btn"></div>' +
                                    '<div class="btn_backtostart_slice_c_catview setter_btn" onclick="Main.magicCtrVerVideos()" onMouseOver="Main.magicCtrGeneralMouseOver(this, true, null, 1)">&nbsp;Ver videos &nbsp;</div>' +
                                    '<div class="btn_backtostart_slice_r_catview setter_btn"></div>' +
                                '</div>' +                  
 
                            '</div>'+
                            '</div>'+
                        '</div>';
        },
        
        renderCachedButtons: function(){
            
                var cachedButtons = '';
                var i;
                var count = this.catgNavigData.length;
                TVA.log('count: ' + count);
                for (i = this.buttonsLength; i < count; i++){

                        var thumnbnailUrl = this.categoryThumbImageUrl(this.catgNavigData[i][1]);
                        var cButtonRender = '<img class="cached_img" src="'+ thumnbnailUrl +'" >';

                        cachedButtons += cButtonRender;
                }
                $('#cached_content').append(cachedButtons);
            
        },
        
	setStrings: function(){
            
	},
        
        moving: function(direction){

                switch(direction){
				case 'right':this.moveRight();break;
                                case 'left' :this.moveLeft();break;
                                case 'up'   :this.moveUp();break;
                                case 'down' :this.moveDown();break;
                }
	},
        
        moveRight: function(){
            
                if (this.navigationSelected == this.navigationIds.categoryNavig){
                        
                        if(this.buttonId < this.buttonsLength - 1){
                                this.offFocus(this.buttonName + this.buttonId);
                                this.buttonId++;
                                this.catgIndex++;
                                this.setFocus(this.buttonName + this.buttonId);
                                TVA.log('[infoBar] [moveRight] startCatgId: ' + this.startCatgId);
                                TVA.log('[infoBar] [moveRight] buttonId: ' + this.buttonId);
                                TVA.log('[infoBar] [moveRight] catgIndex: ' + this.catgIndex);

                                
                        }else{
                    
                                this.updateCategoryNavigation('right');

                        }   
                }
	},
        
        moveLeft: function(){
            
                if (this.navigationSelected == this.navigationIds.categoryNavig){
                        
                        if(this.buttonId > 0 && this.startCatgId == 0 ){        // within catg id of 0 to 5 
                                this.offFocus(this.buttonName + this.buttonId);
                                this.buttonId--;
                                this.catgIndex--;
                                this.setFocus(this.buttonName + this.buttonId);
                                TVA.log('[infoBar] [moveLeft] catgIndex: ' + this.catgIndex);

                        }else{
                            
                                this.updateCategoryNavigation('left');

                        }
                }
	},
        
        
        moveUp: function(){

                 if (this.navigationSelected < getObjLength(this.navigationIds)-1){

                        TVA.log('this.navigationSelected: ' + this.navigationSelected);
                    
                        switch(this.navigationSelected){

                                case this.navigationIds.categoryNavig:      // "See all" button focus
                                        var focusedCategory = this.buttonName+ this.buttonId;
                                        this.offFocus(focusedCategory);     // offFocus categoryNavig 
                                        this.setFocus('see_all');           // focus vertodasBtn
                                        this.navigationSelected++;
                                        break;
               
                                case this.navigationIds.vertodasBtn:        // "See videos" button focus
                                        this.offFocus('see_all');           // offFocus vertodasBtn
                                        this.setFocus('see_videos');        // focus vervideosBtn
                                        this.navigationSelected++;
                                        break;
                        }
                }
                
        },

              
        moveDown: function(){
            
                if (this.navigationSelected > 0){

                        TVA.log('this.navigationSelected: ' + this.navigationSelected);
                
                        switch(this.navigationSelected){

                                case this.navigationIds.vervideosBtn:        // "See all" button focus
                                        this.offFocus('see_videos');        // offFocus vervideosBtn
                                        this.setFocus('see_all');           // focus vertodasBtn
                                        break;
                                        
                                case this.navigationIds.vertodasBtn:        // "Category navigation" focus
                                        this.offFocus('see_all');           // offFocus vertodasBtn
                                        var focusedCategory = this.buttonName+ this.buttonId;
                                        this.setFocus(focusedCategory);     // setFocus categoryNavig
                                        break;            
                        }
                        
                        this.navigationSelected--;
                }

        },
  
	offHover: function(id){
		if(id){
			TVA.offHover(id);
		}
	},
	
	setTextHover: function(id){
		$('#'+id).addClass(this.hoverDown);
	},

	offTextHover: function(id){
		$('#'+id).removeClass(this.hoverDown);
	},

	setHover: function(id){
		this.offFocus(this.focusedID);
		this.offFocus(id);
		TVA.setHover(id);
		this.hoveredID = id;
	},

	offFocus: function(id){
		if(id){
			TVA.offFocus(id);
		}
	},
        
        offFocusHome: function(){
                TVA.offFocus(this.buttonName + this.buttonId);
        },

	setFocus: function(id){
		this.offHover(this.hoveredID);
		this.offHover(id);
		TVA.setFocus(id);
		this.focusedID = id;
	},
        
	removeFocus: function(){
		if(this.buttonSelected){
			this.buttonSelected = false;
			this.offFocus(this.buttonName + this.buttonId);
		}
	},
        
        hideInfobar: function(){
                TVA.log('[infoBar] [hideInfobar] ');
                $('#infoBar').hide();
        },
        
        categorySplashImageUrl: function(category){
            
                return CONFIG.hollybyteBaseUrl + 'acc/leroymerlin/pl/' + category+'/splash.jpg';

        },
        
        categoryThumbImageUrl: function(thumbUrl){
            
                return CONFIG.hollybyteBaseUrl + thumbUrl;

        },

        updateCategoryNavigation : function(direction){
            
                var limitStartCatgNumb = this.catgNavigData.length - (this.buttonsLength+0);  // unfilter last two catgs (Todos, A casa le toca..)
     
                this.$el_btnNextImage =  $('div.categories_wrapper div.category_btns_wrapper div.btn_next');
                this.$el_btnPrevImage =  $('div.categories_wrapper div.category_btns_wrapper div.btn_prev');
                
                if(direction == 'right'){
                    
                        if (this.startCatgId == limitStartCatgNumb ){ 

                                TVA.log('[infoBar] [updateCategoryNavigation] startCatgId: ' + this.startCatgId);
                                TVA.log('[infoBar] [updateCategoryNavigation] buttonId: ' + this.buttonId);
                                                                                                                                
                                return
                        }
                        else{
                            
                                this.startCatgId++;
                                this.catgIndex++;
                                TVA.log('[infoBar] [updateCategoryNavigation] startCatgId: ' + this.startCatgId);
                                TVA.log('[infoBar] [updateCategoryNavigation] limitStartCatgNumb: ' + limitStartCatgNumb);
                                TVA.log('[infoBar] [updateCategoryNavigation] buttonId: ' + this.buttonId);
                                TVA.log('[infoBar] [updateCategoryNavigation] catgIndex: ' + this.catgIndex);
                                

                                if (this.startCatgId > limitStartCatgNumb ){  
                                        return
                                }else{

                                        for (var i = 0, j= this.startCatgId; i < this.buttonsLength; i++, j++){ // unfilter last two catgs (Todos, A casa le toca..)

                                                // update titles
                                                this.$el_categoryText       =  $('#info'+i+' span.image div.thumb span.category_btn_text');
                                                this.$el_categoryTextFocus  =  $('#info'+i+' div.item_focus div.thumb span.focus_btn_text');
                                                this.$el_categoryText.html(this.catgNavigData[j][0]);
                                                this.$el_categoryTextFocus.html(this.catgNavigData[j][0]);

                                                // update images
                                                this.$el_thumbImageFocus      =  $('#info'+i+' div.item_focus div.thumb img.mythumb');
                                                this.$el_thumbImage           =  $('#info'+i+' span.image div.thumb img.mythumb');
                                                this.$el_thumbImageFocus.attr('src',  this.categoryThumbImageUrl(this.catgNavigData[j][1]));
                                                this.$el_thumbImage.attr('src',  this.categoryThumbImageUrl(this.catgNavigData[j][1]));

                                                // Hide btn_next:
                                                if(this.startCatgId == limitStartCatgNumb){
                                                    this.$el_btnNextImage.css("display","none");
                                                }
                                                
                                                // Show btn_prev
                                                if(this.startCatgId < limitStartCatgNumb){
                                                    //this.$el_btnPrevImage =  $('div.categories_wrapper div.category_btns_wrapper div.btn_prev');
                                                    this.$el_btnPrevImage.css("display","block");
                                                    this.$el_btnPrevImage.css("visibility", "visible");              
                                                }                                                     
                                                
                                        }
                                }
                            
                        }
                    
                        
                        
                        
                }
                else if (direction == 'left'){
                    
                        if (this.startCatgId == 0 ){ 

                                TVA.log('[infoBar] [updateCategoryNavigation] startCatgId: ' + this.startCatgId);
                                TVA.log('[infoBar] [updateCategoryNavigation] buttonId: ' + this.buttonId);
                                return
                        }
                        else{
                                this.$el_btnNextImage =  $('div.categories_wrapper div.category_btns_wrapper div.btn_next');
                                this.$el_btnNextImage.css("display","block");
                                

                                
                                this.startCatgId--;
                                this.catgIndex--;

                                TVA.log('[infoBar] [updateCategoryNavigation] startCatgId: ' + this.startCatgId);
                                TVA.log('[infoBar] [updateCategoryNavigation] buttonId: ' + this.buttonId);
                                TVA.log('[infoBar] [updateCategoryNavigation] catgIndex: ' + this.catgIndex);
  
                                for (var i = 0, j= this.startCatgId; i < this.buttonsLength; i++, j++){ // unfilter last two catgs (Todos, A casa le toca..)

                                        // update titles
                                        this.$el_categoryText       =  $('#info'+i+' span.image div.thumb span.category_btn_text');
                                        this.$el_categoryTextFocus  =  $('#info'+i+' div.item_focus div.thumb span.focus_btn_text');
                                        this.$el_categoryText.html(this.catgNavigData[j][0]);
                                        this.$el_categoryTextFocus.html(this.catgNavigData[j][0]);
                        
                                        // update images
                                        this.$el_thumbImageFocus    =  $('#info'+i+' div.item_focus div.thumb img.mythumb');
                                        this.$el_thumbImage         =  $('#info'+i+' span.image div.thumb img.mythumb');
                                        this.$el_thumbImageFocus.attr('src',  this.categoryThumbImageUrl(this.catgNavigData[j][1]));
                                        this.$el_thumbImage.attr('src',  this.categoryThumbImageUrl(this.catgNavigData[j][1]));

                                        // Hide btn_prev ou are within the 6 initial elements
                                        if(this.startCatgId == 0 ) {
                                            this.$el_btnPrevImage.css("display","block");
                                            this.$el_btnPrevImage.css("visibility", "hidden"); 
                                        }    
                                                
                                                
                       
                                }
                        
                        }
           
                }
      
        },
        
        getCatgIndex: function(){
		return this.catgIndex;
	},
        
        getFocusedId: function(){
            
                if (this.focusedID == null) {
                        return this.buttonName + this.buttonId;
                }
                else{
                        return this.focusedID;
                }  
        },
        
        getButtonId: function(){
                return this.buttonId;
        }
        
};
