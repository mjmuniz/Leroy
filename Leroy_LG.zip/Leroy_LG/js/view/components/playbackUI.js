window.PlaybackUI = PlaybackUI = {
             
                
        videocontrols: 
                    '<div class="videocontrols_wrapper">'+
                   
                            '<div id="play_button_pui" class="control_play_btn"> </div>'+

                            '<div id="control_play_button_over" onclick="Main.magicCtrViewPUIPlayPauseClick()" onmouseover="Main.magicCtrViewPUIPlayPauseMouseOver(this)"></div>'+
                            '<div id="stop_button_pui" class="control_stop_btn" onclick="Main.magicCtrViewPUIStopClick()" onmouseover="Main.magicCtrViewPUIStopMouseOver(this)"></div>'+ 
                            '<div class="progress_bar">'+
                                    '<div id="progress_pui" class="progress_value"></div>'+
                            '</div>'+

                            '<div id="back_button_pui" class="control_back_btn" onclick="Main.magicCtrViewPUIBackClick()"  onmouseover="Main.magicCtrViewPUIBackMouseOver()"  ></div>'+
                            '<div id="back_text_id" class="back_text">Volver</div>'+
                            '<div id="qmenu" class="qmenu" onclick="Main.magicCtrQmenuBtnClick()" onmouseover="Main.magicCtrQmenuBtnClickMouseOver(this)">&nbsp;</div>'+
                            //'<div id="message" style="color:red;"></div>'+
                    '</div>',
               
        el: '#playbackUI',
        
        // ID of focused related video
        focusedID: null,
        
        // ID of focused player controll
        focusedPlayerID: null,
        
        thumbName : 'relvideo_thumb',
        thumbId: 0,
        
        // Number of thumbs in related videos list:
        thumbsLength: 3, 
        
        numberOfRelVideos: null, 
        relVideosData: null,
        catgVideosData: null,
        
        // id of video thumb which is displayed as topmost in related video list
        startThumbId : 0,        
        
        // Fullscreen flag
        fullscreenFlag : 0,
        
        // Width of progress bar in pixels 
        progressBarWidth : 320,    
        controlIds: {play : 0, stop : 1, back : 2, qmenu : 3},
        controlSelected: null,
        
        playerStatus : null,
        
        progressTimer : null,
        
	initialize: function(){
            this.controlSelected = 0;
            this.focusedPlayerID = 'play_button_pui';
	},

	
	render: function(el){
		el = $(el || '#playbackUI');
                el.hide();
                el.append(this.videocontrols);   
                this.addPlatformBackIcon();
                
                // Enable QMENU only for LG
                if(TVA.device !== 'lg'){
                    $('#qmenu').hide();
                }
	},
        
        addPlatformBackIcon: function(){
            
            var device = TVA.device.toLowerCase();
            this.$el_pui_back_button = $('#back_button_pui');
            
            switch(device){
                
                case 'samsung':
                    this.$el_pui_back_button.css('background', 'transparent url("./resources/img/buttons/Back.png") no-repeat left top');
                    break;
                
                case 'lg':
                    this.$el_pui_back_button.css('background', 'transparent url("./resources/img/buttons/Back_lg.png") no-repeat left top');
                    break;
                    
                case 'philips':
                    this.$el_pui_back_button.css('background', 'transparent url("./resources/img/buttons/Back_phil.png") no-repeat left top');
                    break;
                    
                case 'googletv':
                    this.$el_pui_back_button.css('background', 'transparent url("./resources/img/buttons/Back_google.png") no-repeat left top');
                    break;   
            } 
            

        },
        
        
        updateProgress : function (){
                var percentPlayed = TVA_Player.getCurrentTime() / TVA_Player.getLength();       
                var progressBarWidth = Math.floor(this.progressBarWidth * percentPlayed) + 'px';
                this.$el_progressBar      =  $('#progress_pui');
                if(this.$el_progressBar){
                	this.$el_progressBar.css("width", progressBarWidth);
                }
        },
        

        startProgress: function(){
          this.progressTimer = window.setInterval(bind(this, this.updateProgress), 200);
        },

        resetProgress: function(){
        	this.$el_progressBar      =  $('#progress_pui');
        	if(this.$el_progressBar){
              if(this.progressTimer){
                window.clearInterval(this.progressTimer);
              }
            	this.$el_progressBar.css("width", "0px");
        	}
        },
      
        hide: function(){
                $('#playbackUI').hide();
        },
        
        isVisible: function(){
		return $(this.el).is(':visible');    
	},
        
        show: function(){
                $('#playbackUI').show();
                this.startProgress();
        },

        moving: function(direction, playerStatus){
            
                this.playerStatus = playerStatus;     
                switch(direction){
				case 'right':this.moveRight();break;
                                case 'left' :this.moveLeft();break;
                }
	},
        
        moveRight: function(){

                        TVA.log('[playbackUI] [moveRight] this.focusedPlayerID : ' + this.focusedPlayerID );
                        this.setControlFocus(this.controlSelected, 'right');
	},

        moveLeft: function(){
                        TVA.log('this.controlSelected: ' + this.controlSelected );
                        this.setControlFocus(this.controlSelected, 'left');  
                        
                        /*
                                        if (this.controlSelected > 0){
                                            
                                                this.setControlFocus(this.controlSelected, 'left'); 
                                                TVA.log('[playerView] [moveLeft] this.focusedPlayerID : ' + this.focusedPlayerID );
                                        }
                                        else{
                                                this.offFocus(this.focusedPlayerID);
                                                this.navigationSelected--;
                                                this.controlSelected = null;  
                                                this.setPlayBtnOver();
                                                TVA.setFocus('player_back_btn');
                                                
                                                this.$el_back_button_l = $('#player_back_btn div.btn_backtostart_slice_l');
                                                this.$el_back_button_l.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_l_focus.png") no-repeat  0 0');
                                                this.$el_back_button_c = $('#player_back_btn div.btn_backtostart_slice_c');
                                                this.$el_back_button_c.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_c_focus.png") repeat-x');
                                                this.$el_back_button_r = $('#player_back_btn div.btn_backtostart_slice_r');
                                                this.$el_back_button_r.css('background', 'transparent url("./resources/img/buttons/button_generic_sliced_r_focus.png") no-repeat  0 0');
                                                
                                        }
                         **/

	},
        
        setPlayBtnOver : function(){
            
                TVA.log('------------------controlSelected = ' + this.controlSelected );

                if (this.controlSelected != this.controlIds.play ) {
                        TVA.log('------------------controlSelected != this.controlIds.play = 0 '  );
                        TVA.log('this.playerStatus: ' + this.playerStatus);
                        if (this.playerStatus == Main.player.state.STOPPED || this.playerStatus == Main.player.state.PAUSED){
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/play.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (this.playerStatus == Main.player.state.PLAYING || this.playerStatus == Main.player.state.BUFFERING) {
                                TVA.log('------------------');
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pause.png") no-repeat left top');
                        }  
                }
                else if (this.controlSelected == this.controlIds.play){
            
                        TVA.log('this.playerStatus: ' + this.playerStatus);
                        
                        if (this.playerStatus == Main.player.state.STOPPED || this.playerStatus == Main.player.state.PAUSED){
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/playHighlight.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (this.playerStatus == Main.player.state.PLAYING || this.playerStatus == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pauseHighlight.png") no-repeat left top');
                        }

              }

        },
        
        setPlayBtnOverMC : function(){                  
                if (this.controlSelected != this.controlIds.play ) {

                        if (Main.player.status == Main.player.state.STOPPED || Main.player.status == Main.player.state.PAUSED){
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/playHighlight.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (Main.player.status == Main.player.state.PLAYING || Main.player.status == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pauseHighlight.png") no-repeat left top');
                        }  
                }
                else{
                        
                        if (Main.player.status == Main.player.state.STOPPED || Main.player.status == Main.player.state.PAUSED){
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/play.png") no-repeat left top');
                        }
                        // if playing or buffering:
                        else if (Main.player.status == Main.player.state.PLAYING || Main.player.status == Main.player.state.BUFFERING) {

                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pause.png") no-repeat left top');
                        }
                }
        },
 /*       
        togglePlayBtnOver : function(){
            TVA.log('[togglePlayBtnOver] BEFORE playerStatus='+this.playerStatus+' navigationSelected='+this.navigationSelected+' controlSelected='+this.controlSelected);
            TVA.log('B='+$('#play_button_over').css('background'));
                    if (this.navigationSelected == this.navigationIds.backButton || this.navigationSelected == this.navigationIds.relatedVideos ){
                            // if paused or stopped:
                            if (this.playerStatus == 2 || this.playerStatus == 0){
                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                            }
                            // if playing:
                            else if (this.playerStatus == 1) {

                                this.$el_play_button = $('#play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                            }
                    }
                    else if (this.navigationSelected == this.navigationIds.player) {
                        
                            if (this.controlSelected == this.controlIds.play){
                                

                                    if (this.playerStatus == 2 || this.playerStatus == 0){
                                                this.$el_play_button = $('#play_button_over');
                                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause02.png") no-repeat left top');
                                    }

                                    else if (this.playerStatus == 1) {

                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play02.png") no-repeat left top');
                                    }
  
                            }
                            else{

                                    if (this.playerStatus == 2 || this.playerStatus == 0){
                                                this.$el_play_button = $('#play_button_over');
                                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_pause01.png") no-repeat left top');
                                    }

                                    else if (this.playerStatus == 1) {

                                        this.$el_play_button = $('#play_button_over');
                                        this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/player_play01.png") no-repeat left top');
                                    }

                            }

                        
                    }
                    TVA.log('A='+$('#play_button_over').css('background'));
                    TVA.log('[togglePlayBtnOver] AFTER playerStatus='+this.playerStatus+' navigationSelected='+this.navigationSelected+' controlSelected='+this.controlSelected);
        },
    */    
        //  focusedPlayerID
      
        setControlFocus: function(id, direction){
                //$("#message").html("ID: " + id + " DIRECTION: " + direction);
                if (direction == 'left'){
                    
                        switch(id){
                                case this.controlIds.qmenu:
                                        if(TVA.device == 'lg'){
                                            this.offFocus(this.focusedPlayerID);
                                            this.setPlayerControlFocus('back_text_id');
                                            this.controlSelected-- ;
                                        }
                                        break;

                                case this.controlIds.back:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('stop_button_pui');
                                        this.controlSelected-- ;
                                        break;

                               case this.controlIds.stop:
                                    
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('play_button_pui');
                                       
                                        this.setPlayBtnOver();
                                        this.controlSelected--;
                                        break;


                                        
                        }
                }
                else if (direction == 'right'){
                        switch(id){
                            /*
                                case null:
                                        this.setPlayerControlFocus('play_button_pui');
                                        this.controlSelected = this.controlIds.play;
                                        this.setPlayBtnOver();
                                        break;
                            */
								// PLAY = 0 - START HERE
                                case this.controlIds.play:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('stop_button_pui');
                                        this.setPlayBtnOver();
                                        this.controlSelected++; // =1 Focus on STOP
                                        break;
                                        
                                case this.controlIds.stop:
                                        this.offFocus(this.focusedPlayerID);
                                        this.setPlayerControlFocus('back_text_id');
                                        this.controlSelected++;  // =2 Focus on RETURN
                                        break;
																			
				case this.controlIds.back:
                                        if(TVA.device == 'lg'){
                                            this.offFocus(this.focusedPlayerID);
                                            this.setPlayerControlFocus('qmenu');
                                            this.controlSelected++;  // =3 Focus on qmenu
                                        }
                                        break;                                   
                        }
  
                }
       
	},
        
        offFocus: function(id){
		if(id){
			TVA.offFocus(id);
		}
	},
        
        offFocusPlayerView: function(){
            
                if (this.navigationSelected == this.navigationIds.backButton){

                        this.offFocusBackButton();
                }   
        },
        
        offHover: function(id){
		if(id){
			TVA.offHover(id);
		}
	},

	setFocus: function(id){
		//this.offHover(this.hoveredID);
		this.offHover(id);
		TVA.setFocus(id);
		this.focusedID = id;
	},
        
        setPlayerControlFocus: function(id){
		//this.offHover(this.hoveredID);
		//this.offHover(id);
		TVA.setFocus(id);
		this.focusedPlayerID = id;
	},
       
        displayPlayButton: function(){
            
                this.$el_play_btn_offFoc = $('div.rel_video_thumb_wrapper div.play_btn');
                this.$el_play_btn_offFoc.css('display','none');
                this.$el_play_btn       = $('div.focus div.play_btn');
                this.$el_play_btn.css('display','block');
        },
        
        hidePlayButton: function(){
            
                this.$el_play_btn_offFoc = $('div.rel_video_thumb_wrapper div.play_btn');
                this.$el_play_btn_offFoc.css('display','none');
        },

        getFocusedId: function(){
            
                if (this.focusedID == null) {
                        return this.thumbName + this.thumbId;
                }
                else{
                        return this.focusedID;
                }  
        },
        
        resetFocus: function(){
                this.offFocus(this.focusedPlayerID);
                this.focusedID = 'play_button_pui';
                this.$el_play_button = $('#control_play_button_over');
                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pause.png") no-repeat left top');
        },
        
        resetPlayBtn: function(){
                this.$el_play_button = $('#control_play_button_over');
                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/playHighlight.png") no-repeat left top');
        },

        
        setPlayBtn : function(playerStatus) {       
                TVA.log('playerStatus: ' + playerStatus);
                        // if paused:
                        if (playerStatus == 2){
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/pause.png") no-repeat left top');
                        }
                        // if playing:
                        else if (playerStatus == 1) {
                                this.$el_play_button = $('#control_play_button_over');
                                this.$el_play_button.css('background', 'transparent url("./resources/img/playerview/play.png") no-repeat left top');
                        }
        },
        
        
        getFullscreenFlag: function(){
            
                return this.fullscreenFlag;
        },
        
        offFocusBackButton : function(){
            
                TVA.offFocus('player_back_btn');
        }
      	  
};