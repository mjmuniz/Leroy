window.Player = Player = {
        
        // Fullscreen flag
        fullscreenFlag : 0,
     
        // States of the player
        state : { STOPPED:0, PLAYING:1, PAUSED:2, CONNECTING:3, BUFFERING:4, FINISHED:5, ERROR:6, INIT:7 },
        
        // Current state of the player
        status : null,
        isrunning: false,
        isbuffered: false,
        skip: 5, // skip for backward/forward (in seconds)
        
        
        setFullscreen: function(){
                TVA.log('[playerView] [setFullscreen]' );
                this.fullscreenFlag = 1;
                if(TVA_Player.player && typeof TVA_Player.player.SetDisplayArea != 'undefined'){
                    // samsung
                    TVA_Player.player.SetDisplayArea(0, 0, 960, 540);
                }else{
                    TVA_Player.setWidth(1280);
                    TVA_Player.setHeight(720);
                    TVA_Player.setXY(0, 0);
                }
        },
        
        setSmallScreen: function(){
            
                this.fullscreenFlag = 0;

                if(TVA_Player.player && typeof TVA_Player.player.SetDisplayArea != 'undefined'){
                    // samsung
                    TVA_Player.player.SetDisplayArea(144, 150, 500, 281);
                }else{

                    TVA_Player.setXY(192, 200);
                    
                    if(settings.device == 'googletv'){
                        TVA_Player.setWidth(672);
                        TVA_Player.setHeight(382);
                    }
                    else{
                        TVA_Player.setWidth(666);
                        TVA_Player.setHeight(376);
                    }
   
                }

                if(this.status == this.state.PAUSED){
                	TVA_Player.pause(true);
                }
        },
        
        getFullscreenFlag: function(){
        	
            return this.fullscreenFlag;
        },
        
        getPlayerState : function(status){
            
            var playerState = (typeof status != 'undefined' && status != null) ? status : TVA_Player.getState();
            switch(playerState){
                
                    case TVA_Player.state.stopped:
                    		TVA.log('STOP!');
                            this.status = this.state.STOPPED;
                            this.isrunning = false;
                            Main.togglePlayer(false);
                            this.hideLoading();
                            break;
                            
                    case TVA_Player.state.playing:
                            this.status = this.state.PLAYING;
                            this.isrunning = true;
                           	this.isbuffered = false;
                            Main.togglePlayer(true);
                            this.hideLoading();
                            break;
                            
                    case TVA_Player.state.paused:
                    		TVA.log('PAUSED!');
                            this.status = this.state.PAUSED;
                            this.isrunning = true;
                            break;
                            
                    case TVA_Player.state.connecting:
                    case TVA_Player.state.buffering:
                    		this.isbuffered = true;
                            this.status = this.state.BUFFERING;
                            Main.togglePlayer(false);
                            this.showLoading();
                            break;
                    case TVA_Player.state.finished:
                    		TVA.log('FINISH!!!');
	                        this.status = this.state.FINISHED;
	                        this.isrunning = false;
	                        Main.keyStop();
	                        Main.togglePlayer(false);
                            this.hideLoading();
	                        break;
            }     
            
        },
        
        forward: function(){
    	    if(TVA_Player.getState() == this.state.FINISHED || TVA_Player.getState() == this.state.STOPPED){
    			return;
    		}
        	if(this.status == this.state.PLAYING || this.status == this.state.PAUSED){
        		TVA.log('[Player] [forward] '+this.skip+' '+TVA_Player.getCurrentTime()+' '+TVA_Player.getLength());
        		TVA_Player.forward(this.skip);
        		//TVA_Player.player.JumpForward(this.skip);
                if(TVA_Player.getState() == this.state.FINISHED){
                	this.getPlayerState(this.state.FINISHED);
                }
        	}
        },

        backward: function(){
    	    if(TVA_Player.getState() == this.state.FINISHED || TVA_Player.getState() == this.state.STOPPED){
    			return;
    		}
        	if(this.status == this.state.PLAYING || this.status == this.state.PAUSED){
        		TVA.log('[Player] [backward] '+this.skip+' '+TVA_Player.getCurrentTime()+' '+TVA_Player.getLength());
        		TVA_Player.backward(this.skip);
                if(TVA_Player.getState() == this.state.FINISHED){
        			TVA_Player.pause(true);
                	this.getPlayerState(this.state.PAUSED);
                }
        	}
        },

        showLoading: function(){
        	TVA.log('[Player] [showLoading]');
        	if (Main.playerView.isVisible()){
            	TVA.log('[Player] [showLoading] addClass');
        		$('#preloadWeel').addClass('playerView');
        	}
        	else{
            	TVA.log('[Player] [showLoading] removeClass');
        		$('#preloadWeel').removeClass('playerView');        		
        	}
        	$('#preload').show();
        	$('#preloadWeel').show();
        },

        hideLoading: function(){
        	TVA.log('[Player] [hideLoading]');
        	if($('#preloadWeel').is(":visible")){
            	$('#preload').hide();
            	$('#preloadWeel').hide();
        	}
        	if (Main.playerView.isVisible()){
        		$('#preloadWeel').removeClass('playerView');
        	}
        }
        
};


// this method is called by TVAE
function playStateChanged (status){
        TVA.log('playStateChanged status ' + status);
	Player.getPlayerState(status);
        
        if (status == 1){

            // hide permanent background that prevents black screens when switching views on Philips
            //if (settings.device == 'philips' || settings.device == 'googletv'){
                
                    var content = $('#content');
                    content.css('background', 'transparent');
            //}   
        }       
}

//this method is called by TVAE
function playHeadChanged(seconds){
	//TVA.log('playHeadChanged seconds=' + seconds);
}

//this method is called by TVAE
function bufferingProgress(bufferProgress){
	TVA.log('bufferingProgress = ' + bufferProgress + '%');
}
