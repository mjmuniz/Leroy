    function bind( scope, fn ) {
        
            return function () {
                    fn.apply( scope, arguments );
            };
    }


    // CONVERT MILLISECONDS TO DIGITAL CLOCK FORMAT      
    function convertMilliseconds ( ms ) {
    
            var hours = Math.floor(ms / 3600000); // 1 Hour = 36000 Milliseconds
            var minutes = Math.floor((ms % 3600000) / 60000); // 1 Minutes = 60000 Milliseconds
            var seconds = Math.floor(((ms % 360000) % 60000) / 1000); // 1 Second = 1000 Milliseconds
        
            seconds = String(seconds);
            if (seconds.length == 1) seconds = '0'+ seconds;
            return {
                    hours : hours,
                    minutes : minutes,
                    seconds : seconds,
                    clock : minutes + ":" + seconds
            };
    }
    
    // SORT CATEGORIES ALPHABETICALLY
    function comparator(a,b) {
            a = a[0][0];
            b = b[0][0];
            return a == b ? 0 : (a < b ? -1 : 1);
    }
    
    // COUNT LENGTH OF OBJECT
    function getObjLength(obj){
            
                var count = 0;
                var i = 0;

                for (i in obj) {
                    if (obj.hasOwnProperty(i)) {
                            count++;
                    }
                }
                return count;
    }
    
    // REMOVE LAST CHARACTER FROM STRING, IF COMMA
    function removeLastComma(astring) {

        var stringLength = astring.length;
        var lastCharacter = astring.substr(stringLength - 1, 1);
        if (lastCharacter == ",")
                astring = astring.substr(0, stringLength - 1)
        return astring;
    }
    
    //TRUNCATE TEXT TO FIT INTO ELEMENT, 
    //ADD 3 ELLIPSIS AT THE END IF TEXT DOES NOT FIT
    function truncate(el) {

        TVA.log("el: " + el);
        var width = el.width(),
            desiredHeight = el.height(),
            text = el.html(),
            naturalHeight = 0,
            heightRatio = 1,
            words = [],
            left = [],
            leftStr = '';

        el.css('height', 'auto');   
        naturalHeight = el.height();
        heightRatio = desiredHeight / naturalHeight;

        if (heightRatio < 1) {
            words = text.split(' ');
            left = words.splice(0, (words.length * heightRatio) | 0);
            leftStr = left.join(' ')
            el.text(leftStr);

            // add one word at a time until the container is full
            while (el.height() <= desiredHeight) {
               el.text(el.html() + ' ' + words.splice(0, 1));   
            }

            words = el.html().split( ' ');
            words.pop();                            // remove last element from array
            el.text(words.join(' ') + ' ...');  

            while (el.height() > desiredHeight) {
                words.pop(); 
                el.text(words.join(' ') + ' ...');   
            }
        }     
    }