window.Es = Es = {
    
      popupConnNoTitle  : "Sin conexión a la red",
      popupConnNoText   : "Por favor, compruebe su conexión a internet y vuelva a lanzar la aplicación",
      popupConnBadTitle : "Inestabilidad de la red",
      popupConnBadText  : "Tú conexión a la red se ha desconectado. Algunos servicios de red pueden necesitar ser reiniciados",
      popupConnBack     : "Pulse volver para cerrar este mensaje"
};